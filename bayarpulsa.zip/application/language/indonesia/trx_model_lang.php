<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.2.8
 * @author Achunk JealousMan (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://isipulsa.co
 * @link http://facebook.com/achunks
 * @link http://your.my.id
 * @link http://sellfy.com/achunk17
 * @copyright 2015 - 2016
 */

defined('BASEPATH') or exit('No direct script access allowed');

$lang['trx_model_1'] = 'Pembayaran atas pembelian {provider} {voucher} sudah dikonfirmasi dan transaksi akan segera diproses.';
$lang['trx_model_2'] = 'Status Order #{id}';

// Admin edit transaksi
$lang['trx_model_3'] = 'Server';
$lang['trx_model_4'] = 'Kode Voucher';
$lang['trx_model_5'] = 'Nomor HP';
$lang['trx_model_6'] = 'ID Pelanggan';
$lang['trx_model_7'] = 'Status Pembayaran';
$lang['trx_model_8'] = 'Status Pengisian';

// Keterangan histori balance
$lang['trx_model_9'] = 'Refund Pembayaran / TRX #{id}';

$lang['trx_model_10'] = 'Pembayaran atas pembelian {provider} {voucher} ditolak dan dana akan segera di-refund;';
