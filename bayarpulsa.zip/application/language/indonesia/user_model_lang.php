<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.2.0
 * @author Achunk JealousMan (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://isipulsa.co
 * @link http://facebook.com/achunks
 * @link http://your.my.id
 * @link http://sellfy.com/achunk17
 * @copyright 2015 - 2016
 */

defined('BASEPATH') OR exit('No direct script access allowed');

// Admin edit user account
$lang['user_model_1'] = 'Nama Pengguna';
$lang['user_model_2'] = 'Nama Lengkap';
$lang['user_model_3'] = 'Email';
$lang['user_model_4'] = 'Jenis Kelamin';
$lang['user_model_5'] = 'Alamat';
$lang['user_model_6'] = 'Nomor HP';
$lang['user_model_7'] = 'Nama Pengguna sudah ada.';
$lang['user_model_8'] = 'Email sudah ada.';
$lang['user_model_9'] = 'Nomor HP sudah ada.';
$lang['user_model_10'] = 'Password Baru';

// Admin edit saldo
$lang['user_model_11'] = 'Jenis';
$lang['user_model_12'] = 'Jumlah';
$lang['user_model_13'] = 'Keterangan';
$lang['user_model_14'] = 'Password Admin';
$lang['user_model_15'] = 'Jumlah harus lebih kecil atau sama dengan {balance}.';

// User login
$lang['user_model_16'] = 'Kata Sandi';
$lang['user_model_17'] = 'Nama pengguna atau kata sandi tidak benar.';
$lang['user_model_18'] = 'Anda sudah terlalu sering gagal login, silakan login kembali pada {date}.';
$lang['user_model_19'] = 'Anda sudah terlalu sering gagal login, jika lupa kata sandi silakan kunjungi {link}.';
$lang['user_model_20'] = 'Gagal Login';
$lang['user_model_21'] = 'Hanya Administrator yang diijinkan untuk masuk situs.';
$lang['user_model_22'] = 'Kode OTP sebelumnya sudah dikirim melaui {via}, silakan tunggu 10 menit lagi untuk meminta kode OTP baru.';
$lang['user_model_23'] = "Kode OTP Anda: {kode}\r\n{site_name}";// Pesan OTP var: {kode}, {site_name}, {site_url}, {link}
$lang['user_model_24'] = 'Kode OTP Login'; // Subjek email
$lang['user_model_25'] = 'Nama pengguna atau kata sandi tidak benar.';

// User register
$lang['user_model_26'] = 'Konfirmasi Kata Sandi';
$lang['user_model_27'] = 'TOS';
$lang['user_model_28'] = 'Pemulihan Kata Sandi';
$lang['user_model_29'] = "Kamu baru saja meminta untuk mer-reset password, silakan klik tautan berikut untuk me-reset password Kamu\r\n{link}\r\nJika Kamu tidak meminta untuk me-reset password abaikan saja pesan ini.";
$lang['user_model_30'] = 'Kata Sandi Diubah';
$lang['user_model_31'] = 'Kata Sandi akun {site_name} berhasil diubah, silakan login di {site_url}.';

// User edit password
$lang['user_model_32'] = 'Kata sandi saat ini';
$lang['user_model_33'] = 'Kata sandi baru';
$lang['user_model_34'] = 'Konfirmasi kata sandi baru';

// User edit security settings
$lang['user_model_35'] = 'Login OTP saat ini tidak tersedia.';
$lang['user_model_36'] = 'Login OTP';
$lang['user_model_37'] = 'Perubahan berhasil disimpan.';

// User transfer saldo
$lang['user_model_38'] = 'Penerima';
$lang['user_model_39'] = 'Jumlah';
$lang['user_model_40'] = 'Keterangan';
$lang['user_model_41'] = 'Transfer saldo dari {username}. Ket: {note}';
$lang['user_model_42'] = 'Transfer saldo kepada {username}. Ket: {note}';
$lang['user_model_43'] = '{name} telah mentransfer saldo ke akun kamu sebesar {amount}.';
$lang['user_model_44'] = 'Anda tidak boleh mentranfer saldo ke akun anda sendiri.';
$lang['user_model_45'] = 'Pengguna tidak ditemukan.';
$lang['user_model_46'] = 'Akun pengguna ini sedang diblokir.';
$lang['user_model_47'] = 'Tidak dapat mentransfer saldo sebesar {amount} ke pengguna ini.';

$lang['user_model_48'] = 'Pengguna tidak ditemukan.';
$lang['user_model_49'] = 'Link untuk me-reset kata sandi sebelumnya sudah Kami kirim ke email Anda.';
