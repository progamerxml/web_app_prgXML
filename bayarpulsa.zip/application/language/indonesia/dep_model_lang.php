<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.2.8
 * @author Achunk JealousMan (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://isipulsa.co
 * @link http://facebook.com/achunks
 * @link http://your.my.id
 * @link http://sellfy.com/achunk17
 * @copyright 2015 - 2016
 */

defined('BASEPATH') or exit('No direct script access allowed');

$lang['dep_model_1'] = 'Deposit melalui {payment} sebesar {amount} ditolak.';
$lang['dep_model_2'] = 'Pemberitahuan Deposit';
$lang['dep_model_3'] = 'Deposit via {payment} {amount} #{id}';
$lang['dep_model_4'] = 'Deposit melalui {payment} sebesar {amount} sudah dikonfirmasi dan saldo sebesar {saldo} ditambahkan ke akun Anda.';
$lang['dep_model_5'] = 'Jumlah';
$lang['dep_model_6'] = 'Pembayaran';
$lang['dep_model_7'] = 'Deposit sebelumnya belum terbayarkan.';
$lang['dep_model_8'] = 'Jumlah deposit harus kelipatan dari {amount}.';
$lang['dep_model_9'] = 'Limit saldo akun anda hanya sebesar {limit}.';
$lang['dep_model_10'] = 'Deposit melalui {payment} minimal {amount}.';
$lang['dep_model_11'] = 'Deposit melalui {payment} maksimal {amount}.';
$lang['dep_model_12'] = 'Silakan masukan jumlah lainnya.';