<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.2.0
 * @author Achunk JealousMan (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://isipulsa.co
 * @link http://facebook.com/achunks
 * @link http://your.my.id
 * @link http://sellfy.com/achunk17
 * @copyright 2015 - 2016
 */

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['order_model_1'] = 'Nomor HP / ID Pelanggan {nomor} diblokir.';
$lang['order_model_2'] = '5 transaksi terakhir anda belum terbayarkan, mohon tunggu beberapa saat lagi.';
$lang['order_model_3'] = 'Sisa saldo kamu tidak cukup untuk melakukan transaksi ini.';
$lang['order_model_4'] = 'Pembayaran tidak tersedia.';
$lang['order_model_5'] = 'Pembayaran {payment} hanya untuk member terdaftar.';
$lang['order_model_6'] = 'Pembayaran {payment} hanya untuk member terverifikasi.';
$lang['order_model_7'] = 'Pembayaran dengan menggunakan {payment} minimal {amount}.';
$lang['order_model_8'] = 'Pembayaran dengan menggunakan {payment} maksimal {amount}.';
$lang['order_model_9'] = 'Silakan pilih nominal voucher lainnya.';
$lang['order_model_10'] = 'Sisa saldo kami tidak cukup untuk melakukan transaksi ini.';
$lang['order_model_11'] = 'Produk ini sedang gangguan.';
$lang['order_model_12'] = 'Pembayaran order {provider} - {voucher} / Trx #{id}';
$lang['order_model_13'] = 'Potongan harga order {provider} - {voucher} / Trx #{id}';
$lang['order_model_14'] = 'Potongan Harga Trx #{id}';
$lang['order_model_15'] = 'Anda mendapat potongan harga sebesar {diskon} atas pembelian {provider} - {voucher}. Harga: {harga} - {diskon} = {harga_dibayar}.';
$lang['order_model_16'] = 'Yang boleh melakukan order {produk} hanya member terdaftar.';
$lang['order_model_17'] = 'Yang boleh melakukan order {produk} hanya member terverifikasi.';
