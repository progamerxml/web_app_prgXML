<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.2.0
 * @author Achunk JealousMan (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://isipulsa.co
 * @link http://facebook.com/achunks
 * @link http://your.my.id
 * @link http://sellfy.com/achunk17
 * @copyright 2015 - 2016
 */

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['order_model_1'] = 'Phone Number / Customer ID {number} blocked.';
$lang['order_model_2'] = '5 of the last transaction you have not paid, please wait a while longer.';
$lang['order_model_3'] = 'The rest of your balance is not sufficient for this transaction.';
$lang['order_model_4'] = 'Payment is not available.';
$lang['order_model_5'] = 'Payment {payment} only for registered members.';
$lang['order_model_6'] = 'Payment {payment} only for verified members.';
$lang['order_model_7'] = 'Payment using {payment} minimum {amount}.';
$lang['order_model_8'] = 'Payment using {payment} maximum {amount}.';
$lang['order_model_9'] = 'Please choose another voucher nominal.';
$lang['order_model_10'] = 'Our balance remaining is not sufficient for this transaction.';
$lang['order_model_11'] = 'This product was being a nuisance.';
$lang['order_model_12'] = 'Payment order {provider} - {voucher} / Trx #{id}';
$lang['order_model_13'] = 'Rebates order {provider} - {voucher} / Trx #{id}';
$lang['order_model_14'] = 'Rebates Trx #{id}';
$lang['order_model_15'] = 'You get a discount on the purchase of {diskon} {provider} - {voucher}. Price: {harga} - {diskon} = {harga_dibayar}.';
$lang['order_model_16'] = 'Yang boleh melakukan order {produk} hanya member terdaftar.';
$lang['order_model_17'] = 'Yang boleh melakukan order {produk} hanya member terverifikasi.';
