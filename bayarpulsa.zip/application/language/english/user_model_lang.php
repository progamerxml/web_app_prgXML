<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.2.0
 * @author Achunk JealousMan (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://isipulsa.co
 * @link http://facebook.com/achunks
 * @link http://your.my.id
 * @link http://sellfy.com/achunk17
 * @copyright 2015 - 2016
 */

defined('BASEPATH') OR exit('No direct script access allowed');

// Admin edit user account
$lang['user_model_1'] = 'Username';
$lang['user_model_2'] = 'Full Name';
$lang['user_model_3'] = 'Email';
$lang['user_model_4'] = 'Gender';
$lang['user_model_5'] = 'Address';
$lang['user_model_6'] = 'Phone';
$lang['user_model_7'] = 'Username already exists.';
$lang['user_model_8'] = 'Email already exists.';
$lang['user_model_9'] = 'Phone already exists.';
$lang['user_model_10'] = 'New Password';

// Admin edit saldo
$lang['user_model_11'] = 'Type';
$lang['user_model_12'] = 'Amount';
$lang['user_model_13'] = 'Note';
$lang['user_model_14'] = 'Admin Password';
$lang['user_model_15'] = 'Amount must be less than or equal to {balance}.';

// User login
$lang['user_model_16'] = 'Password';
$lang['user_model_17'] = 'Username or password is incorrect.';
$lang['user_model_18'] = 'You have too often failed login, please log back on {date}.';
$lang['user_model_19'] = 'You have too often failed login, if you forgot your password please visit the {link}.';
$lang['user_model_20'] = 'Failed Login';
$lang['user_model_21'] = 'Only administrators are allowed to enter the site.';
$lang['user_model_22'] = 'OTP code previously sent via {via}, please wait 10 minutes to ask for a new OTP code.';
$lang['user_model_23'] = "Your OTP code: {kode}\r\n{site_name}";// Pesan OTP var: {kode}, {site_name}, {site_url}, {link}
$lang['user_model_24'] = 'Logi OTP Code'; // Subjek email
$lang['user_model_25'] = 'Username or password is incorrect.';

// User register
$lang['user_model_26'] = 'Confirm Password';
$lang['user_model_27'] = 'TOS';
$lang['user_model_28'] = 'Reset Password';
$lang['user_model_29'] = "You just ask for a password reset, please click the following link to reset your password\r\n{link}\r\nIf you did not request to reset your password just ignore this message.";
$lang['user_model_30'] = 'Password Changed';
$lang['user_model_31'] = 'Password account {site_name} successfully changed, please login at {site_url}.';

// User edit password
$lang['user_model_32'] = 'Current password';
$lang['user_model_33'] = 'New password';
$lang['user_model_34'] = 'Confirm new password';

// User edit security settings
$lang['user_model_35'] = 'OTP login not available.';
$lang['user_model_36'] = 'OTP Login';
$lang['user_model_37'] = 'Changes successfully saved.';

// User transfer saldo
$lang['user_model_38'] = 'Receiver';
$lang['user_model_39'] = 'Amount';
$lang['user_model_40'] = 'Note';
$lang['user_model_41'] = 'Transfer balance from {username}. Note: {note}';
$lang['user_model_42'] = 'Transfer balance to {username}. Note: {note}';
$lang['user_model_43'] = '{name} has been transferred to your account balance for {amount}.';
$lang['user_model_44'] = 'You may not transfer balances to your own account.';
$lang['user_model_45'] = 'User not found.';
$lang['user_model_46'] = 'These user accounts are being blocked.';
$lang['user_model_47'] = 'Unable to transfer the balance of {amount} to this user.';

$lang['user_model_48'] = 'User not found.';
$lang['user_model_49'] = 'Link to reset the password previously we send to your email.';
