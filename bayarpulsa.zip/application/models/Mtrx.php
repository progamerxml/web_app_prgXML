<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.9.1
 * @author Samsul Bahri (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://facebook.com/achunks
 * @license http://w38s.com/lisensi
 * @copyright 2015 - 2017
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Mtrx extends CI_Model
{
    protected $auto_refund = false;
    protected $cek_saldo = true;

    protected $adm_notifaction_config;
    protected $telebot_config;
    protected $apk_config;

    public function __construct()
    {
        parent::__construct();
    }

    public function get_pending_trx($gateway = array())
    {
        $servers = array();
        foreach ($this->get_servers($gateway, 'sv_id') as $srv) {
            $servers[] = $srv->sv_id;
        }
        if (!$servers)
            return array();

        $this->db->select('transaksi.*,voucher.vo_harga_beli,voucher.vo_harga,voucher.vo_harga_reseller,voucher.vo_kode_trx,voucher.vo_kode_fisik,voucher.vo_status,server.sv_nama,server.sv_saldo,server.sv_format_trx,server.sv_regex_sukses,server.sv_regex_gagal,server.sv_regex_sn,server.sv_gateway,server.sv_sms_center,server.sv_jabber_center,server.sv_pin,server.sv_data,users.us_username,users.us_name,users.us_email,users.us_phone,users.us_balance,users.us_data,users.us_telegram_id');
        $this->db->from('transaksi');

        $this->db->join('server', 'server.sv_id = transaksi.sv_id', 'LEFT');
        $this->db->join('voucher', 'voucher.vo_id = transaksi.vo_id', 'LEFT');
        $this->db->join('users', 'users.us_id = transaksi.us_id', 'LEFT');

        $this->db->where_in('transaksi.sv_id', $servers);
        $this->db->where('transaksi.tr_status_pembayaran', 'sukses');
        $this->db->where('transaksi.tr_status', 'pending');

        $this->db->order_by('transaksi.tr_id', 'ASC');
        $query_results = $this->db->get()->result();

        $us_last_trx = array();
        $results = array();

        foreach ($query_results as $res) {
            if ($res->us_id) {
                if (!isset($us_last_trx[$res->us_id]))
                    $us_last_trx[$res->us_id] = 0;
                if (($res->tr_tanggal - $us_last_trx[$res->us_id]) <= 1 && strpos($res->tr_opsi,
                    '"order_via":"Pembelian Massal"') === false && strpos($res->tr_opsi,
                    '"jabbertrx":') === false) {
                    $this->db->where('tr_id', $res->tr_id);
                    $this->db->set('tr_status', 'manual');
                    $this->db->update('transaksi');

                    $this->db->where('us_id', $res->us_id);
                    // Jika user adalah administrator maka akun tidak diblokir
                    $this->db->where('us_rights !=', '10');
                    $this->db->set('us_block', '1');
                    $this->db->update('users');

                    $this->db->insert('notifikasi', array(
                        'us_id' => '0',
                        'nf_admin' => '1',
                        'nf_judul' => 'Transaksi Mencurigakan',
                        'nf_teks' => $res->us_name .
                            ' melakukan transaksi mencurigakan dan akun telah diblokir secara otomatis.',
                        'nf_link' => 'admin/transaksi?status_pengisian=manual',
                        'nf_tanggal' => time(),
                        ));
                } else {
                    $us_last_trx[$res->us_id] = $res->tr_tanggal;
                    $results[] = $res;
                }
            } else {
                $results[] = $res;
            }
        }

        return $results;
    }

    public function get_trx_in_process($gateway = array(), $start_time = null)
    {
        $servers = array();
        foreach ($this->get_servers($gateway, 'sv_id') as $srv) {
            $servers[] = $srv->sv_id;
        }
        if (!$servers)
            return array();

        $this->db->select('transaksi.*,voucher.vo_harga_beli,voucher.vo_harga,voucher.vo_harga_reseller,voucher.vo_kode_trx,voucher.vo_kode_fisik,voucher.vo_status,server.sv_nama,server.sv_saldo,server.sv_format_trx,server.sv_regex_sukses,server.sv_regex_gagal,server.sv_regex_sn,server.sv_gateway,server.sv_sms_center,server.sv_jabber_center,server.sv_pin,server.sv_data,users.us_username,users.us_name,users.us_email,users.us_phone,users.us_balance,users.us_data,users.us_telegram_id');
        $this->db->from('transaksi');

        $this->db->join('server', 'server.sv_id = transaksi.sv_id', 'LEFT');
        $this->db->join('voucher', 'voucher.vo_id = transaksi.vo_id', 'LEFT');
        $this->db->join('users', 'users.us_id = transaksi.us_id', 'LEFT');

        $this->db->where_in('transaksi.sv_id', $servers);
        $this->db->where('transaksi.tr_status_pembayaran', 'sukses');
        $this->db->group_start();
        $this->db->where('transaksi.tr_status', '-');
        $this->db->or_where('transaksi.tr_status', 'dalam_proses');
        $this->db->group_end();
        if ($start_time)
            $this->db->where('transaksi.tr_tanggal >', $start_time);

        $this->db->order_by('transaksi.tr_id', 'ASC');

        return $this->db->get()->result();
    }

    public function trx_voucher_fisik($trx)
    {
        $kode_vouchers = json_decode($this->system->decrypt_data($trx->vo_kode_fisik), true);
        $sn = $kode_vouchers[0];
        unset($kode_vouchers[0]);

        $this->db->where('vo_id', $trx->vo_id);
        if (count($kode_vouchers)) {
            $this->db->set('vo_kode_fisik', $this->system->encrypt_data(json_encode(array_values
                ($kode_vouchers))));
        } else {
            $this->db->set('vo_kode_fisik', '');
        }
        $this->db->update('voucher');

        $opsi = $trx->tr_opsi ? json_decode($trx->tr_opsi, true) : array();
        $opsi['sn'] = $sn;
        $trx->tr_opsi = json_encode($opsi);
        $this->db->where('tr_id', $trx->tr_id);
        $this->db->set('tr_opsi', $trx->tr_opsi);
        $this->db->update('transaksi');
        $message = "Trx #" . $trx->tr_id . " " . ($trx->vo_kode_trx ? $trx->vo_kode_trx :
            $trx->vo_kode) . "." . ($trx->tr_id_plgn ? $trx->tr_id_plgn : $trx->tr_no_hp) .
            " SUKSES. Voucher Fisik: " . $sn;
        $this->set_sukses($trx, $message, $sn);
    }

    public function sms_remind_trx()
    {
        if (!property_exists($this->system->perm, 'sms_reminder'))
            return;

        if (!$this->system->perm->sms_reminder)
            return;

        $this->db->select('transaksi.*,voucher.vo_harga_beli,voucher.vo_harga,voucher.vo_harga_reseller,voucher.vo_kode_trx,voucher.vo_kode_fisik,voucher.vo_status,server.sv_nama,server.sv_saldo,server.sv_format_trx,server.sv_regex_sukses,server.sv_regex_gagal,server.sv_regex_sn,server.sv_gateway,server.sv_sms_center,server.sv_jabber_center,server.sv_pin,server.sv_data,users.us_username,users.us_name,users.us_email,users.us_phone,users.us_balance,users.us_data,users.us_telegram_id');
        $this->db->from('transaksi');
        $this->db->join('server', 'server.sv_id = transaksi.sv_id', 'LEFT');
        $this->db->join('voucher', 'voucher.vo_id = transaksi.vo_id', 'LEFT');
        $this->db->join('users', 'users.us_id = transaksi.us_id', 'LEFT');
        $this->db->where('transaksi.tr_tanggal < ', time() - ($this->system->perm->
            sms_reminder * 60));
        $this->db->where('transaksi.tr_tanggal > ', time() - (3600 * $this->system->set['jam_pembayaran']));
        $this->db->where('transaksi.tr_status_pembayaran', 'pending');
        $this->db->not_like('transaksi.tr_opsi', '"sms_reminder"');
        $query = $this->db->get();
        if (!$query->num_rows())
            return;

        foreach ($query->result() as $trx) {
            $opsi = ($trx->tr_opsi ? json_decode($trx->tr_opsi, true) : array());
            $opsi['sms_reminder'] = format_tanggal(time());
            $this->db->where('tr_id', $trx->tr_id);
            $this->db->set('tr_opsi', json_encode($opsi));
            $this->db->update('transaksi');
            $pesan = "Trx #" . $trx->tr_id . " " . ($trx->vo_kode_trx ? $trx->vo_kode_trx :
                $trx->vo_kode) . "." . ($trx->tr_id_plgn ? $trx->tr_id_plgn : $trx->tr_no_hp) .
                " " . @format_uang2($trx->tr_harga) . " belum dibayar.\r\n" . parse_url(site_url
                (), PHP_URL_HOST);
            send_sms($trx->us_id ? $trx->us_phone : $trx->tr_no_hp, $pesan);
        }
    }

    public function get_servers($gateway = array(), $select = '*')
    {
        $this->db->select($select);
        $this->db->where_in('sv_gateway', $gateway);
        $query = $this->db->get('server');
        return $query->result();
    }

    public function set_sukses($trx, $reply_message, $sn = null)
    {
        if ($this->cek_saldo) {
            $saldo = $this->get_saldo($reply_message);
            if ($saldo) {
                $this->db->where('sv_id', $trx->sv_id);
                $this->db->set('sv_saldo', $saldo);
                $this->db->update('server');
            }
        }

        $income = $this->get_income($trx, $reply_message);

        $opsi = $trx->tr_opsi ? json_decode($trx->tr_opsi, true) : array();

        if (is_null($sn)) {
            $sn = $this->get_sn($trx->sv_regex_sn, $reply_message);
        }
        if ($sn) {
            $opsi['sn'] = $sn;
        }

        $opsi['server_message'] = $reply_message;

        $this->db->where('tr_id', $trx->tr_id);
        $this->db->set('tr_status', 'sukses');
        $this->db->set('tr_income', $income);
        $this->db->set('tr_opsi', json_encode($opsi));
        $this->db->update('transaksi');

        $consumer_message = "Trx #" . $trx->tr_id . " " . ($trx->vo_kode_trx ? $trx->
            vo_kode_trx : $trx->vo_kode) . "." . ($trx->tr_id_plgn ? $trx->tr_id_plgn : $trx->
            tr_no_hp) . " SUKSES.";
        if ($sn) {
            $consumer_message .= "\r\nSN: " . $sn;
        }
        $consumer_message .= "\r\n" . parse_url(site_url(), PHP_URL_HOST);

        if (in_array($trx->op_produk, $this->system->perm->sms_order)) {
            $this->send_sms($trx->tr_no_hp, $consumer_message);
        }

        if ($trx->us_id) {
            $this->db->insert('notifikasi', array(
                'us_id' => $trx->us_id,
                'nf_judul' => 'Status Order #' . $trx->tr_id,
                'nf_teks' => $consumer_message,
                'nf_link' => 'akun/riwayat-transaksi/view/' . $trx->tr_id,
                'nf_feedback' => '1',
                'nf_tanggal' => time(),
                ));
            if (isset($opsi['telegram_chat_id'])) {
                $this->send_telegram_message($opsi['telegram_chat_id'], $consumer_message);
            } elseif (isset($opsi['smstrx'])) {
                $this->send_sms($opsi['smstrx'], $consumer_message);
            } elseif (isset($opsi['jabbertrx'])) {
                $this->send_jabber($opsi['jabbertrx'], $consumer_message);
            } elseif (isset($opsi['order_via']) && $opsi['order_via'] == 'API') {
                $user_data = json_decode($trx->us_data, true);
                if (isset($user_data['api']) && isset($user_data['api']['reg_id'])) {
                    $this->send_android_push($user_data['api']['reg_id'], $trx->tr_id, $consumer_message);
                }
            }
            if ($this->system->perm->email_order == 'yes') {
                $this->send_email($trx->us_email, 'Status Order #' . $trx->tr_id, $consumer_message .
                    "\r\n\r\n" . site_url('akun/riwayat-transaksi/view/' . $trx->tr_id));
            }
        }

        // Notifikasi admin
        if (!$this->adm_notifaction_config)
            $this->adm_notifaction_config = json_decode($this->system->get_set('trx_notifikasi'));

        $this->db->insert('notifikasi', array(
            'us_id' => '0',
            'nf_admin' => '1',
            'nf_judul' => $trx->sv_nama,
            'nf_teks' => $reply_message,
            'nf_link' => 'admin/transaksi/view/' . $trx->tr_id,
            'nf_feedback' => '1',
            'nf_tanggal' => time(),
            ));
        if ($this->adm_notifaction_config->sms) {
            $this->send_sms($this->adm_notifaction_config->sms, $reply_message);
        }
        if ($this->adm_notifaction_config->email) {
            $this->send_email($this->adm_notifaction_config->email, $trx->sv_nama, $reply_message .
                "\r\n\r\n" . site_url('admin/transaksi/view/' . $trx->tr_id));
        }

    }

    public function set_gagal($trx, $reply_message)
    {
        if ($this->cek_saldo) {
            $saldo = $this->get_saldo($reply_message);
            if ($saldo) {
                $this->db->where('sv_id', $trx->sv_id);
                $this->db->set('sv_saldo', $saldo);
                $this->db->update('server');
            }
        }

        $opsi = $trx->tr_opsi ? json_decode($trx->tr_opsi, true) : array();
        $opsi['server_message'] = $reply_message;

        $this->db->where('tr_id', $trx->tr_id);
        if ($trx->us_id && $this->auto_refund && $trx->sv_gateway != 'sms') {
            $this->db->set('tr_status_pembayaran', 'refund');
        }
        $this->db->set('tr_status', 'gagal');
        $this->db->set('tr_opsi', json_encode($opsi));
        $this->db->update('transaksi');

        $consumer_message = "Trx #" . $trx->tr_id . " " . ($trx->vo_kode_trx ? $trx->
            vo_kode_trx : $trx->vo_kode) . "." . ($trx->tr_id_plgn ? $trx->tr_id_plgn : $trx->
            tr_no_hp) . " GAGAL.\r\n" . parse_url(site_url(), PHP_URL_HOST);

        if (in_array($trx->op_produk, $this->system->perm->sms_order) && !isset($opsi['jabbertrx']) &&
            !isset($opsi['smstrx']) && !isset($opsi['telegram_chat_id'])) {
            $this->send_sms($trx->tr_no_hp, $consumer_message);
        }

        if ($trx->us_id) {
            if ($this->auto_refund && $trx->sv_gateway != 'sms') {
                $note = 'Refund Pembayaran / Trx #' . $trx->tr_id;
                $this->db->where('us_id', $trx->us_id);
                $this->db->where('info', $note);
                if (!$this->db->count_all_results('balance_history')) {
                    $this->db->query("UPDATE users SET us_balance = us_balance + $trx->tr_harga2 WHERE us_id = '$trx->us_id'");
                    insert_balance_history(array(
                        $trx->us_id,
                        '0',
                        $trx->tr_harga2,
                        ($trx->us_balance + $trx->tr_harga2),
                        $note,
                        time(),
                        ));
                }
            }
            $this->db->insert('notifikasi', array(
                'us_id' => $trx->us_id,
                'nf_judul' => 'Status Order #' . $trx->tr_id,
                'nf_teks' => $consumer_message,
                'nf_link' => 'akun/riwayat-transaksi/view/' . $trx->tr_id,
                'nf_feedback' => '1',
                'nf_tanggal' => time(),
                ));
            if (isset($opsi['telegram_chat_id'])) {
                $this->send_telegram_message($opsi['telegram_chat_id'], $consumer_message);
            } elseif (isset($opsi['smstrx'])) {
                $this->send_sms($opsi['smstrx'], $consumer_message);
            } elseif (isset($opsi['jabbertrx'])) {
                $this->send_jabber($opsi['jabbertrx'], $consumer_message);
            } elseif (isset($opsi['order_via']) && $opsi['order_via'] == 'API') {
                $user_data = json_decode($trx->us_data, true);
                if (isset($user_data['api']) && isset($user_data['api']['reg_id'])) {
                    $this->send_android_push($user_data['api']['reg_id'], $trx->tr_id, $consumer_message);
                }
            }
            if ($this->system->perm->email_order == 'yes') {
                $this->send_email($trx->us_email, 'Status Order #' . $trx->tr_id, $consumer_message .
                    "\r\n\r\n" . site_url('akun/riwayat-transaksi/view/' . $trx->tr_id));
            }
        }

        // Notifikasi admin
        if (!$this->adm_notifaction_config)
            $this->adm_notifaction_config = json_decode($this->system->get_set('trx_notifikasi'));

        $this->db->insert('notifikasi', array(
            'us_id' => '0',
            'nf_admin' => '1',
            'nf_judul' => $trx->sv_nama,
            'nf_teks' => $reply_message,
            'nf_link' => 'admin/transaksi/view/' . $trx->tr_id,
            'nf_feedback' => '1',
            'nf_tanggal' => time(),
            ));

        if ($this->adm_notifaction_config->sms) {
            $this->send_sms($this->adm_notifaction_config->sms, $reply_message);
        }
        if ($this->adm_notifaction_config->email) {
            $this->send_email($this->adm_notifaction_config->email, $trx->sv_nama, $reply_message);
        }
    }

    public function cek_status($pesan, $regex_sukses, $regex_gagal)
    {
        $status = null;
        if ($regex_sukses) {
            $arr = explode('|', $regex_sukses);
            foreach ($arr as $ar) {
                if ($ar) {
                    $arr1 = explode(',', $ar);
                    $finds = count($arr1);
                    foreach ($arr1 as $ar1) {
                        if ($ar1) {
                            if (stripos($pesan, $ar1) !== false) {
                                $finds -= 1;
                            }
                        }
                    }
                    if ($finds == 0) {
                        return 'sukses';
                    }
                }
            }
        }
        if ($regex_gagal) {
            $arr = explode('|', $regex_gagal);
            foreach ($arr as $ar) {
                if ($ar) {
                    $arr1 = explode(',', $ar);
                    $finds = count($arr1);
                    foreach ($arr1 as $ar1) {
                        if ($ar1) {
                            if (stripos($pesan, $ar1) !== false) {
                                $finds -= 1;
                            }
                        }

                    }
                    if ($finds == 0) {
                        return 'gagal';
                    }
                }
            }
        }
        return null;
    }

    public function set_proses($trx)
    {
        $this->db->where('tr_id', $trx->tr_id);
        $this->db->set('tr_status', '-');
        $this->db->update('transaksi');
    }

    public function get_sn($regex, $message)
    {
        $message = str_replace("\n", " ", $message);
        if (!$regex)
            return '';
        preg_match($regex, $message, $matches);
        $sn = '';
        if (isset($matches['sn'])) {
            $sn = trim($matches['sn']);

            if (strpos($sn, 'Bisa diorderkan kembali') !== false) {
                $xsn = explode('Bisa diorderkan kembali', $sn);
                $sn = trim($xsn[0]);
            } elseif (strpos($sn, 'Harga:') !== false) {
                $xsn = explode('Harga:', $sn);
                $sn = trim($xsn[0]);
            } elseif (strpos($sn, 'Tgl:') !== false) {
                $xsn = explode('Tgl:', $sn);
                $sn = trim($xsn[0]);
            } elseif (strpos($sn, 'Hrg') !== false) {
                $xsn = explode('Hrg', $sn);
                $sn = trim($xsn[0]);
            }

            $sn = (substr($sn, -1) == '.' ? substr($sn, 0, -1) : $sn);
        }
        return $sn;
    }

    public function get_income($trx, $message)
    {
        $harga_beli = 0;
        $harga_jual = $trx->us_id ? $trx->tr_harga2 : $trx->tr_harga;
        $income = 0;
        $regex = array(
            '/([0-9\.\,]{4,16})( - |-)(?P<harga>[a-zA-Z0-9\.\,\:]{4,32})( =|=)/s',
            '/(Hrg|Harga)(=| = |:| : | Rp\.| )(?P<harga>[0-9\.\,]{4,32})/is',
            );
        for ($i = 0; $i < count($regex); $i++) {
            preg_match($regex[$i], $message, $matches);
            if (isset($matches['harga'])) {
                $harga_beli = (int)preg_replace('/\D/', '', $matches['harga']);
                $income = $harga_jual - $harga_beli;
            }
        }
        if (!$harga_beli && $trx->vo_harga_beli)
            $harga_beli = $trx->vo_harga_beli;

        if ($harga_beli != $trx->vo_harga_beli) {
            $harga_umum = $harga_beli + ($trx->vo_harga - $harga_beli);

            if ($trx->vo_harga_reseller)
                $harga_reseller = $harga_umum - ($trx->vo_harga - $trx->vo_harga_reseller);
            else
                $harga_reseller = $harga_umum;

            if ($harga_reseller < $harga_beli)
                $harga_reseller = $harga_umum;

            $this->db->where('vo_id', $trx->vo_id);
            $this->db->set('vo_harga_beli', $harga_beli);
            $this->db->set('vo_harga', $harga_umum);
            $this->db->set('vo_harga_reseller', $harga_reseller);
            $this->db->update('voucher');
        }
        if ($income == 0 && $harga_beli != 0)
            $income = $harga_jual - $harga_beli;
        return $income;
    }

    public function get_saldo($message)
    {
        $message = str_replace("\n", " ", $message);
        $regex = array(
            '/([0-9\.\,]{4,16})( - |-)([a-zA-Z0-9\.\,\:]{4,32})( = |=)(?P<saldo>[a-zA-Z0-9\.\,\:]{4,32})/',
            '/(?P<saldo>[0-9\.,]+), masih proses/i',
            '/(Sal|Saldo)(=| = |:| : | )(?P<saldo>[a-zA-Z0-9\.\,\:]{4,32})/i');
        for ($i = 0; $i < count($regex); $i++) {
            preg_match($regex[$i], $message, $matches);
            if (isset($matches['saldo'])) {
                return (int)preg_replace('/\D/', '', $matches['saldo']);
            }
        }
        return 0;
    }

    public function get_format_trx($trx)
    {
        $format = json_decode($trx->sv_format_trx, true);
        $format_trx = $format[$trx->op_produk];
        $format_dobel = $trx->op_produk . '_dobel';
        $total = 0;
        if (isset($format[$format_dobel])) {
            $total = $this->count_success_trx($trx);
            if ($total >= 1)
                $format_trx = $format[$format_dobel];
        }
        $replaces = array(
            '{ID}' => $trx->tr_id,
            '{KODE}' => $trx->vo_kode,
            '{NO_HP}' => $trx->tr_no_hp,
            '{NUM}' => ($total + 1),
            '{ID_PLGN}' => $trx->tr_id_plgn,
            '{PIN}' => $this->system->decrypt_data($trx->sv_pin),
            );
        $pesan = str_ireplace(array_keys($replaces), array_values($replaces), $format_trx);
        return $pesan;
    }

    public function count_success_trx($trx)
    {
        $this->db->select('tr_id');
        $this->db->where('sv_id', $trx->sv_id);
        $this->db->where('vo_id', $trx->vo_id);
        if ($trx->tr_id_plgn)
            $this->db->where('tr_id_plgn', $trx->tr_id_plgn);
        else
            $this->db->where('tr_no_hp', $trx->tr_no_hp);
        $this->db->where('tr_status_pembayaran', 'sukses');
        $this->db->where('tr_status', 'sukses');
        $this->db->where('tr_tanggal >', strtotime(date('Y/m/d 00:00:00')));
        $this->db->where('tr_tanggal <', strtotime(date('Y/m/d 23:59:59')));
        return $this->db->count_all_results('transaksi');
    }

    public function send_sms($phone, $message)
    {
        $this->db->insert('sms_keluar', array(
            'out_to' => $phone,
            'out_message' => $message,
            'out_submit_date' => time(),
            ));
    }

    protected function send_jabber($receiver, $message)
    {
        $this->load->model('sms_model');
        $jabber_api = json_decode($this->system->get_set('jabber_api'), true);
        if ($jabber_api['server_url'] && $jabber_api['username'] && $jabber_api['password']) {
            if ($this->sms_model->send_mass_jabber(array($receiver), $message, $jabber_api)) {
                return true;
            } else {
                return false;
            }
        } else {
            $this->sms_model->send_mass_jabber(array($receiver), $message, $jabber_api);
            return true;
        }
    }

    public function send_email($to, $subject, $message)
    {
        $this->load->library('email');
        $this->email->from($this->system->get_set('site_email'), $this->system->set['site_name']);
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message . "\r\n\r\n" . $this->system->set['site_name'] .
            "\r\n" . site_url());
        @$this->email->send();
    }

    public function send_telegram_message($telegram_id, $message)
    {
        if (!$this->telebot_config)
            $this->telebot_config = json_decode($this->system->get_set('telegram_bot'));

        if (!$this->telebot_config->token)
            return;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.telegram.org/bot' . $this->
            telebot_config->token . '/sendMessage');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array(
            'chat_id' => $telegram_id,
            'text' => $message,
            'disable_web_page_preview' => true,
            )));
        $req = curl_exec($ch);
        curl_close($ch);

        return $req;
    }

    public function send_android_push($reg_id, $trx_id, $body)
    {
        if (!$this->apk_config)
            $this->apk_config = @json_decode($this->system->get_set('aplikasi_android'));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: key=' . $this->apk_config->fcm_server_key,
            'Content-Type: application/json',
            ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            'to' => $reg_id,
            'notification' => array(
                'title' => 'Status Order ' . $trx_id,
                'body' => $body,
                'sound' => 'mySound',
                'click_action' => 'DETAIL_TRANSAKSI',
                'android_channel_id' => 'transactions', // V2
                ),
            'data' => array(
                'trxID' => $trx_id,
                'transaction_id' => (String)$trx_id, // v2
                ),
            )));
        $req = curl_exec($ch);
        curl_close($ch);

        return $req;
    }
}
