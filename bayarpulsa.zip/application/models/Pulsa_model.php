<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pulsa_model extends CI_Model
{
    public $voucher;
    public $server;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('server_model');
    }

    public function get_providers()
    {
        $this->db->where('op_produk', 'pulsa');
        $this->db->order_by('op_produk', 'ASC');
        $this->db->order_by('op_nama', 'ASC');
        $query = $this->db->get('operator');
        if ($query->num_rows() > 0)
            $providers = $query->result_array();
        else
            $providers = array();
        return $providers;
    }

    public function create()
    {
        $this->load->library('form_validation');
        // Operator
        $op_label = $this->system->produk->pulsa->form->provider->label;
        $this->form_validation->set_rules('operator', $op_label, 'required');
        // Voucher
        $vo_label = $this->system->produk->pulsa->form->voucher->label;
        $this->form_validation->set_rules('voucher', $vo_label, array(
            'required',
            array('vcr', array($this->pulsa_model, 'cek_voucher')),
            ));
        // Nomor Hp
        $this->form_validation->set_rules('nomor_hp', 'Nomor HP', array(
            'required',
            'numeric',
            'min_length[8]',
            'max_length[14]',
            array('hp', array($this->pulsa_model, 'validasi_hp')),
            ));
        // Pembayaran
        $this->form_validation->set_rules('pembayaran', 'Pembayaran',
            'required|in_list[' . implode(',', array_keys($this->payment->get())) . ']',
            array('in_list' => 'Pembayaran tidak tersedia.'));
        // General
        $this->load->model('order_model');
        $this->order_model->set_rules(strtolower(__class__));

        if ($this->form_validation->run() != false) {
            $values = array('tr_no_hp' => $this->input->post('nomor_hp'));
            return $this->order_model->insert($values);
        }
        return 0;
    }

    public function cek_voucher($voucher)
    {
        $this->db->select('voucher.*, operator.*');
        $this->db->join('operator', 'operator.op_id = voucher.op_id');
        $this->db->where(array(
            'voucher.sv_id !=' => '0',
            'voucher.vo_id' => $voucher,
            'voucher.op_id' => $this->input->post('operator'),
            'voucher.vo_status' => '1',
            ));
        $query = $this->db->get('voucher');

        if ($query->num_rows() == 0) {
            $this->form_validation->set_message('vcr',
                'Voucher tidak tersedia, silakan pilih nominal lainnya.');
            return false;
        }

        $this->voucher = $query->row();

        $this->db->where('tr_no_hp', $this->input->post('nomor_hp'));
        $this->db->order_by('tr_id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get('transaksi');

        $old_trx = null;

        if ($query->num_rows()) {
            $old_trx = $query->row();
            if (($old_trx->tr_status_pembayaran == 'sukses' && $old_trx->tr_status ==
                'pending') || $old_trx->tr_status == 'dalam_proses' || $old_trx->tr_status ==
                '-' || $old_trx->tr_status == 'manual') {
                $this->form_validation->set_message('vcr', 'Transaksi sebelumnya ke ' . $this->input->post
                    ('nomor_hp') . ' masih dalam proses.');
                return false;
            } elseif (($old_trx->tr_tanggal > (time() - (3600 * $this->system->set['jam_pembayaran']))) &&
            $old_trx->tr_status_pembayaran == 'pending') {
                $this->form_validation->set_message('vcr', 'Transaksi sebelumnya ke ' . $this->input->post
                    ('nomor_hp') . ' masih menunggu pembayaran.');
                return false;
            }
        }

        $server = $this->server_model->get_server($this->voucher->sv_id);

        if (!$server) {
            $this->form_validation->set_message('vcr',
                'Saat ini server untuk memproses transaksi ' . html_escape($this->voucher->op_nama .
                ' - ' . $this->voucher->vo_nominal) . ' tidak tersedia.');
            return false;
        }

        $this->server = $server;

        $format_trx = json_decode($server->sv_format_trx, true);
        $format_dobel = $this->voucher->op_produk . '_dobel';
        if (!isset($format_trx[$format_dobel])) {
            $this->db->where('sv_id', $server->sv_id);
            $this->db->where('vo_id', $this->voucher->vo_id);
            $this->db->where('tr_no_hp', $this->input->post('nomor_hp'));
            $this->db->where('tr_status_pembayaran', 'sukses');
            $this->db->where('tr_status', 'sukses');
            $this->db->where('tr_tanggal >', strtotime(date('Y/m/d 00:00:00')));
            $this->db->where('tr_tanggal <', strtotime(date('Y/m/d 23:59:59')));
            if ($this->db->count_all_results('transaksi')) {
                $this->form_validation->set_message('vcr',
                    'Tidak dapat memproses transaksi dobel di hari yang sama untuk nominal ' .
                    html_escape($this->voucher->op_nama . ' - ' . $this->voucher->vo_nominal) .
                    ' ke ' . $this->input->post('nomor_hp') . '.');
                return false;
            }

        }
        return true;
    }

    public function validasi_hp($nomor)
    {
        if ($this->form_validation->error_array())
            return true;
        $validator = json_decode($this->system->get_set('validasi_nomor'), true);
        if (!validasi_nomor($this->voucher->op_id, $nomor, $validator)) {
            $this->form_validation->set_message('hp', 'Nomor HP tidak benar');
            return false;
        }
        return true;
    }
}
