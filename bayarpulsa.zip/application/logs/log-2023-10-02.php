<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-02 02:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-02 02:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-02 03:29:18 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-02 03:41:55 --> 404 Page Not Found: Well_known/apple_app_site_association
ERROR - 2023-10-02 04:17:40 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-10-02 10:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-02 15:00:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:00:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:00:44 --> Unable to connect to the database
ERROR - 2023-10-02 15:00:44 --> Unable to connect to the database
ERROR - 2023-10-02 15:00:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:00:44 --> Unable to connect to the database
ERROR - 2023-10-02 15:00:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:00:55 --> Unable to connect to the database
ERROR - 2023-10-02 15:01:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:01:01 --> Unable to connect to the database
ERROR - 2023-10-02 15:01:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:01:12 --> Unable to connect to the database
ERROR - 2023-10-02 15:01:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-10-02 15:01:13 --> Unable to connect to the database
ERROR - 2023-10-02 16:17:45 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-10-02 20:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-02 20:03:46 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-10-02 20:17:54 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-10-02 20:17:56 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-10-02 23:33:47 --> 404 Page Not Found: user/Login/xmlrpc.php
