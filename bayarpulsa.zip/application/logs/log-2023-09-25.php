<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-25 02:45:24 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-25 02:45:24 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-25 02:45:45 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-25 02:45:45 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-25 03:54:56 --> 404 Page Not Found: 403shtml/index
ERROR - 2023-09-25 07:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 07:28:43 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-25 08:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 09:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 13:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 13:29:46 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-25 16:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-25 16:36:42 --> 404 Page Not Found: Well_known/assetlinks.json
