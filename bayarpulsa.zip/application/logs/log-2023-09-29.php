<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-29 00:18:02 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-29 00:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-29 03:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-29 11:10:22 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 12:02:08 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 12:02:09 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 12:02:10 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 12:02:11 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 12:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-29 12:09:53 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-09-29 12:10:07 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-29 12:10:09 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-09-29 12:10:10 --> 404 Page Not Found: Well_known/security.txt
ERROR - 2023-09-29 12:10:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-29 12:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-29 12:10:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2023-09-29 12:10:41 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-29 12:10:43 --> 404 Page Not Found: Securitytxt/index
ERROR - 2023-09-29 12:10:44 --> 404 Page Not Found: Well_known/security.txt
ERROR - 2023-09-29 12:10:45 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-29 16:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-29 17:06:51 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 17:06:52 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 17:06:53 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 17:06:54 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-29 23:33:21 --> 404 Page Not Found: Adstxt/index
