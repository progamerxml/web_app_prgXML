<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-13 08:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 08:29:08 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-13 08:29:34 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-13 08:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 09:01:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-13 09:01:34 --> Unable to connect to the database
ERROR - 2023-09-13 13:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 22:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-13 22:28:12 --> 404 Page Not Found: Adstxt/index
