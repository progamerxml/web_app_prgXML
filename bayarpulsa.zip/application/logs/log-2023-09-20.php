<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-20 06:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 07:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 07:59:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-20 08:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 08:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 13:20:46 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-20 13:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-20 13:28:22 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-20 14:07:16 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-20 14:07:16 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-20 14:07:16 --> 404 Page Not Found: 403shtml/index
ERROR - 2023-09-20 14:07:18 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-20 15:15:50 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-20 17:57:35 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-20 18:26:04 --> 404 Page Not Found: Apple_app_site_association/index
ERROR - 2023-09-20 21:57:58 --> 404 Page Not Found: Robotstxt/index
