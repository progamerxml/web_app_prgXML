<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-22 00:22:47 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for this server Unknown 0
ERROR - 2023-09-22 03:36:09 --> 404 Page Not Found: Licensetxt/index
ERROR - 2023-09-22 04:31:21 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-22 04:48:05 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-22 07:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 08:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 08:48:12 --> 404 Page Not Found: Well_known/apple_app_site_association
ERROR - 2023-09-22 09:00:43 --> 404 Page Not Found: Apple_app_site_association/index
ERROR - 2023-09-22 13:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 13:41:41 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-22 16:51:28 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-22 16:51:29 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-22 16:51:32 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-22 16:51:33 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-22 22:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-22 22:27:56 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-22 23:35:56 --> 404 Page Not Found: Robotstxt/index
