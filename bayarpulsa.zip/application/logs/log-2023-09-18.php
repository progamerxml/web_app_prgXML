<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-18 02:13:40 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-18 07:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 08:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 08:31:15 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-18 12:01:57 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-18 13:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 17:33:52 --> 404 Page Not Found: Well_known/apple_app_site_association
ERROR - 2023-09-18 18:00:32 --> 404 Page Not Found: Apple_app_site_association/index
ERROR - 2023-09-18 21:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-18 21:57:16 --> 404 Page Not Found: Adstxt/index
