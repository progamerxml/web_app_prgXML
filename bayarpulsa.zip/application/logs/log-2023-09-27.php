<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-27 01:52:50 --> 404 Page Not Found: Site/login
ERROR - 2023-09-27 01:54:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home1/pulsacil/bayarpulsa.com/application/views/akun/deposit/index.php 44
ERROR - 2023-09-27 01:54:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home1/pulsacil/bayarpulsa.com/application/views/akun/deposit/index.php 44
ERROR - 2023-09-27 01:54:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home1/pulsacil/bayarpulsa.com/application/views/akun/deposit/index.php 44
ERROR - 2023-09-27 02:59:07 --> 404 Page Not Found: 
ERROR - 2023-09-27 03:02:32 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-27 03:02:33 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-27 03:02:35 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-27 03:02:35 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-27 04:22:59 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for this server Unknown 0
ERROR - 2023-09-27 06:15:39 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-27 06:15:40 --> 404 Page Not Found: user/Login/xmlrpc.php
ERROR - 2023-09-27 06:15:41 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-27 07:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 07:41:57 --> 404 Page Not Found: 
ERROR - 2023-09-27 08:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 08:33:26 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-27 09:16:34 --> Severity: Warning --> filemtime(): stat failed for /home1/pulsacil/bayarpulsa.com/application/logs/cron.txt /home1/pulsacil/bayarpulsa.com/application/controllers/Cron.php 0
ERROR - 2023-09-27 09:37:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:50 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:50 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:50 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:50 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:50 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:50 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:53 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:54 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:56 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:57 --> Unable to connect to the database
ERROR - 2023-09-27 09:37:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:37:59 --> Unable to connect to the database
ERROR - 2023-09-27 09:38:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:38:00 --> Unable to connect to the database
ERROR - 2023-09-27 09:38:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:38:00 --> Unable to connect to the database
ERROR - 2023-09-27 09:38:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:38:02 --> Unable to connect to the database
ERROR - 2023-09-27 09:38:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:38:08 --> Unable to connect to the database
ERROR - 2023-09-27 09:38:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-27 09:38:13 --> Unable to connect to the database
ERROR - 2023-09-27 13:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 20:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 20:24:22 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-27 20:50:39 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-27 22:29:35 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-27 22:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-27 22:30:17 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-27 22:30:19 --> 404 Page Not Found: Adstxt/index
