<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-21 00:28:41 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-21 00:28:48 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-21 06:54:55 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for this server Unknown 0
ERROR - 2023-09-21 08:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 08:18:34 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-21 08:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 12:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 12:57:48 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-21 12:57:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-21 13:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 13:22:15 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-21 13:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-21 13:28:33 --> 404 Page Not Found: Adstxt/index
