<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-01 02:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-01 02:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-01 07:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-01 10:37:09 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-10-01 11:11:51 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-10-01 13:16:54 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-10-01 20:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-10-01 22:03:43 --> 404 Page Not Found: Wp_includes/css
