<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-28 01:47:58 --> 404 Page Not Found: admin/sistem/Install/index
ERROR - 2023-09-28 06:28:00 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-28 07:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 08:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 11:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 12:51:55 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-28 13:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 13:29:43 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-28 19:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-28 20:21:15 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-28 20:21:15 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-28 22:46:06 --> 404 Page Not Found: Robotstxt/index
