<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-30 02:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-30 02:39:05 --> 404 Page Not Found: Script/index
ERROR - 2023-09-30 04:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-30 06:17:45 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 06:17:46 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 06:17:49 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 06:17:50 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 06:38:59 --> 404 Page Not Found: 403shtml/index
ERROR - 2023-09-30 06:39:00 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-30 06:39:00 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-30 06:41:32 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-30 07:29:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:41 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:41 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:41 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:41 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:41 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:42 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:46 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:47 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:51 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:51 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:52 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:56 --> Unable to connect to the database
ERROR - 2023-09-30 07:29:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:29:59 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:01 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:04 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:06 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:07 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:08 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:11 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:12 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:16 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:18 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:21 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:21 --> Unable to connect to the database
ERROR - 2023-09-30 07:30:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-30 07:30:22 --> Unable to connect to the database
ERROR - 2023-09-30 08:59:01 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 08:59:07 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 08:59:13 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 08:59:42 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 09:21:14 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 09:30:30 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 09:37:36 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 11:32:03 --> 404 Page Not Found: Well_known/apple_app_site_association
ERROR - 2023-09-30 11:57:36 --> 404 Page Not Found: Apple_app_site_association/index
ERROR - 2023-09-30 11:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-30 12:09:07 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-30 15:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-30 15:41:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-30 16:21:48 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-30 16:21:49 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-30 16:21:49 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-30 16:21:50 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-30 16:21:51 --> 404 Page Not Found: Backup/index
ERROR - 2023-09-30 16:21:51 --> 404 Page Not Found: Old/index
ERROR - 2023-09-30 16:21:52 --> 404 Page Not Found: New/index
ERROR - 2023-09-30 16:21:53 --> 404 Page Not Found: Home/index
ERROR - 2023-09-30 18:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-30 23:30:44 --> 404 Page Not Found: user/Register/xmlrpc.php
ERROR - 2023-09-30 23:30:44 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-30 23:30:45 --> 404 Page Not Found: 403shtml/index
ERROR - 2023-09-30 23:30:55 --> 404 Page Not Found: user/Xmlrpcphp/index
