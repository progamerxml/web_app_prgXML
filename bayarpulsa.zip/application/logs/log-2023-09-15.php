<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-15 01:35:06 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-15 08:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-15 08:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-15 08:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-15 08:42:34 --> 404 Page Not Found: Humanstxt/index
ERROR - 2023-09-15 08:42:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-15 10:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-15 10:33:04 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-15 13:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-15 21:46:09 --> 404 Page Not Found: Robotstxt/index
