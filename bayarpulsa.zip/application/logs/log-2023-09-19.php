<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-19 05:19:31 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-19 05:19:32 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-19 05:19:32 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-19 05:19:33 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-19 05:19:33 --> 404 Page Not Found: Backup/index
ERROR - 2023-09-19 05:19:34 --> 404 Page Not Found: Old/index
ERROR - 2023-09-19 05:19:34 --> 404 Page Not Found: New/index
ERROR - 2023-09-19 05:19:35 --> 404 Page Not Found: Home/index
ERROR - 2023-09-19 06:29:27 --> 404 Page Not Found: Apple_app_site_association/index
ERROR - 2023-09-19 07:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 08:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 13:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 13:08:31 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-19 13:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-19 13:27:16 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-19 15:51:32 --> 404 Page Not Found: Stylephp/index
ERROR - 2023-09-19 18:02:08 --> 404 Page Not Found: Well_known/apple_app_site_association
ERROR - 2023-09-19 23:45:39 --> 404 Page Not Found: user/Xmlrpcphp/index
ERROR - 2023-09-19 23:45:41 --> 404 Page Not Found: 403shtml/index
ERROR - 2023-09-19 23:45:45 --> 404 Page Not Found: user/Login/xmlrpc.php
ERROR - 2023-09-19 23:45:47 --> 404 Page Not Found: user/Login/xmlrpc.php
ERROR - 2023-09-19 23:45:51 --> 404 Page Not Found: 403shtml/index
