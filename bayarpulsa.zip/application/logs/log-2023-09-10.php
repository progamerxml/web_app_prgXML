<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-10 03:27:43 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:44 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:45 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:45 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:46 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:46 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:47 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:48 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:48 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 03:27:49 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-10 08:30:41 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-10 08:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 08:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 08:59:01 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-10 14:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 16:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 23:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-10 23:25:31 --> 404 Page Not Found: Adstxt/index
