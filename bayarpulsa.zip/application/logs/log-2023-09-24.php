<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-24 02:37:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-24 02:37:13 --> Unable to connect to the database
ERROR - 2023-09-24 02:37:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-24 02:37:14 --> Unable to connect to the database
ERROR - 2023-09-24 04:09:35 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-24 04:09:35 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:36 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:36 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-24 04:09:36 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:37 --> 404 Page Not Found: Bc/index
ERROR - 2023-09-24 04:09:37 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:37 --> 404 Page Not Found: Bk/index
ERROR - 2023-09-24 04:09:38 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:38 --> 404 Page Not Found: Backup/index
ERROR - 2023-09-24 04:09:38 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:39 --> 404 Page Not Found: Old/index
ERROR - 2023-09-24 04:09:39 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:39 --> 404 Page Not Found: New/index
ERROR - 2023-09-24 04:09:40 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:40 --> 404 Page Not Found: Home/index
ERROR - 2023-09-24 04:09:40 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 04:09:41 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 07:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 08:22:30 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:22:30 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:25:06 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:25:06 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:25:35 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:25:35 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:25:36 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:25:36 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 08:30:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-24 08:42:24 --> Severity: Notice --> Undefined index: N0111 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 08:42:24 --> Severity: Notice --> Undefined index: N0101 /home1/pulsacil/bayarpulsa.com/application/controllers/admin/modules/Otomax.php 0
ERROR - 2023-09-24 11:16:02 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 11:16:03 --> 404 Page Not Found: Wp/index
ERROR - 2023-09-24 11:16:03 --> 404 Page Not Found: Wordpress/index
ERROR - 2023-09-24 11:16:03 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 11:16:04 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 11:16:04 --> 404 Page Not Found: Demo/index
ERROR - 2023-09-24 11:16:04 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 11:16:05 --> 404 Page Not Found: New/index
ERROR - 2023-09-24 11:16:05 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 11:16:05 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-24 13:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-24 22:28:22 --> 404 Page Not Found: Robotstxt/index
