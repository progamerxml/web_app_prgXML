<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-09 08:01:51 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-09 08:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-09 09:26:12 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-09 13:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-09 14:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-09 23:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-09 23:27:16 --> 404 Page Not Found: Adstxt/index
