<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-11 04:28:09 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-11 04:28:13 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-11 07:07:03 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2023-09-11 08:29:48 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-11 08:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 08:56:52 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-11 08:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 13:42:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-11 13:42:17 --> Unable to connect to the database
ERROR - 2023-09-11 13:42:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-11 13:42:36 --> Unable to connect to the database
ERROR - 2023-09-11 13:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 14:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-11 22:56:14 --> 404 Page Not Found: Adstxt/index
