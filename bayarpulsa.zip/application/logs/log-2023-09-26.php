<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-26 02:26:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-26 02:26:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-26 02:26:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-26 02:26:48 --> Unable to connect to the database
ERROR - 2023-09-26 02:26:48 --> Unable to connect to the database
ERROR - 2023-09-26 02:26:48 --> Unable to connect to the database
ERROR - 2023-09-26 02:27:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-26 02:27:07 --> Unable to connect to the database
ERROR - 2023-09-26 02:27:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-26 02:27:10 --> Unable to connect to the database
ERROR - 2023-09-26 06:43:52 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-26 07:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 07:32:08 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-26 08:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 11:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 11:15:13 --> 404 Page Not Found: Apple_app_site_association/index
ERROR - 2023-09-26 11:31:01 --> 404 Page Not Found: Well_known/apple_app_site_association
ERROR - 2023-09-26 13:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 18:06:32 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-26 18:49:15 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-26 18:49:16 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-26 18:49:17 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-26 18:49:18 --> Severity: Core Error --> <br>The encoded file <b>/home1/pulsacil/bayarpulsa.com/application/core/MY_Controller.php</b> is not permissioned for 139.162.57.218 Unknown 0
ERROR - 2023-09-26 21:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 21:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-26 22:28:45 --> 404 Page Not Found: Robotstxt/index
