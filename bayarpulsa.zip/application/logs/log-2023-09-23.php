<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-23 07:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-23 08:18:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-23 08:18:59 --> Unable to connect to the database
ERROR - 2023-09-23 08:19:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-23 08:19:05 --> Unable to connect to the database
ERROR - 2023-09-23 08:19:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home1/pulsacil/bayarpulsa.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2023-09-23 08:19:28 --> Unable to connect to the database
ERROR - 2023-09-23 08:29:10 --> 404 Page Not Found: Adstxt/index
ERROR - 2023-09-23 09:23:30 --> 404 Page Not Found: 403shtml/index
ERROR - 2023-09-23 10:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-23 11:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-23 13:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2023-09-23 14:50:20 --> 404 Page Not Found: Well_known/assetlinks.json
ERROR - 2023-09-23 22:28:35 --> 404 Page Not Found: Adstxt/index
