<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.5.0
 * @author Samsul Bahri (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://facebook.com/achunks
 * @link http://sellfy.com/achunk17
 * @license http://w38s.com/lisensi
 * @copyright 2015 - 2017
 */

defined('BASEPATH') or exit('No direct script access allowed');

function tg_keterangan($user_id, $tagihan, $data, $admin = false)
{
    if ($tagihan == 'Pembayaran Masal') {
        $CI = &get_instance();
        $CI->db->select('tr_id,op_produk,op_nama,vo_nominal,tr_id_plgn,tr_no_hp');
        $CI->db->where('us_id', $user_id);
        $CI->db->where_in('tr_id', $data['trx']);
        $CI->db->order_by('tr_tanggal', 'DESC');
        $query = $CI->db->get('transaksi');
        if (!$query->num_rows())
            return '';
        $trx = array();
        foreach ($query->result() as $res) {
            $trx[] = 'Trx #<a href="' . site_url(($admin ? 'admin/transaksi' :
                'akun/riwayat-transaksi') . '/view/' . $res->tr_id) . '">' . $res->tr_id .
                '</a> ' . html_escape(property_exists($CI->system->produk, $res->op_produk) ? $CI->
                system->produk->{$res->op_produk}->nama : ucwords(str_replace('_', ' ', $res->
                op_produk))) . ' - ' . html_escape($res->op_nama) . ' - ' . html_escape($res->
                vo_nominal) . ' ke ' . ($res->tr_id_plgn ? $res->tr_id_plgn : $res->tr_no_hp);
        }
        return implode("<br/>", $trx);
    } elseif (isset($data['keterangan']))
        return $data['keterangan'];
    else
        return '';
}

function tg_status($tanggal, $status, $expired)
{
    if ($status == 'refund')
        return '<span class="badge" style="width: 34px;" data-toggle="tooltip" data-title="Refund">RF<span>';
    elseif ($status == 'sukses')
        return '<span class="badge badge-success" style="width: 34px;" data-toggle="tooltip" data-title="Lunas">OK</span>';
    else {
        if ($tanggal < $expired)
            return '<span class="badge badge-important" style="width: 34px;" data-toggle="tooltip" data-title="Tidak berlaku">CL</span>';
        else
            return '<span class="badge badge-warning" style="width: 34px;" data-toggle="tooltip" data-title="Menunggu pembayaran">WP</span>';
    }
}
