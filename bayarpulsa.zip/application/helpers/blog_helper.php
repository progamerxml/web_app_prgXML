<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.5.0
 * @author Samsul Bahri (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://facebook.com/achunks
 * @link http://sellfy.com/achunk17
 * @license http://w38s.com/lisensi
 * @copyright 2015 - 2017
 */

defined('BASEPATH') or exit('No direct script access allowed');

function get_post_category($str, $single = false)
{
    $kategori = array();
    $array = @json_decode($str, true);
    if (!$array)
        return $kategori;
    $CI = &get_instance();
    $CI->db->where_in('bk_id', $array);
    $CI->db->order_by('bk_nama', 'ASC');
    if ($single)
        $CI->db->limit(1);
    $query = $CI->db->get('blog_kategori');
    foreach ($query->result() as $res) {
        $kategori[] = '<a href="' . site_url('blog/kategori/' . $res->bk_slug) . '">' .
            html_escape($res->bk_nama) . '</a>';
    }
    return $kategori;
}
