<?php

/**
 * @package Pulsa Online w38s.com
 * @version 3.5.0
 * @author Samsul Bahri (0818118061 / achunk17@gmail.com)
 * @link http://w38s.com
 * @link http://facebook.com/achunks
 * @link http://sellfy.com/achunk17
 * @license http://w38s.com/lisensi
 * @copyright 2015 - 2017
 */

defined('BASEPATH') or exit('No direct script access allowed');

function format_size($bytes)
{
    if ($bytes >= 1073741824) {
        $bytes = number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        $bytes = number_format($bytes / 1048576, 2) . ' MB';
    } else {
        $bytes = number_format($bytes / 1024, 2) . ' KB';
    }

    return $bytes;
}

function sidebar_menu($params, $dropdown = true, $title = 'NAVIGASI')
{
    $active = false;
    $list_group = '';
    $option = array();

    for ($i = 0; $i < count($params); $i++) {
        $param = $params[$i];
        $list_group .= '<div class="panel panel-default' . ($dropdown ? ' hidden-xs' :
            '') . '">' . '<div class="panel-heading"><h3>' . (isset($param['icon']) ?
            '<i class="' . $param['icon'] . '"></i> ' : '') . $param['title'] .
            '</h3></div><div class="list-group">';
        $option[] = '<optgroup label="' . $param['title'] . '">';
        $s = 0;
        foreach ($param['links'] as $link) {
            $list_group .= '<a class="list-group-item' . (isset($link[3]) && $link[3] ?
                ' active' : '') . '" id="menu_item_' . $i . '_' . $s . '" href="' . $link[1] .
                '">' . (isset($link[2]) && $link[2] ? '<i class="' . $link[2] . '"></i> ' : '') .
                $link[0] . (isset($link[4]) && $link[4] ? ' ' . $link[4] : '') . '</a>';
            $option[] = '<option value="' . $link[1] . '"' . (isset($link[3]) && $link[3] ?
                ' selected="selected"' : '') . '>' . $link[0] . (isset($link[4]) && $link[4] ?
                ' (' . strip_tags($link[4]) . ')' : '') . '</option>';
            if (isset($link[3]) && $link[3])
                $active = true;
            $s++;
        }
        $list_group .= '</div></div>';
        $option[] = '</optgroup>';
    }
    if (!$active)
        $option[0] = '<option value="#" selected="selected">' . $title . '</option>' . $option[0];
    $html = '';
    if ($dropdown) {
        $html .= '<div class="left-menu-select visible-xs"><div class="input-group"><span class="' .
            'input-group-addon" style="background-color: transparent"><i class="fa fa-bars"></i>' .
            '</span><select class="form-control" ' .
            'onChange="window.location.href=this.value">' . implode('', $option) .
            '</select></div></div>';
    }
    $html .= $list_group;
    return $html;
}
function pagination_start($page, $per_page = false)
{
    $page = intval($page);
    if (!$per_page)
        $per_page = get_instance()->system->get_set('list_per_page');
    $start = $page ? $page * $per_page - $per_page : 0;
    return $start;
}

function send_sms($to, $message)
{
    get_instance()->db->insert('sms_keluar', array(
        'out_to' => $to,
        'out_message' => $message,
        'out_submit_date' => time(),
        ));
}

function deposit_status_label($trx, $exp_time, $status_code = true)
{
    if ($trx->de_status == 'pending' && $trx->de_tanggal < $exp_time)
        $status = array(
            'status' => 'CL',
            'label' => '<span class="badge badge-important" style="width: 34px;" data-toggle="tooltip" data-title="Deposit tidak berlaku">CL</span>',
            );
    elseif ($trx->de_status == 'pending')
        $status = array(
            'status' => 'WP',
            'label' => '<span class="badge badge-warning" style="width: 34px;" data-toggle="tooltip" data-title="Menunggu pembayaran">WP</span>',
            );
    elseif ($trx->de_status == 'dalam_proses')
        $status = array(
            'status' => 'IP',
            'label' => '<span class="badge badge-info" style="width: 34px;" data-toggle="tooltip" data-title="Menunggu konfirmasi">IP</span>',
            );
    elseif ($trx->de_status == 'refund')
        $status = array(
            'status' => 'RF',
            'label' => '<span class="badge" style="width: 34px;" data-toggle="tooltip" data-title="Refund">RF</span>',
            );
    else
        $status = array(
            'status' => 'OK',
            'label' => '<span class="badge badge-success" style="width: 34px;" data-toggle="tooltip" data-title="Deposit berhasil">OK</span>',
            );
    return ($status_code ? $status : $status['label']);
}

function insert_balance_history($data = array())
{
    $array = array(
        'us_id',
        'debet',
        'kredit',
        'saldo_akhir',
        'info',
        'tanggal',
        );
    if (count($data) == 5)
        unset($array[3]);
    get_instance()->db->insert('balance_history', array_combine($array, $data));
    return true;
}

function harga_unik($harga, $hour = 72, $pembayaran = null)
{
    $CI = get_instance();
    $ranges = explode('-', $CI->system->get_set('trx_range'));
    $expired = time() - (3600 * $hour);
    for ($i = 0; $i < 5; $i++) {
        $harga_unik = $harga + mt_rand((int)$ranges[0], (int)$ranges[1]);
        if (!is_null($pembayaran)) {
            $CI->db->where('tr_pembayaran', $pembayaran);
        }
        $CI->db->where('tr_harga', $harga_unik);
        $CI->db->where('tr_rate', 0);
        $CI->db->where('tr_tanggal >', $expired);
        if ($CI->db->count_all_results('transaksi') == 0) {
            return $harga_unik;
        }
    }
    return 0;
}

function status_label($trx, $exp_time, $status_code = true)
{
    if ($trx->tr_status_pembayaran == 'pending' && $trx->tr_tanggal < $exp_time)
        $status = array(
            'status' => 'CL',
            'label' => '<span class="badge badge-important" style="width: 34px;" data-toggle="tooltip" data-title="Transaksi dibatalkan">CL</span>',
            );
    elseif ($trx->tr_status_pembayaran == 'pending')
        $status = array(
            'status' => 'WP',
            'label' => '<span class="badge badge-warning" style="width: 34px;" data-toggle="tooltip" data-title="Menunggu Pembayaran">WP</span>',
            );
    elseif ($trx->tr_status_pembayaran == 'refund')
        $status = array(
            'status' => 'RF',
            'label' => '<span class="badge" style="width: 34px;" data-toggle="tooltip" data-title="Refund, Nomer habis masa aktif atau Nomer salah">RF</span>',
            );
    elseif ($trx->tr_status_pembayaran == 'sukses' && ($trx->tr_status == 'pending' ||
        $trx->tr_status == 'dalam_proses' || $trx->tr_status == '-' || $trx->tr_status ==
        'manual'))
        $status = array(
            'status' => 'IP',
            'label' => '<span class="badge badge-info" style="width: 34px;" data-toggle="tooltip" data-title="Sedang kami proses">IP</span>',
            );
    elseif ($trx->tr_status_pembayaran == 'sukses' && $trx->tr_status == 'gagal')
        $status = array(
            'status' => 'CL',
            'label' => '<span class="badge badge-important" style="width: 34px;" data-toggle="tooltip" data-title="Transaksi dibatalkan">CL</span>',
            );
    else
        $status = array(
            'status' => 'OK',
            'label' => '<span class="badge badge-success" style="width: 34px;" data-toggle="tooltip" data-title="Transaksi berhasil">OK</span>',
            );
    return ($status_code ? $status : $status['label']);
}
function uri_to_assoc($params = array())
{
    $vars = array();
    array_unshift($params, "/");
    for ($i = 0; $i < count($params); $i++) {
        if ($i % 2)
            $vars[$params[$i]] = isset($params[$i + 1]) ? $params[$i + 1] : '';
    }
    return $vars;
}
function validasi_nomor($provider, $input_number, $data_validasi = array())
{
    $status = true;
    $data_validasi = is_object($data_validasi) ? (array )$data_validasi : $data_validasi;
    foreach ($data_validasi as $data) {
        if (in_array($provider, $data['operator'])) {
            if (!preg_match($data['regex'], $input_number)) {
                $status = false;
            }
        }
    }
    return $status;
}

function get_validator($provider, $data_validasi = array(), $ret_array = false)
{
    $data_validasi = is_object($data_validasi) ? (array )$data_validasi : $data_validasi;
    foreach ($data_validasi as $data) {
        if (in_array($provider, $data['operator'])) {
            return $ret_array ? $data : $data['nama'];
        }
    }
    return '';
}

function get_thumb($str, $default_image = '')
{
    preg_match('/\<img(.*?)src=\"(.*?)\"(.*?)\>/i', $str, $matches,
        PREG_OFFSET_CAPTURE);
    if ($matches) {
        return strip_tags($matches[2][0]);
    }
    return $default_image;
}
function remove_tags($str)
{
    $str = str_replace('<', ' <', $str);
    $str = strip_tags($str);
    $str = preg_replace('!\s+!', ' ', $str);
    return trim($str);
}
function str_link($str, $sep = '-')
{
    setlocale(LC_ALL, 'en_US.UTF8');
    $plink = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
    $plink = preg_replace("/[^a-zA-Z0-9\/_| -]/", '', $plink);
    $plink = strtolower(trim($plink, $sep));
    $plink = preg_replace("/[\/_| -]+/", $sep, $plink);
    return $plink;
}
function format_uang($nilai)
{
    return number_format($nilai, 0, '', '.');
}
function format_uang2($rupiah, $rate = 0, $tpl = 'Rp {INT}', $round = 2)
{
    if ($rate)
        return str_ireplace('{INT}', round($rupiah / $rate, $round), $tpl);
    return str_ireplace('{INT}', number_format($rupiah, 0, '', '.'), $tpl);
}
function pagination($url, $start, $total, $kmess, $page_str = 'page=%d')
{
    if ($total <= $kmess)
        return;
    $neighbors = 3;
    if ($start >= $total)
        $start = max(0, $total - (($total % $kmess) == 0 ? $kmess : ($total % $kmess)));
    else
        $start = max(0, (int)$start - ((int)$start % (int)$kmess));
    $base_link = '<li><a href="' . strtr($url, array('%' => '%%')) . $page_str .
        '">%s</a></li>';
    $out[] = $start == 0 ?
        '<li class="disabled"><span><span aria-hidden="true">&laquo; Prev</span></span></li>' :
        sprintf('<li><a href="' . strtr($url, array('%' => '%%')) . $page_str .
        '">%s</a></li>', $start / $kmess, '&laquo; Prev');
    if ($start > $kmess * $neighbors)
        $out[] = sprintf($base_link, 1, '1');
    if ($start > $kmess * ($neighbors + 1)) {
        $out[] = '<li class="disabled"><span><span aria-hidden="true">...</span></span></li>';
    }
    for ($nCont = $neighbors; $nCont >= 1; $nCont--)
        if ($start >= $kmess * $nCont) {
            $tmpStart = $start - $kmess * $nCont;
            $out[] = sprintf($base_link, $tmpStart / $kmess + 1, $tmpStart / $kmess + 1);
        }
    $out[] = '<li class="active"><a href="#">' . ($start / $kmess + 1) . '</a></li>';
    $tmpMaxPages = (int)(($total - 1) / $kmess) * $kmess;
    for ($nCont = 1; $nCont <= $neighbors; $nCont++)
        if ($start + $kmess * $nCont <= $tmpMaxPages) {
            $tmpStart = $start + $kmess * $nCont;
            $out[] = sprintf($base_link, $tmpStart / $kmess + 1, $tmpStart / $kmess + 1);
        }
    if ($start + $kmess * ($neighbors + 1) < $tmpMaxPages) {
        $out[] = '<li class="disabled"><span><span aria-hidden="true">...</span></span></li>';
    }
    if ($start + $kmess * $neighbors < $tmpMaxPages)
        $out[] = sprintf($base_link, $tmpMaxPages / $kmess + 1, $tmpMaxPages / $kmess +
            1);
    if ($start + $kmess < $total) {
        $display_page = ($start + $kmess) > $total ? $total : ($start / $kmess + 2);
        $out[] = sprintf('<li><a href="' . strtr($url, array('%' => '%%')) . $page_str .
            '">%s</a></li>', $display_page, 'Next &raquo;');
    } else {
        $out[] = '<li class="disabled"><span><span aria-hidden="true">Next &raquo;</span></span></li>';
    }
    $html = '<nav><ul class="pagination">' . implode('', $out) . '</ul></nav>';
    return $html;
}

function format_tanggal($var, $full = false)
{
    $shift = get_instance()->system->set['zona_waktu'] * 3600;
    if ($full != false) {
        $tanggal = strtr(date("-N, j #m Y H:i", $var + $shift), array(
            '-1' => 'Senin',
            '-2' => 'Selsa',
            '-3' => 'Rabu',
            '-4' => 'Kamis',
            '-5' => 'Jum&quot;at',
            '-6' => 'Sabtu',
            '-7' => 'Minggu',
            '#01' => 'Januari',
            '#02' => 'Februari',
            '#03' => 'Maret',
            '#04' => 'April',
            '#05' => 'Mei',
            '#06' => 'Juni',
            '#07' => 'Juli',
            '#08' => 'Agustus',
            '#09' => 'September',
            '#10' => 'Oktober',
            '#11' => 'November',
            '#12' => 'Desember',
            ));
        return $tanggal . ' WIB';
    }
    return date("d/m/Y H:i", $var + $shift);
}
if (!function_exists('lang')) {
    /**
     * Lang
     *
     * Fetches a language variable and optionally outputs a form label
     *
     * @param	string	$line		The language line
     * @param	string	$for		The "for" value (id of the form element)
     * @param	array	$attributes	Any additional HTML attributes
     * @return	string
     */
    function lang($line, $for = '', $attributes = array())
    {
        $line = get_instance()->lang->line($line);

        if ($for !== '') {
            $line = '<label for="' . $for . '"' . _stringify_attributes($attributes) . '>' .
                $line . '</label>';
        }

        return $line;
    }
}
