<div class="table-responsive">
  <table class="table table-hover">
    <tbody>
      <tr><td>Jenis Produk</td><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->nama);?></td></tr>
      <tr><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->form->provider->label);?></td><td><?php echo html_escape($trx->op_nama);?></td></tr>
      <tr><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->form->voucher->label);?></td><td><?php echo html_escape($trx->vo_nominal);?></td></tr>
      <tr><td><?php echo html_escape(@$this->system->produk->{$trx->op_produk}->form->id_plgn->label);?></td><td><?php echo (($this->user->is_user() && $trx->us_id == $this->user->data['us_id']) || $this->user->is_admin() ? $trx->tr_id_plgn : substr($trx->tr_id_plgn, 0, -3).'XXXX');?></td></tr>
      <tr><td>Nomor HP</td><td><?php echo (($this->user->is_user() && $trx->us_id == $this->user->data['us_id']) || $this->user->is_admin() ? $trx->tr_no_hp : substr($trx->tr_no_hp, 0, -3).'XXX');?></td></tr>
      <tr><td>Harga</td><td><?php echo format_uang2($trx->tr_harga, $trx->tr_rate, $this->payment->{$trx->tr_pembayaran}->template, $this->payment->{$trx->tr_pembayaran}->round);?></td></tr>
      <tr><td>Pembayaran</td><td><?php echo $trx->tr_pembayaran =='balance' ? 'Saldo Akun' : $this->payment->{$trx->tr_pembayaran}->nama;?></td></tr>
      <tr><td>Tanggal Pembelian</td><td><?php echo format_tanggal($trx->tr_tanggal);?></td></tr>
      <?php if ($trx->tr_status_pembayaran != 'pending' && $trx->tanggal):?>
      <tr><td>Tanggal Pembayaran</td><td><?php echo format_tanggal($trx->tanggal);?></td></tr>
      <?php endif;?>
      <tr><td>Status Pembayaran</td><td><?php echo ucfirst(str_replace('_',' ', $trx->tr_status_pembayaran));?></td></tr>
      <tr><td>Status Pengisian</td><td><?php echo ucfirst(str_replace('_',' ', $trx->tr_status));?></td></tr>
    </tbody>
  </table>
</div>