<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      Riwayat Transaksi | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li class="active"><span>Riwayat Transaksi</span></li>
      </ul>
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3>
            <span class="pull-right"><i class="fa fa-refresh fa-spin"></i></span>
            <i class="fa fa-history"></i> Riwayat Transaksi
          </h3>
        </div>
        <div class="panel-body">
          <div class="row" style="margin-bottom: 15px;">
            <div class="col-sm-4">
              <a href="<?php echo site_url('contact-us');?>" target="_blank" class="btn btn-danger hidden-xs">Komplain / Pertanyaan</a>
            </div>
            <div class="col-sm-4">
              <div id="refresh" class="text-center">
              </div>
            </div>
            <div class="col-sm-4">
              <span class="pull-right">
                <form method="GET" action="<?php echo current_url();?>">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Cari no. telepon.." name="q" id="q" value="<?php echo html_escape($search);?>" maxlength="12"/>
                    <span class="input-group-btn">
                      <button type="submit" class="btn btn-primary">
                        <i class="fa fa-search">
                        </i>
                      </button>
                    </span>
                  </div>
                </form>
              </span>
            </div>
          </div>
          <?php if (!$results):?>
          <div class="alert alert-info">
            Tidak ada transaksi
          </div>
          <?php else:?>
          <div class="table-responsive">
            <table class="table table-striped hidden-phone">
              <thead>
                <tr>
                  <th>
                    #
                  </th>
                  <th>
                    Tanggal
                  </th>
                  <th>
                    Provider
                  </th>
                  <th>
                    Voucher
                  </th>
                  <th>
                    No. Telepon
                  </th>
                  <th>
                    Harga
                  </th>
                  <th>
                    Pembayaran
                  </th>
                  <th>
                    Status
                  </th>
                </tr>
              </thead>
              <tbody id="history_transaksi">
                <?php $i=1; foreach ($results as $trx): ?>
                <tr>
                  <td>
                    <?php echo $i . PHP_EOL; ?>
                  </td>
                  <td>
                    <a href="<?php echo site_url('history/view/' . $trx->tr_id); ?>"><?php echo format_tanggal($trx->tr_tanggal);?></a>
                  </td>
                  <td>
                    <?php echo html_escape($trx->op_nama) . PHP_EOL;?>
                  </td>
                  <td>
                    <?php echo html_escape($trx->vo_nominal) . PHP_EOL;?>
                  </td>
                  <td>
                    <?php echo (($this->user->is_user() && $trx->us_id == $this->user->data['us_id']) || $this->user->is_admin() ? $trx->tr_no_hp : substr($trx->tr_no_hp, 0, -3).'XXX') . PHP_EOL;?>
                  </td>
                  <td class="text-left">
                    <?php echo format_uang2($trx->tr_harga, $trx->tr_rate, $this->payment->{$trx->tr_pembayaran}->template, $this->payment->{$trx->tr_pembayaran}->round);?>
                  </td>
                  <td>
                    <?php echo $trx->tr_pembayaran =='balance' ? 'Saldo Akun' : $this->payment->{$trx->tr_pembayaran}->nama . PHP_EOL;?>
                  </td>
                  <td>
                    <?php echo status_label($trx, $exp_time, false) . PHP_EOL;?>
                  </td>
                </tr>
                <?php $i++; endforeach;?>
              </tbody>
            </table>
          </div>
          <?php endif;?>
          <div class="row">
            <div class="col-sm-4">
              <p>
                <b>
                  Keterangan Status
                </b>
              </p>
              <table class="table" style="margin-bottom: 15px;">
                <tbody>
                  <tr>
                    <td style="width: 40px;">
                      <span class="badge badge-warning" style="width: 34px;">
                        WP
                      </span>
                    </td>
                    <td>
                      Menunggu Pembayaran.
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <span class="badge badge-info" style="width: 34px;">
                        IP
                      </span>
                    </td>
                    <td>
                      Sedang kami proses.
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <span class="badge badge-success" style="width: 34px;">
                        OK
                      </span>
                    </td>
                    <td>
                      Transaksi berhasil.
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <span class="badge badge-important" style="width: 34px;">
                        CL
                      </span>
                    </td>
                    <td>
                      Transaksi dibatalkan.
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <span class="badge" style="width: 34px;">
                        RF
                      </span>
                    </td>
                    <td>
                      Refund, Nomer habis masa aktif atau Nomer salah.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="col-sm-8">
              <p>
                <b>
                  Pulsa Telpon, Token, atau Voucher Belum Masuk?
                </b>
              </p>
              <ul>
                <li>
                  Terlebih dahulu cek pulsa Anda. Kadang pulsa sudah masuk mendahului report / notifikasi melalui SMS.
                </li>
                <li>
                  Khusus Token PLN, Token akan otomatis kami kirimkan ke HP anda atau bisa langsung anda cetak di halaman informasi order.
                </li>
              </ul>
              <p>
                <b>
                  Status WP atau Waiting Payment / Belum dibayar?
                </b>
              </p>
              <ul>
                <li>
                  Hal ini dikarenakan ibanking Mandiri/BCA/BRI/BNI sedang Offline (sehingga sistem kami tidak bisa mengecek data mutasi atau data mutasi tidak update).
                </li>
                <li>
                  Anda salah mentransfer Nominal / Jumlah dan Berita yang telah diinstruksikan oleh sistem? Jika YA, silahkan ulangi transfer anda dengan Nominal yang telah diinfokan oleh sistem (Total harga beserta angka
                  unik, tidak dibulatkan). Segera hubungi cs untuk request refund dana sebelumnya.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script>
      /*<![CDATA[*/
      function refreshHistory() {
        <?php if (!$search):?>
        $.get("<?php echo site_url('ajax/history_trx');?>", function(data) {
          $("#history_transaksi").html(data);
        });
        <?php endif;?>
      }
      setInterval(refreshHistory, 5000);
      /*]]>*/
    </script>
  </body>

</html>