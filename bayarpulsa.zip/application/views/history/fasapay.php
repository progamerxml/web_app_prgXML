<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>IDR</td><td><?php echo format_uang2($trx->tr_harga, 0, $this->payment->fasapay->template);?></td></tr>
        <tr><td>USD</td><td><?php echo format_uang2($trx->tr_harga, $this->payment->fasapay->data->rate_usd, $this->payment->fasapay->data->template_usd, 2);?></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Anda dapat melakukan pembayaran dengan mata uang IDR atau USD.</li>
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<form action="https://sci.fasapay.com/" method="POST">
  <input type="hidden" name="fp_acc" value="<?php echo html_escape($this->payment->fasapay->data->nomor_rekening);?>"/>
  <input type="hidden" name="fp_store" value="<?php echo html_escape($this->payment->fasapay->data->nama_rekening);?>"/>
  <input type="hidden" name="fp_item" value="<?php echo html_escape($this->system->produk->{$trx->op_produk}->nama.' '.$trx->op_nama.' '.$trx->vo_nominal);?>"/>
  <input type="hidden" id="amount" name="fp_amnt" value="<?php echo $trx->tr_harga;?>"/>
  <input type="hidden" name="fp_fee_mode" value="FiS"/>
  <input type="hidden" name="fp_merchant_ref" value="<?php echo $trx->tr_id_pembayaran;?>"/>
  <input type="hidden" name="trx_id" value="TRX<?php echo $trx->tr_id;?>"/>
  <input type="hidden" name="fp_success_url" value="<?php echo site_url('history/view/'.$trx->tr_id);?>"/>
  <input type="hidden" name="fp_status_url" value="<?php echo site_url('payment/fasapay/trx/'.$trx->tr_id);?>"/>
  <input type="hidden" name="fp_fail_url" value="<?php echo site_url('history/view/'.$trx->tr_id);?>"/>
  <div class="panel-footer">
    <div class="form-group">
      <select class="form-control" name="fp_currency" id="currency" onchange="setAmount(this.value)">
        <option value="IDR"><?php echo format_uang2($trx->tr_harga, 0, $this->payment->fasapay->template);?></option>
        <option value="USD"><?php echo format_uang2($trx->tr_harga, $this->payment->fasapay->data->rate_usd, $this->payment->fasapay->data->template_usd, 2);?></option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-money"></i> Bayar Sekarang</button>
  </div>
</form>
<script type="text/javascript">function setAmount(currency) {if (currency == 'USD'){document.getElementById("amount").value = '<?php echo round($trx->tr_harga / $this->payment->fasapay->data->rate_usd, 2);?>';}else{document.getElementById("amount").value = '<?php echo $trx->tr_harga; ?>';}}</script>