<div class="panel-body">
  <div>
    <div class="text-warning text-center">
      Pembayaran akan diproses secara otomatis apabila menggunakan saldo iPaymu, jika menggunakan bank transfer dan anda sudah membayarnya maka segera hubungi Administrator.
    </div>
    <br />
    <div class="table-responsive">
      <table class="table table-striped">
        <tbody>
          <tr>
            <td>Harga</td>
            <td>Rp <?php echo format_uang($trx->tr_harga);?></td>
          </tr>
          <tr>
            <td>Fee / Biaya</td>
            <td>Rp <?php echo format_uang($fee = ceil(round($trx->tr_harga / 100, 2)));?></td>
          </tr>
          <tr>
            <td>Total</td>
            <td><strong>Rp <?php echo format_uang($trx->tr_harga + $fee);?></strong></td>
          </tr>
        </tbody>
      </table>
    </div>
    <p>
      Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.
      <br/>
      Dana yang akan dikembalikan ke saldo akun adalah <strong>Rp <?php echo $trx->tr_harga - $trx->tr_harga2;?></strong> setelah pembayaran berhasil diselesaikan.
    </p>
  </div>
</div>
<div class="panel-footer">
  <a class="btn btn-primary btn-block" href="<?php echo site_url('payment/ipaymu/trx/'.$trx->tr_id);?>" id="submit-confirm">
    Bayar Sekarang
  </a>
</div>