<?php if ($trx->tr_status_pembayaran == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>Harga</td><td><?php echo format_uang2($trx->tr_harga2);?></td></tr>
        <tr><td>Fee</td><td><?php echo format_uang2(floor($trx->tr_harga2 * 3 / 100 + 2500));?></td></tr>
        <tr><td>Total</td><td><strong><?php echo format_uang2($trx->tr_harga2 + floor($trx->tr_harga2 * 3 / 100 + 2500));?></strong></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <a href="<?php echo site_url('payment/duitku/trx/'.$trx->tr_id);?>" class="btn btn-primary btn-block" id="submit-confirm"><i class="fa fa-money"></i> Bayar Sekarang </a>
</div>
<?php endif;?>