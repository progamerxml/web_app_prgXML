<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr>
          <td>No. Rekening</td>
          <td><?php echo html_escape($this->payment->bank_bca->data->nomor_rekening);?></td>
        </tr>
        <tr>
          <td>Atas Nama</td>
          <td><?php echo html_escape($this->payment->bank_bca->data->nama_rekening);?></td>
        </tr>
        <tr>
          <td>Harga</td>
          <td><?php echo format_uang2($trx->tr_harga2);?></td>
        </tr>
        <tr>
          <td>Kode Unik</td>
          <td><?php echo format_uang2($trx->tr_harga - $trx->tr_harga2);?></td>
        </tr>
        <tr>
          <td>Total</td>
          <td><strong><?php echo format_uang2($trx->tr_harga);?></strong></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
    <li>Silakan lakukan transfer sebesar <strong><?php echo format_uang2($trx->tr_harga);?></strong>.</li>
    <?php if ($trx->us_id):?>
    <li>Harga unik sebesar <?php echo format_uang2($trx->tr_harga - $trx->tr_harga2);?> akan dikembalikan ke saldo deposit Anda.</li>
    <?php endif;?>
    <li>Jika memungkinkan, Anda juga dapat mentransfer sejumlah <strong><?php echo format_uang2($trx->tr_harga2);?></strong> dan masukan berita transfer <strong><?php echo $trx->tr_id_pembayaran;?></strong>.</li>
    <li>Setelah melakukan pembayaran silakan klik tombol &quot;<b>Konfirmasi Pembayaran</b>&quot;.</li>
    <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <a href="<?php echo site_url('payment/bank_bca/trx/'.$trx->tr_id);?>" class="btn btn-primary btn-block" id="submit-confirm"><i class="fa fa-check"></i> Konfirmasi Pembayaran</a>
</div>