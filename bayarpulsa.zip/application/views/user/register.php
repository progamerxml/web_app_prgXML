<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8"/>
    <title>
      Mendaftar | <?php echo html_escape($this->system->set[ 'site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <link href="<?php echo base_url('assets/css/signin.css');?>" rel="stylesheet"/>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="account-container register stacked">
      <div class="content clearfix">
        <?php echo form_open();?>
          <h1>
            <i class="fa fa-user-plus"></i> Mendaftar
          </h1>
          <p>
            Membuat akun
          </p>
          <div class="form-group">
            <input type="text" id="user_username" name="user_username" value="<?php echo set_value('user_username');?>" placeholder="Nama Pengguna" class="form-control input-lg" required="required"/>
          </div>
          <div class="form-group">
            <input type="text" id="user_phone" name="user_phone" value="<?php echo set_value('user_phone');?>" placeholder="Nomor HP" class="form-control input-lg" required="required" maxlength="13"/>
          </div>
          <div class="form-group">
            <input type="email" id="user_email" name="user_email" value="<?php echo set_value('user_email');?>" placeholder="Email" class="form-control input-lg" required="required" maxlength="64"/>
          </div>
          <div class="form-group">
            <input type="password" id="user_password" name="user_password" value="" placeholder="Kata Sandi" class="form-control input-lg" required="required"/>
          </div>
          <div class="form-group">
            <input type="password" id="user_confirm_password" name="user_confirm_password" value="" placeholder="Konfirmasi Kata Sandi" class="form-control input-lg" required="required"/>
          </div>
          <?php if ($this->system->perm->captcha_reg == 'yes'):?>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon" style="padding: 0;">
                <img src="<?php echo site_url('captcha');?>" style="" alt="Captcha"/>
              </span>
              <input type="text" class="form-control input-lg" name="captcha" id="captcha" maxlength="5" size="5" required="required" placeholder="Kode keamanan">
            </div>
          </div>
          <?php endif;?>
          <div class="checkbox">
            <label for="tos">
              <input id="tos" name="tos" type="checkbox" class="field login-checkbox" value="1" tabindex="4" /> Saya sudah membaca dan setuju dengan Syarat dan Ketentuan.
            </label>
          </div>
          <div class="login-actions">
            <button class="login-action btn btn-primary btn-lg btn-block" type="submit" name="submit" value="signup">
              Mendaftar
            </button>
          </div>
        </form>
      </div>
    </div>
    <div class="login-extra">
      Sudah punya akun?
      <a href="<?php echo site_url('user/login');?>">Masuk</a>
    </div>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>">
    </script>
    <script src="<?php echo base_url('assets/js/notify.min.js');?>"></script>
    <script>
      $(document).ready(function(){
        <?php if ($this->session->get_flash_keys()):?>
        <?php foreach ($this->session->get_flash_keys() as $fk):?>
        $.notify("<?php echo strip_tags($this->session->flashdata($fk));?>", "<?php echo $fk;?>");
        <?php endforeach;?>
        <?php endif;?>
        <?php if (function_exists('validation_errors') && validation_errors()):?>
        <?php foreach (array_reverse($this->form_validation->error_array()) as $err):?>
        $.notify("<?php echo strip_tags($err);?>", "error");
        <?php endforeach;?>
        <?php endif;?>
      });
    </script>
  </body>

</html>