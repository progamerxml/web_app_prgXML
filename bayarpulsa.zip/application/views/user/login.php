<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <title>Masuk | <?php echo html_escape($this->system->set[ 'site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <link href="<?php echo base_url('assets/css/signin.css');?>" rel="stylesheet"/>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="account-container stacked">
      <div class="content">
        <?php echo form_open();?>
          <h1><i class="fa fa-sign-in"></i> Masuk</h1>
          <p>Masuk dengan akun terdaftar Anda</p>
          <?php if ($this->system->set['maintenance'] == 'on'):?>
          <div class="alert alert-danger" id="alert">Akses situs hanya untuk Administrator</div>
          <?php endif;?>
          <?php if ($otp != false):?>
          <div class="alert alert-info">Kode OTP telah dikirim melalui <?php echo strtoupper($otp);?>, silakan masukan kode OTP tersebut di kolom Password / Kode OTP.</div>
          <div class="form-group">
            <input type="text" id="username" name="username" value="<?php echo set_value('username');?>" class="form-control input-lg username-field" readonly="readonly"/>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon" data-toggle="tooltip" data-title="Jangan minta kode OTP pada browser ini"><input type="checkbox" name="save_browser" value="1" /></span>
              <input type="text" placeholder="Kode OTP" maxlength="5" autocomplete="off" id="password" name="password" value="" class="form-control input-lg password-field" required="required"/>
            </div>
          </div>
          <?php else:?>
          <div class="form-group">
            <input type="text" id="username" name="username" value="<?php echo set_value('username');?>" placeholder="Nama Pengguna" class="form-control input-lg username-field" required="required"/>
          </div>
          <div class="form-group">
            <input type="password" placeholder="Kata Sandi" id="password" name="password" value="" class="form-control input-lg password-field" required="required"/>
          </div>
          <?php endif;?>
          <?php if ($this->system->perm->captcha_login == 'yes' && $otp == false):?>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon" style="padding: 0;">
                <img src="<?php echo site_url('captcha');?>" style="" alt="Captcha"/>
              </span>
              <input type="text" class="form-control input-lg" name="captcha" id="captcha" maxlength="5" size="5" required="required" placeholder="Kode keamanan">
            </div>
          </div>
          <?php endif;?>
          <div class="login-actions">
            <button class="login-action btn btn-primary btn-lg btn-block" type="submit" name="submit" value="login">
              Masuk
            </button>
          </div>
        <?php echo form_close();?>
      </div>
    </div>
    <div class="login-extra">
      Tidak punya akun? <a href="<?php echo site_url('user/register'); ?>">Mendaftar</a>
      <br/>
      Ingatkan <a href="<?php echo site_url('user/forgot-password'); ?>">Kata Sandi</a>
    </div>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>">
    </script>
    <script src="<?php echo base_url('assets/js/jquery.app.js');?>"></script>
    <script src="<?php echo base_url('assets/js/notify.min.js');?>"></script>
    <script>
      $(document).ready(function(){
        $("[data-toggle='tooltip']").tooltip('show');
        <?php if ($this->session->get_flash_keys()):?>
        <?php foreach ($this->session->get_flash_keys() as $fk):?>
        $.notify("<?php echo strip_tags($this->session->flashdata($fk));?>", "<?php echo $fk;?>");
        <?php endforeach;?>
        <?php endif;?>
        <?php if (function_exists('validation_errors') && validation_errors()):?>
        <?php foreach (array_reverse($this->form_validation->error_array()) as $err):?>
        $.notify("<?php echo strip_tags($err);?>", "error");
        <?php endforeach;?>
        <?php endif;?>
      });
    </script>
  </body>
</html>