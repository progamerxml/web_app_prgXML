<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8"/>
    <title>
      Lupa Kata Sandi | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <link href="<?php echo base_url('assets/css/signin.css');?>" rel="stylesheet"/>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="account-container stacked">
      <div class="content">
        <?php echo form_open();?>
          <h1 style="font-size: 22px;margin-bottom: 15px;color: inherit">
            <i class="fa fa-lock"></i> Lupa Kata Sandi
          </h1>
          <div class="form-group">
            <input type="text" id="user_username" name="user_username" value="<?php echo set_value('user_username');?>" placeholder="Nama Pengguna" class="form-control input-lg username-field" maxlength="12"/>
          </div>
          <div class="form-group">
            <input type="email" id="user_email" name="user_email" value="<?php echo set_value('user_email');?>" placeholder="Email" class="form-control input-lg username-field" maxlength="255"/>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon" style="padding: 0;">
                <img src="<?php echo site_url('captcha');?>" style="" alt="Captcha"/>
              </span>
              <input type="text" class="form-control input-lg" name="captcha" id="captcha" maxlength="5" size="5" required="required" placeholder="Kode keamanan">
            </div>
          </div>
          <div class="login-actions">
            <button class="login-action btn btn-primary btn-lg btn-block" type="submit" name="submit" value="login">
              Kirim
            </button>
          </div>
        <?php echo form_close();?>
      </div>
    </div>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>">
    </script>
    <script src="<?php echo base_url('assets/js/notify.min.js');?>"></script>
    <script>
      $(document).ready(function(){
        $("[data-toggle='tooltip']").tooltip('show');
        <?php if ($this->session->get_flash_keys()):?>
        <?php foreach ($this->session->get_flash_keys() as $fk):?>
        $.notify("<?php echo strip_tags($this->session->flashdata($fk));?>", "<?php echo $fk;?>");
        <?php endforeach;?>
        <?php endif;?>
        <?php if (function_exists('validation_errors') && validation_errors()):?>
        <?php foreach (array_reverse($this->form_validation->error_array()) as $err):?>
        $.notify("<?php echo strip_tags($err);?>", "error");
        <?php endforeach;?>
        <?php endif;?>
      });
    </script>
  </body>

</html>