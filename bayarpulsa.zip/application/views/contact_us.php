<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      Hubungi Kami | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-sm-8">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-phone"></i> Hubungi Kami
              </h3>
            </div>
            <div class="panel-body">
              <?php echo form_open(current_url(),'class="form-horizontal"');?>
                <?php if ($trx_id):?>
                <div class="form-group">
                  <label for="nama" class="col-sm-2 control-label">
                    Komplain
                  </label>
                  <div class="col-sm-10">
                    <input type="hidden" name="trx_id" value="<?php echo $trx_id;?>" />
                    <input type="text" class="form-control" value="Transaksi #<?php echo $trx_id;?>" disabled="disabled" />
                  </div>
                </div>
                <?php endif;?>
                <div class="form-group">
                  <label for="nama" class="col-sm-2 control-label">
                    Nama
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" id="nama" maxlength="32" required="required" value="<?php echo set_value('nama', $this->user->is_user() ? $this->user->data['us_name'] : '');?>" <?php echo $this->user->is_user() ? ' disabled="disabled"' : '';?>/>
                  </div>
                </div>
                <div class="form-group">
                  <label for="no_hp" class="col-sm-2 control-label">
                    Nomor HP
                  </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="no_hp" id="no_hp" maxlength="14" placeholder="08xxxxxxxxxx" required="required" value="<?php echo set_value('no_hp', $this->user->is_user() ? $this->user->data['us_phone'] : '');?>"/>
                    <?php if ($trx_id):?>
                    <p class="help-block">Masukan nomor HP sesuai yang ada di data transaksi yang anda komplain</p>
                    <?php endif;?>
                  </div>
                </div>
                <div class="form-group">
                  <label for="pesan" class="col-sm-2 control-label">
                    Pesan
                  </label>
                  <div class="col-sm-10">
                    <textarea class="form-control" name="pesan" id="pesan" required="required" maxlength="160" rows="8"><?php echo set_value('pesan', $pesan);?></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label for="kode" class="col-sm-2 control-label">
                    Kode Keamanan
                  </label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon" style="padding: 0;">
                        <img src="<?php echo site_url('captcha');?>" style="" alt="Loading...."/>
                      </span>
                      <input type="text" class="form-control input-lg" name="captcha" id="v" maxlength="5" size="5" required="required" style="width: auto;">
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" name="submit" value="send" class="btn btn-primary">
                      <i class="fa fa-paper-plane-o"></i> Kirim
                    </button>
                  </div>
                </div>
              <?php echo form_close();?>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-map-marker">
                </i>
                Alamat
              </h3>
            </div>
            <div class="panel-body">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126933.05719128522!2d106.5799930239489!3d-6.176512298030374!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f8e853d2e38d%3A0x301576d14feb9c0!2sTangerang%2C+Kota+Tangerang%2C+Banten!5e0!3m2!1sid!2sid!4v1463841572371"
              width="100%" height="350" frameborder="0" style="border:0">
              </iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>