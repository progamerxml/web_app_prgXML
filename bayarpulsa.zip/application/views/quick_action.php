<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'):?>

<?php if (isset($title)):?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true">
      &times;
    </span>
  </button>
  <h4 class="modal-title">
    <?php echo $title;?>
  </h4>
</div>
<?php endif;?>
<div class="modal-body">
  <?php echo $content;?>
</div>
<?php else:?>
<?php
define('HIDE_SUBNAVBAR', true);
?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      <?php echo html_escape(isset($title) ? $title . ' | ' . $this->system->set['site_name'] : $this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH. 'includes/head.php'); ?>
    <style type="text/css">
      body {
      padding-top: 70px;
      }
    </style>
  </head>
  
  <body>
    <?php include_once(VIEWPATH. 'includes/navbar.php'); ?>
    <div class="container">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3>
            <?php echo (isset($title) ? $title : $this->system->set['site_name']);?>
          </h3>
        </div>
        <div class="panel-body">
          <div class="row">
            <div class="col-sm-offset-2 col-sm-8">
              <?php echo $content;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>
<?php endif;?>