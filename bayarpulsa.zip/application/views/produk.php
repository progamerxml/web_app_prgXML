<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      Order | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li class="active"><span>Produk</span></li>
      </ul>
      <div class="row">
        <?php
        foreach ($this->system->produk as $pr_key=>$pr_val):
        if ($pr_val->status == 'off')
          continue;
        $total = $this->produk_model->count($pr_key);
        ?>
          <div class="col-sm-4 col-md-3">
          <div class="panel panel-default">
            <div class="panel-heading" style="white-space: nowrap; overflow: hidden;">
              <h3 class="text-center text-uppercase">
                <?php echo $pr_val->nama . PHP_EOL;?>
              </h3>
            </div>
            <div style="margin: 0; padding: 0; height: 200px; position: relative; overflow: hidden;">
              <img src="<?php echo (file_exists(FCPATH.'assets/'.$pr_key.'.png') ? base_url('assets/'.$pr_key.'.png') : 'http://placehold.it/280x240');?>" class="img-responsive" style="margin: 0 auto;"/>
            </div>
            <ul class="list-group">
              <li class="list-group-item">Provider <span class="badge" data-toggle="tooltip" data-title="Jumlah provider" data-placement="left"><?php echo $total['providers'];?></span></li>
              <li class="list-group-item">Voucher <span class="badge" data-toggle="tooltip" data-title="Jumlah voucher" data-placement="left"><?php echo $total['vouchers'];?></span></li>
              <li class="list-group-item">Transaksi <span class="badge" data-toggle="tooltip" data-title="Jumlah transaksi sukses" data-placement="left"><?php echo $total['trx'];?></span></li>
            </ul>
            <div class="panel-body text-center">
              <a class="btn btn-primary btn-block" href="<?php echo site_url($pr_key);?>"><i class="fa fa-shopping-cart"></i> Order</a>
            </div>
          </div>
        </div>
        <?php endforeach;?>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>