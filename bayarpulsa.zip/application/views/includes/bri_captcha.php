<?php if ($captcha == 'data:image/png;base64,'):?>
<div class="alert alert-danger">
  Terjadi kesalahan!, silakan coba lagi.
</div>
<?php else:?>
<div class="alert alert-warning">
  Harap masukan kode keamanan berikut ini dengan benar!
</div>
<?php echo form_open();?>
  <div class="form-group text-center">
    <img src="<?php echo $captcha;?>"/>
  </div>
  <div class="input-group">
    <input type="number" class="form-control" name="captcha" value="" min="0001" max="9999"/>
    <span class="input-group-btn">
      <button type="submit" class="btn btn-primary">
        Kirim
      </button>
    </span>
  </div>
<?php echo form_close();?>
<?php endif;?>