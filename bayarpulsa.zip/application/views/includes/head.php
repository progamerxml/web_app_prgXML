<?php defined( 'BASEPATH') OR exit( 'No direct script access allowed'); ?>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="description" content="<?php echo isset($page_description) ? htmlentities($page_description) : ($this->config->item('page_description') ?  htmlentities($this->config->item('page_description')) : htmlentities(@$this->system->set['site_desc']));?>"/>
    <meta name="keywords" content="<?php echo isset($page_keywords) ? htmlentities($page_keywords) : ($this->config->item('page_keywords') ?  htmlentities($this->config->item('page_keywords')) : htmlentities(@$this->system->set['site_keywords']));?>"/>
    <meta name="msvalidate.01" content=""/>
    <meta name="google-site-verification" content=""/>
    <link rel="icon" href="<?php echo base_url('favicon.ico');?>" type="image/x-icon"/>
    <link rel="shortcut icon" href="<?php echo base_url('favicon.ico');?>" type="image/x-icon"/>
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet"/>
    <link href="<?php echo base_url('assets/css/bootstrap-theme.css');?>" rel="stylesheet"/>
    <link href="<?php echo base_url('assets/css/font-awesome.min.css');?>" rel="stylesheet"/>
    <link href="//fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet"/>
    <link href="<?php echo base_url('assets/css/custom.css');?>" rel="stylesheet"/>
    <style type="text/css">
      body {
      padding-top: <?php echo ($this->uri->segment(1) == 'admin' ? '70': '48'); ?>px;
      }
    </style>
    <script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>