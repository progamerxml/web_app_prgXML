    <!-- foot -->
    <div class="extra hidden-print">
      <div class="container">
        <div class="row">
          <div class="col-sm-3">
            <h4>
              About
            </h4>
            <ul>
              <li>
                <a href="<?php echo site_url('about');?>">Tentang Kami</a>
              </li>
              <li>
                <a href="https://twitter.com/achunk17" target="_blank">Twitter</a>
              </li>
              <li>
                <a href="https://facebook.com/achunks" target="_blank">Facebook</a>
              </li>
              <li>
                <a href="https://plus.google.com/+AchunkJealousMan" target="_blank">Google+</a>
              </li>
            </ul>
          </div>
          <div class="col-sm-3">
            <h4>
              Support
            </h4>
            <ul>
              <li>
                <a href="<?php echo site_url('contact_us');?>">Hubungi Kami</a>
              </li>
              <li>
                <a href="<?php echo site_url('faq');?>">Frequently Asked Questions</a>
              </li>
              <li>
                <a href="javascript:;">Video Tutorial</a>
              </li>
              <li>
                <a href="javascript:;">Feedback</a>
              </li>
            </ul>
          </div>
          <div class="col-sm-3">
            <h4>
              Legal
            </h4>
            <ul>
              <li>
                <a href="javascript:;">License</a>
              </li>
              <li>
                <a href="javascript:;">Terms of Use</a>
              </li>
              <li>
                <a href="javascript:;">Privacy Policy</a>
              </li>
              <li>
                <a href="javascript:;">Security</a>
              </li>
            </ul>
          </div>
          <div class="col-sm-3">
            <h4>
              Payments
            </h4>
            <div class="row">
              <div class="col-xs-6">
                <ul>
                  <li>
                    <a href="http://www.klikbca.com" target="_blank">Bank BCA</a>
                  </li>
                  <li>
                    <a href="https://ib.bankmandiri.co.id" target="_blank">Bank Mandiri</a>
                  </li>
                  <li>
                    <a href="https://ibank.bni.co.id" target="_blank">Bank BNI</a>
                  </li>
                  <li>
                    <a href="https://ib.bri.co.id" target="_blank">Bank BRI</a>
                  </li>
                </ul>
              </div>
              <div class="col-xs-6">
                <ul>
                  <li>
                    <a href="https://www.paypal.com" target="_blank">PayPal</a>
                  </li>
                  <li>
                    <a href="https://www.perfectmoney.is" target="_blank">Perfect Money</a>
                  </li>
                  <li>
                    <a href="https://www.fasapay.com/FP163805" target="_blank">FasaPay</a>
                  </li>
                  <li>
                    <a href="https://www.bitcoin.co.id" target="_blank">Bitcoin</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /container -->
    </div>
    <div class="footer hidden-print">
      <div class="container">
        <div class="row">
          <div id="footer-copyright" class="col-md-6">
            <span style="line-height: 34px;">
              &copy; <?php echo date('Y');?> <a href="<?php echo site_url();?>"><?php echo html_escape($this->system->set['site_name']) . PHP_EOL;?></a>
            </span>
          </div>
          <!-- /span6 -->
          <div id="footer-terms" class="col-md-6">
            <ul class="list-inline pull-right">
                <li>
                  <a href="https://facebook.com/achunks"><i class="fa fa-facebook"></i></a>
                </li>
                <li>
                  <a href="https://twitter.com/achunk17"><i class="fa fa-twitter"></i></a>
                </li>
                <li>
                  <a href="https://www.linkedin.com/in/achunk17"><i class="fa fa-linkedin"></i></a>
                </li>
                <li>
                  <a href="https://plus.google.com/+AchunkJealousMan"><i class="fa fa-google-plus"></i></a>
                </li>
                <li>
                  <!-- Jangan Hapus Copyright ini --><a href="http://w38s.com" target="_blank"><i class="fa fa-copyright"></i></a>
                </li>
              </ul>
          </div>
          <!-- /.span6 -->
        </div>
        <!-- /row -->
      </div>
      <!-- /container -->
    </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal-label" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="margin-bottom margin-top text-center">
            <img src="<?php echo base_url('assets/ajax-loader.gif'); ?>" alt="loading"/>
          </div>
        </div>
      </div>
    </div>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>">
    </script>
    <script src="<?php echo base_url('assets/js/notify.min.js');?>"></script>
    <?php if ($this->session->get_flash_keys()):?>
    <script>
      $(document).ready(function(){
        <?php foreach ($this->session->get_flash_keys() as $fk):?>
        $.notify("<?php echo strip_tags($this->session->flashdata($fk));?>", "<?php echo $fk;?>");
        <?php endforeach;?>
      });
    </script>
    <?php endif;?>
    <?php if (function_exists('validation_errors') && validation_errors()):?>
    <script>
      $(document).ready(function(){
        $.notify.defaults({autoHideDelay:10000});
        <?php foreach (array_reverse($this->form_validation->error_array()) as $err):?>
        $.notify("<?php echo strip_tags($err);?>", "error");
        <?php endforeach;?>
      });
    </script>
    <?php endif;?>
    <script type="text/javascript">
      jQuery(function($) {
        $(document.body).on("show.bs.modal", function() {
          $(".modal-content").html('<div class="text-center" style="padding:15px;"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>');
          $(".modal").removeData("bs.modal");
        });
        $("[data-toggle='tooltip']").tooltip();
        $("[data-toggle='popover']").popover();
        var backToTop = $('<a>', { id: 'back-to-top', href: '#top' });
		var icon = $('<i>', { class: 'fa fa-chevron-up' });
		backToTop.appendTo ('body');
		icon.appendTo (backToTop);
	    backToTop.hide();
	    $(window).scroll(function () {
	        if ($(this).scrollTop() > 150) {
	            backToTop.fadeIn ();
	        } else {
	            backToTop.fadeOut ();
	        }
	    });
	    backToTop.click (function (e) {
	    	e.preventDefault ();
	        $('body, html').animate({
	            scrollTop: 0
	        }, 600);
	    });
        $('button[data-target=".subnav-collapse"]').click (function (e) {
	    	e.preventDefault ();
            $('body, html').animate({
	            scrollTop: 0
	        }, 600);           
	    });
        $("#alert").fadeTo(2000, 500).slideUp(500, function() {
            $(this).alert('close');
        });
        $('.subnav-collapse > .mainnav > li.dropdown > a[data-toggle="dropdown-x"]').on('click', function (event) {
            $('.subnav-collapse > .mainnav > .dropdown.open').not($(this).parent()).removeClass('open');
            $(this).parent().toggleClass('open');
            return false;
        });
      });
    </script>
    <script>
      function callCron() {
        $.get("<?php echo site_url('cron');?>");
      }
      var cron_time = <?php echo ($this->session->has_userdata('call_cron') ? 15000: 30000);?>;
callCron();
setInterval(callCron, cron_time);
    </script>
