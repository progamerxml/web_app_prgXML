<?php defined( 'BASEPATH') OR exit( 'No direct script access allowed'); ?>
    <nav class="navbar navbar-inverse navbar-fixed-top hidden-print" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".subnav-collapse" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="fa fa-user">
            </span>
          </button>
          <a class="navbar-brand" href="<?php echo site_url(); ?>"><img src="<?php echo base_url('assets/logo.png');?>" style="margin-top:-7px; height: 32px" alt="logo"/></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <li>
              <a href="tel:081234567890"><i class="fa fa-phone"></i> 081234567890</a>
            </li>
            <li>
              <a href="whatsapp://send?text=081234567890"><i class="fa fa-whatsapp"></i> 081234567890</a>
            </li>
            <li>
              <a href="ymsgr:sendim?yahoo_id"><i class="fa fa-smile-o"></i> yahoo_id</a>
            </li>
            <li>
              <a href="mailto:support@domain.tld"><i class="fa fa-envelope-o"></i> support@domain.tld</a>
            </li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <?php if (!$this->user->is_user()):?>
            <li>
              <a href="<?php echo site_url('user/login');?>"><i class="fa fa-sign-in"></i> Masuk</a>
            </li>
            <?php if ($this->system->perm->allow_reguser == 'yes'):?>
            <li>
              <a href="<?php echo site_url('user/register');?>"><i class="fa fa-user-plus"></i> Mendaftar</a>
            </li>
            <?php endif;?>
            <?php else:?>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-user"></i>
              <?php echo html_escape($this->user->data['us_name']) . ($this->user->count_notifications() ? ' <span class="label label-danger" style="border-radius: 15px">'.($this->user->count_notifications() > 100 ? $this->user->count_notifications().'+' : $this->user->count_notifications()).'</span>' : '');?>
              <b class="caret"></b>
              </a>
              <ul class="dropdown-menu">
                <li class="<?php echo $this->uri->segment(1) == 'akun' && $this->uri->segment(2) == 'index' ? 'active' : '';?>">
                  <a href="<?php echo site_url('akun/profil');?>"><i class="fa fa-user"></i> Profil</a>
                </li>
                <li class="<?php echo $this->uri->segment(1) == 'akun' && $this->uri->segment(2) == 'notifikasi' ? 'active' : '';?>">
                  <a href="<?php echo site_url('akun/notifikasi');?>"><?php echo ($this->user->count_notifications() ? '<span class="label label-danger pull-right" style="border-radius: 15px">'.$this->user->count_notifications().'</span>' : '');?><i class="fa fa-bell"></i> Pemberitahuan</a>
                </li>
                <li class="<?php echo $this->uri->segment(1) == 'akun' && $this->uri->segment(2) == 'riwayat-transaksi' ? 'active' : '';?>">
                  <a href="<?php echo site_url('akun/riwayat-transaksi');?>"><i class="fa fa-history"></i> Riwayat Transaksi</a>
                </li>
                <?php if ($this->system->perm->allow_deposit == 'yes'):?>
                <li class="<?php echo $this->uri->segment(1) == 'akun' && $this->uri->segment(2) == 'deposit' ? 'active' : '';?>">
                  <a href="<?php echo site_url('akun/deposit');?>"><i class="fa fa-money"></i> Deposit</a>
                </li>
                <?php endif;?>
                <li class="<?php echo $this->uri->segment(1) == 'akun' && $this->uri->segment(2) == 'riwayat-saldo' ? 'active' : '';?>">
                  <a href="<?php echo site_url('akun/riwayat-saldo');?>"><i class="fa fa-credit-card"></i> Mutasi Saldo</a>
                </li>
                <li class="<?php echo $this->uri->segment(1) == 'akun' && $this->uri->segment(2) == 'settings' ? 'active' : '';?>">
                  <a href="<?php echo site_url('akun/pengaturan');?>"><i class="fa fa-cogs"></i> Pengaturan</a>
                </li>
                <?php if ($this->user->is_admin()):?>
                <li>
                  <a href="<?php echo site_url('admin');?>"><i class="fa fa-shield"></i> Admin Panel</a>
                </li>
                <?php endif;?>
                <li class="divider">
                </li>
                <li>
                  <a href="<?php echo site_url('user/logout');?>"><i class="fa fa-sign-out"></i> Keluar</a>
                </li>
              </ul>
            </li>
            <?php endif;?>
          </ul>
        </div>
      </div>
    </nav>
    <?php if ($this->uri->segment(1) != 'user' && !defined('HIDE_SUBNAVBAR')):?>
    <div class="subnavbar hidden-print">
      <div class="subnavbar-inner">
        <div class="container">
          <div class="collapse subnav-collapse">
            <ul class="mainnav">
              <li class="<?php echo $this->uri->segment(1) == 'home' && $this->uri->segment(2) == 'index' ? 'active' : '';?>">
                <a href="<?php echo site_url();?>">
                <i class="fa fa-home"></i>
                <span>Beranda</span>
                </a>
              </li>
              <li class="dropdown <?php echo $this->uri->segment(1) == 'order' ? 'active' : '';?>">
                <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown-x">
                  <i class="fa fa-shopping-cart"></i>
                  <span>Order</span>
                  <b class="caret"></b>
                </a>
                <ul class="dropdown-menu">
                  <?php foreach ($this->system->produk as $pr_key=>$pr_val):?>
                  <?php if ($pr_val->status == 'on'):?>
                  <li>
                    <a href="<?php echo site_url(str_replace('_','-',$pr_key));?>"><?php echo $pr_val->nama;?></a>
                  </li>
                  <?php endif;?>
                  <?php endforeach;?>
                </ul>
              </li>
              <li class="<?php echo $this->uri->segment(1) == 'history' ? 'active' : '';?>">
                <a href="<?php echo site_url('history');?>">
                <i class="fa fa-history"></i>
                <span>Riwayat</span>
                </a>
              </li>
              <li class="<?php echo $this->uri->segment(1) == 'harga' ? 'active' : '';?>">
                <a href="<?php echo site_url('harga');?>">
                <i class="fa fa-money"></i>
                <span>Harga</span>
                </a>
              </li>
              <li class="<?php echo $this->uri->segment(1) == 'testimonial' ? 'active' : '';?>">
                <a href="<?php echo site_url('testimonial');?>">
                <i class="fa fa-comments"></i>
                <span>Testimonial</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <?php endif;?>

