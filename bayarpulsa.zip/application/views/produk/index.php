<?php
defined('BASEPATH') or exit('No direct script access allowed');
define('HIDE_SUBNAVBAR', true);
if ($produk && $operator) {
    $title = $this->system->produk->$produk->nama.' '.$operator->op_nama;
    if ($operator->op_description)
        $page_description = $operator->op_description;
    elseif ($this->system->produk->$produk->description)
        $page_description = $this->system->produk->$produk->description;
    else
        $page_description = $this->system->get_set('site_desc');
} elseif ($produk && !$operator) {
    $title = $this->system->produk->$produk->nama;
    if ($this->system->produk->$produk->description)
        $page_description = $this->system->produk->$produk->description;
    else
        $page_description = $this->system->get_set('site_desc');
} else {
    $title = 'Produk';
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title><?php echo html_escape($title);?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">body{padding-top:70px;}
    .label {font-size: 12px;font-weight: 400;line-height: 1.25;display: inline-block;height: 20px;border-radius: 0;}
    .label.arrowed {position: relative;z-index: 1;display: inline-block;height: 20px;margin-left: 5px;}
    .label.arrowed:before {position: absolute;z-index: -1;top: 0;left: -10px;display: inline-block;content: '';border: 1px solid transparent;border-width: 10px 5px;}
    .label.arrowed-right {position: relative;z-index: 1;display: inline-block;height: 20px;margin-right: 5px;}
    .label.arrowed-right:after {position: absolute;z-index: -1;top: 0;right: -10px;display: inline-block;content: '';border: 1px solid transparent;border-width: 10px 5px;}
    .label-default.arrowed:before {border-right-color: #777;}
    .label-default.arrowed-right:after {border-left-color: #777;}
    .label-primary.arrowed:before {border-right-color: #337ab7;}
    .label-primary.arrowed-right:after {border-left-color: #337ab7;}
    .label-success.arrowed:before {border-right-color: #5cb85c;}
    .label-success.arrowed-right:after {border-left-color: #5cb85c;}
    .label-info.arrowed:before {border-right-color: #5bc0de;}
    .label-info.arrowed-right:after {border-left-color: #5bc0de;}
    .label-warning.arrowed:before {border-right-color: #f0ad4e;}
    .label-warning.arrowed-right:after {border-left-color: #f0ad4e;}
    .label-danger.arrowed:before {border-right-color: #d9534f;}
    .label-danger.arrowed-right:after {border-left-color: #d9534f;}
    .box-product-outer {margin-bottom: 15px;border-radius: 0;}
    .box-product {padding: 15px;background-color: #fff;border: 1px solid #ddd;}
    .box-product .img-wrapper {margin: -15px -15px 0;position: relative;overflow: hidden;}
    .box-product .img-wrapper > :first-child {position: relative;display: block;}
    .box-product .img-wrapper > a > img {width: 100%;}
    .box-product .img-wrapper .tags {position: absolute;top: 0;right: 0;display: table;overflow: visible;width: auto;height: auto;margin: 0;padding: 0;vertical-align: inherit;border-width: 0;background-color: transparent;direction: rtl;}
    .box-product .img-wrapper .tags > .label-tags {display: table;margin: 0 -1px 1px 0;text-align: left;opacity: .80;filter: alpha(opacity=80);direction: ltr;}
    .box-product .img-wrapper .tags > .label-tags a{white-space: nowrap;overflow: hidden;color: #fff;text-decoration: none;}
    .box-product .img-wrapper .tags > .label-tags:hover {opacity: 1;filter: alpha(opacity=100);}
    .box-product .img-wrapper .tags > .label-tags a:hover {text-decoration: none;}
    .box-product .img-wrapper .tags-left {left: 0;direction: ltr;}
    .box-product .img-wrapper > .option {position: absolute;top: auto;right: 0;bottom: -30px;left: 0;width: auto;height: 28px;-webkit-transition: all 0.2s ease;-o-transition: all 0.2s ease;transition: all 0.2s ease;text-align: center;vertical-align: middle;border-radius: 0;background-color: rgba(0, 0, 0, 0.55);}
    .box-product .img-wrapper > .option > a {font-size: 13px;margin-top: 5px;font-weight: normal;display: inline-block;padding: 0 4px;color: #fff;text-decoration: none;}
    .box-product .img-wrapper > .option > a:hover {color: #9E9E9E;}
    .box-product .img-wrapper > .option > a.wishlist:hover {color: #ef5350;}
    .box-product .title-wrapper{padding: 0;margin-top: 10px;height: 40px;overflow: hidden;}
    .box-product .title-wrapper h6 a {font-size: 13px;line-height: 1.4;display: block;}
    .box-product:hover .img-wrapper > .option {bottom: 0;}
    .price {margin-bottom: 5px;color: #ef5350;}
    .price-old {position: relative;display: inline-block;margin-right: 7px;color: #666;}
    .price-old:before {position: absolute;width: 100%;height: 60%;content: '';border-bottom: 1px solid #666;}
    .rating i {color: #ffc107;}
    .box-product:hover {-webkit-box-shadow:0 10px 20px rgba(0,0,0,.19),0 6px 6px rgba(0,0,0,.23);box-shadow:0 10px 20px rgba(0,0,0,.19),0 6px 6px rgba(0,0,0,.23)}
    .title {font-size: 18px;line-height: 1;margin: 0 0 15px;padding: 0;border-bottom: 3px solid #ffdf7e;}
    .title span {display: inline-block;margin-bottom: -3px;padding-bottom: 10px;color: #666;border-bottom: 3px solid #f90;}
    @media (max-width: 480px) {
      .box-product-outer:hover {border-color: transparent;background-color: transparent;}
      .box-product .img-wrapper > .option {bottom: 0;}
    }
</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <?php if ($produk && $operator):?>
        <li><a href="<?php echo site_url('produk');?>">Produk</a></li>
        <li><a href="<?php echo site_url('produk/'.str_replace('_','-',$produk));?>"><?php echo html_escape($this->system->produk->$produk->nama);?></a></li>
        <li class="active"><span><?php echo html_escape($operator->op_nama);?></span></li>
        <?php elseif ($produk && !$operator):?>
        <li><a href="<?php echo site_url('produk');?>">Produk</a></li>
        <li class="active"><span><?php echo html_escape($this->system->produk->$produk->nama);?></span></li>
        <?php else:?>
        <li class="active"><span>Produk</span></li>
        <?php endif;?>
      </ul>
      <div class="row">
        <div class="col-sm-3">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-tags"></i> Produk</h3>
            </div>
            <?php
            $out = '';
            foreach ($this->system->produk as $produk_key => $produk_val) {
              $providers = $this->produk_model->get_providers($produk_key);
              if ($produk_val->status == 'off' || !$providers)
                continue;
              $out.='<a class="list-group-item produk-heading'.($produk == $produk_key && !$operator ? ' activeX' : '').'" href="#" id="'.$produk_key.'"><h4 style="font-size:14px;font-weight:bold;margin:0"><span class="caret pull-right" style="margin-top:5px"></span>'.@$produk_val->mini_icon.' '.html_escape(strtoupper($produk_val->nama)).'</h4></a>';
              foreach ($providers as $provider) {
                $out.='<a class="list-group-item list-'.$produk_key . ($produk == $produk_key && ($operator && $operator->op_slug == $provider->op_slug) ? ' active' : '').'" href="'.site_url('produk/'.str_replace('_','-',$produk_key).'/'.$provider->op_slug).'" style="display:'.($produk == $produk_key ? 'block' : 'none').'">&nbsp;&nbsp;&raquo; '.html_escape($provider->op_nama).'</a>';
              }
              $out.='<a class="list-group-item list-'.$produk_key . ($produk == $produk_key && !$operator ? ' active' : '').'" href="'.site_url('produk/'.str_replace('_','-',$produk_key)).'" style="display:'.($produk == $produk_key ? 'block' : 'none').'">&nbsp;&nbsp;&raquo; Tampilkan Semua</a>';
            }
            if ($out) {
                echo '<div class="list-group">'.$out.'</div>';
            }
            else {
                echo '<div class="panel-body">Tidak ada daftar</div>';
            }
            ?>
          </div>
        </div>
        <div class="col-sm-9" id="content">
          <?php if ($title != 'Produk'):?>
          <h1 class="title"><span><?php echo ($produk ? @$this->system->produk->$produk->mini_icon.' ' : '') . html_escape($title); ?></span></h1>
          <?php endif;?>
          <div class="well well-sm" style="padding-bottom: 0;">
            <div class="row">
              <div class="col-sm-6 col-md-4" style="margin-bottom: 9px;">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-sort"></i> Urutkan</span>
                  <select class="form-control" onChange="window.location.href=this.value">
                    <option value="<?php echo site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/terbaru/1'.($search ? '?search='.urlencode($search) : ''));?>"<?php echo $sort == 'terbaru' ? ' selected="selected"' : '';?>>Terbaru</option>
                    <option value="<?php echo site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/termurah/1'.($search ? '?search='.urlencode($search) : ''));?>"<?php echo $sort == 'termurah' ? ' selected="selected"' : '';?>>Termurah</option>
                    <option value="<?php echo site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/termahal/1'.($search ? '?search='.urlencode($search) : ''));?>"<?php echo $sort == 'termahal' ? ' selected="selected"' : '';?>>Termahal</option>
                    <option value="<?php echo site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/transaksi-terbanyak/1'.($search ? '?search='.urlencode($search) : ''));?>"<?php echo $sort == 'transaksi-terbanyak' ? ' selected="selected"' : '';?>>Transaksi Terbanyak</option>
                    <option value="<?php echo site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/testimonial-terbanyak/1'.($search ? '?search='.urlencode($search) : ''));?>"<?php echo $sort == 'testimonial-terbanyak' ? ' selected="selected"' : '';?>>Testimonial Terbanyak</option>
                  </select>
                </div>
              </div>
              <div class="col-sm-6 col-md-8" style="margin-bottom: 9px;">
                <form method="get" action="<?php echo site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/'.$sort.'/1');?>">
                  <div class="input-group">
                    <input type="text" class="form-control" name="search" value="<?php echo html_escape($search);?>" placeholder="Pencarian..." />
                    <span class="input-group-btn">
                      <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php if ($search && $page == 1):?>
          <div class="alert alert-info alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Menampilkan hasil pencarian: <strong><?php echo html_escape($search);?></strong></div>
          <?php endif;?>
          <?php if (!$results):?>
          <div class="alert alert-warning">Tidak ada data</div>
          <?php else:?>
          <div class="row" style="margin-bottom: 15px;">
            <?php $i = 1; foreach ($results as $result):?>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 <?php echo (($i % 4) == 0 ? 'hidden-md' : '');?> box-product-outer">
            <div class="box-product">
              <div class="img-wrapper">
                <a href="<?php echo $link = site_url('produk/'.str_replace('_','-',$result->op_produk).'/'.$result->op_slug.'/'.str_link($result->vo_nominal).'-'.$result->vo_id);?>">
                  <img alt="<?php echo html_escape($result->vo_nominal);?>" data-src="<?php echo $this->produk_model->get_thumbnail($result->op_produk,$result->vo_image);?>"/>
                </a>
                <div class="tags">
                  <span class="label-tags"><span class="label label-info arrowed"><a href="<?php echo site_url('produk/'.str_replace('_','-',$result->op_produk).'/'.$result->op_slug);?>" title="<?php echo html_escape($result->op_nama);?>"><?php echo html_escape($result->op_nama);?></a></span></span>
                </div>
                <div class="tags tags-left">
                  <span class="label-tags"><span class="label label-primary arrowed-right"><a href="<?php echo site_url('produk/'.str_replace('_','-',$result->op_produk));?>" title="<?php echo html_escape($this->system->produk->{$result->op_produk}->nama);?>"><?php echo $this->system->produk->{$result->op_produk}->mini_icon;?></a></span></span>
                </div>
                <div class="option">
                  <a href="<?php echo $link;?>#order"><i class="fa fa-shopping-cart"></i> Beli Sekarang</a>
                </div>
              </div>
              <div class="title-wrapper">
                <h6><a title="<?php echo html_escape($result->vo_nominal);?>" href="<?php echo $link;?>"><?php echo html_escape($result->vo_nominal);?></a></h6>
              </div>
              <div class="price">
                <div><?php echo format_uang2($this->user->is_reseller ? $result->vo_harga_reseller : $result->vo_harga);?></div>
              </div>
              <div class="rating">
                <a href="<?php echo $link;?>#riwayat"><?php echo $result->total_transaksi;?> transaksi</a> / <a href="<?php echo $link;?>#testimonial"><?php echo $result->total_testimonial;?> testimonial</a>
              </div>
            </div>
          </div>
          <?php if (($i % 4) == 0):?>
          <div class="clearfix"></div>
          <?php elseif (($i % 2) == 0):?>
          <div class="clearfix visible-xs visible-sm"></div>
          <?php endif;?>
            <?php ++$i; endforeach;?>
          </div>
          <?php
          $pager = pagination(site_url('produk/'.($produk ? ($operator ? $produk.'/'.$operator->op_slug : str_replace('_','-', $produk)) : 'index').'/'.$sort), $start, $total, $this->system->set['list_per_page'],'/%d'.($search ? '?search='.urlencode($search) : '').'#content');
          echo $pager ? '<div class="pull-right" style="margin-bottom:15px">'.$pager.'</div><div class="clearfix"></div>' : '';
          ?>
          <?php endif;?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script src="<?php echo base_url('assets/js/lazyload.min.js');?>"></script>
    <script>
      var myLazyLoad = new LazyLoad();
    </script>
    <script>$(".produk-heading").click(function(){var produk = $(this).attr("id");$(".list-"+produk).toggle(400);return false;})</script>
  </body>

</html>