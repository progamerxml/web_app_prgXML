<?php

defined('BASEPATH') or exit('No direct script access allowed');
define('HIDE_SUBNAVBAR', true);

// Ditambahkan di v3.7.0
if ($this->user->is_reseller)
    $this->system->produk->{$voucher->op_produk}->payments[] = 'balance';

$reseller_config = json_decode($this->system->get_set('reseller'));
$data_payments = array();
$payment_active = '';
$payment_inactive = '';
foreach ($this->payment->get() as $payment) {
    if ($payment->status == 'off')
        continue;
    elseif ($this->user->is_reseller && $reseller_config->payment == 'balance' && $payment->key != 'balance')
        $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member)</option>';
    elseif ($payment->user == 1 && !$this->user->is_user())
        $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member)</option>';
    elseif ($payment->user == 2 && !$this->user->verified)
        $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member terverifikasi)</option>';
    elseif (!in_array($payment->key, $this->system->produk->{$voucher->op_produk}->payments))
        $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Tidak diijinkan)</option>';
    elseif ($this->payment->is_offline($payment->key)) // Ditambahkan di v3.7.0
        $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Offline)</option>';
    else
        $payment_active .= '<option value="' . $payment->key . '">' . $payment->nama . '</option>';
    $data_payments[$payment->key] = array(
        'nama' => $payment->nama,
        'template' => $payment->template,
        'rate' => (int)@$payment->rate,
        'round'=> (int)@$payment->round,
    );
}
$title = html_escape($this->system->produk->{$voucher->op_produk}->nama.' '.$voucher->op_nama.' - '.$voucher->vo_nominal);
$payment_html = $payment_active . $payment_inactive;
$page_description = 'Jual '.$this->system->produk->{$voucher->op_produk}->nama.' '.$voucher->op_nama.' - '.$voucher->vo_nominal .' hanya seharga '.format_uang2($voucher->vo_harga);
if ($voucher->vo_description)
  $page_description = ' '.substr(strip_tags($voucher->vo_description), 0, 200);
$images = $voucher->vo_image ? json_decode($voucher->vo_image, true) : array();
?>
<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $title;?></title>
    <meta property="og:title" content="<?php echo $title;?>"/>
    <meta property="og:image" content="<?php echo isset($images[0]) ? base_url('images/produk/'.$voucher->op_produk.'/'.$images[0]) : base_url('images/produk/default.png');?>"/>
    <meta property="og:description" content="<?php echo($page_description);?>"/>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">
    body{padding-top:70px;}
    #content,#content-left,#content-right,#image,#content-right>h1,.nav-tabs{margin-bottom: 15px;}
    .input-group-addon i{width: 12px;text-align: center;}
    .img-thumbnail.active{border-color: #337ab7;}
    #image {text-align: center;}
    #image img{margin: 0 auto;overflow: hidden;}
    .social-share{margin-bottom: 40px;}
    .social-share ul li{float:left;margin-right:10px;}
    .social-share ul li a{display:inline-block;padding:4px 12px;font-size:12px;color:#FFF;}
    .social-share ul li a.facebook{background: #5b79b4;}
    .social-share ul li a.facebook:hover{background: #4565a3;}
    .social-share ul li a.twitter{background: #2fccf7;}
    .social-share ul li a.twitter:hover{background: #1db9e3;}
    .social-share ul li a.gplus{background: #ed492a;}
    .social-share ul li a.gplus:hover{background: #d33416;}
    .social-share ul li a i{border-right: 1px solid #FFF;padding-right:6px;margin-right:6px;}
    </style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('produk');?>">Produk</a></li>
        <li><a href="<?php echo site_url('produk/'.str_replace('_','-',$voucher->op_produk));?>"><?php echo html_escape($this->system->produk->{$voucher->op_produk}->nama);?></a></li>
        <li><a href="<?php echo site_url('produk/'.str_replace('_','-',$voucher->op_produk).'/'.$voucher->op_slug);?>"><?php echo html_escape($voucher->op_nama);?></a></li>
        <li class="active"><span><?php echo html_escape($voucher->vo_nominal);?></span></li>
      </ul>
      <div class="row">
        <div class="col-sm-8" id="content">
          <div class="panel panel-default">
            <div class="panel-body">
              <div class="row">
                <div id="content-left" class="col-sm-6 col-lg-4">
                  <div id="image"><a href="#"><img id="produk-image" class="img-thumbnail" src="<?php echo isset($images[0]) ? base_url('images/produk/'.$voucher->op_produk.'/'.$images[0]) : base_url('images/produk/default.png');?>" alt="<?php echo $title;?>" title="<?php echo $title;?>"/></a></div>
                  <?php if ($images):?>
                  <div class="row" id="images">
                    <?php for ($i = 0; $i < count($images); $i++):?>
                    <div class="col-xs-4">
                      <a href="#" data-image="<?php echo $images[$i];?>"><img src="<?php echo base_url('images/produk/'.$voucher->op_produk.'/thumb-'.$images[$i]);?>" class="img-thumbnail <?php echo $i == 0 ? 'active' : '';?>"/></a>
                    </div>
                    <?php endfor;?>
                  </div>
                  <?php endif;?>
                </div>
                <div id="content-right" class="col-sm-6 col-lg-8">
                  <h1 style="font-size: 20px;"><?php if ($this->user->is_admin()):?><a href="<?php echo site_url('admin/produk/edit_voucher/'.$voucher->vo_id.'/1');?>" class="pull-right" data-toggle="tooltip" data-title="Edit"><i class="fa fa-edit"></i></a><?php endif;?><?php echo @$this->system->produk->{$voucher->op_produk}->mini_icon.' '. html_escape($voucher->op_nama.' - '.$voucher->vo_nominal);?></h1>
                  <hr/>
                  <ul class="list-unstyled">
                    <li><h3 style="font-size: 17px;font-weight: bold;"><?php echo format_uang2($this->user->is_reseller ? $voucher->vo_harga_reseller : $voucher->vo_harga);?></h3></li>
                    <li><strong>Produk:</strong> <a href="<?php echo site_url('produk/'.str_replace('_','-',$voucher->op_produk));?>"><span><?php echo html_escape($this->system->produk->{$voucher->op_produk}->nama);?></span></a></li>
				    <li><strong><?php echo $this->system->produk->{$voucher->op_produk}->form->provider->label;?>:</strong> <a href="<?php echo site_url('produk/'.str_replace('_','-',$voucher->op_produk).'/'.$voucher->op_slug);?>"><span><?php echo html_escape($voucher->op_nama);?></span></a></li>
				    <li><strong><?php echo $this->system->produk->{$voucher->op_produk}->form->voucher->label;?>:</strong> <span><?php echo html_escape($voucher->vo_nominal);?></span></li>
				    <li><strong>Stok:</strong> <?php echo ($voucher->vo_status == 1 ? '<span>Tersedia</span>' : '<span class="text-dager">Tidak Tersedia</span>');?></li>
                  </ul>
                  <div class="social-share">
                    <ul class="list-unstyled">
                      <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(current_url());?>" target="_blank" class="facebook"><i class="fa fa-facebook fa-lg"></i>Facebook</a></li>
                      <li><a href="https://twitter.com/home?status=<?php echo urlencode(current_url());?>" target="_blank" class="twitter"><i class="fa fa-twitter fa-lg"></i>Twitter</a></li>
                      <li><a href="https://plus.google.com/share?url=<?php echo urlencode(current_url());?>" target="_blank" class="gplus"><i class="fa fa-google-plus fa-lg"></i>Google+</a></li>
                    </ul>
                  </div>
                  <div class="clearfix"></div>
                </div>
                <div class="col-sm-12">
                  <ul class="nav nav-tabs" role="tablist" style="margin-top: 5px;">
                    <li role="presentation" class="active"><a href="#deskripsi" aria-controls="deskripsi" role="tab" data-toggle="tab">Deskripsi</a></li>
                    <li role="presentation"><a href="#riwayat" aria-controls="riwayat" role="tab" data-toggle="tab">Riwayat (<?php echo $total_riwayat;?>)</a></li>
                    <li role="presentation"><a href="#testimonial" aria-controls="testimonial" role="tab" data-toggle="tab">Testimonial (<?php echo $total_testimonial;?>)</a></a></li>
                  </ul>
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="deskripsi">
                      <?php echo $voucher->vo_description ? $voucher->vo_description : html_escape($voucher->vo_nominal);?>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="riwayat">
                      <?php if (!$riwayat):?>
                      <div class="alert alert-warning" style="margin-bottom: 0;">Tidak ada riwayat transaksi</div>
                      <?php else:?>
                      <?php if ($total_riwayat > 10):?>
                      <div class="alert alert-info alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Menampilkan 10 riwayat transaksi terakhir.</div>
                      <?php endif;?>
                      <div class="table-responsive">
                        <table class="table table-striped" style="margin-bottom: 0;">
                          <thead>
                            <tr>
                              <th>Tanggal</th>
                              <th><?php echo property_exists($this->system->produk->{$voucher->op_produk}->form,'id_plgn') ? $this->system->produk->{$voucher->op_produk}->form->id_plgn->label : 'No. Telepon';?></th>
                              <th>Pembayaran</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php foreach ($riwayat as $trx):?>
                            <tr>
                              <td><a href="<?php echo site_url('history/view/'.$trx->tr_id);?>" target="_blank"><?php echo format_tanggal($trx->tr_tanggal);?></a></td>
                              <td><?php echo $trx->tr_id_plgn ? 'XXX'.substr($trx->tr_id_plgn,3,-3).'XXX' : substr($trx->tr_no_hp, 0, -3).'XXX';?></td>
                              <td><?php echo $this->payment->{$trx->tr_pembayaran}->nama;?></td>
                              <td><?php echo status_label($trx, 0, false);?></td>
                            </tr>
                            <?php endforeach;?>
                          </tbody>
                        </table>
                      </div>
                      <?php endif;?>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="testimonial">
                      <?php if (!$testimonial):?>
                      <div class="alert alert-warning" style="margin-bottom: 0;">Tidak ada testimonial</div>
                      <?php else:?>
                      <?php if ($total_testimonial > 10):?>
                      <div class="alert alert-info alert-dismissible fade in" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Menampilkan 10 testimonial terakhir.</div>
                      <?php endif;?>
                      <ul class="list-group" style="margin-bottom: 0;">
                        <?php foreach ($testimonial as $testi):?>
                        <li class="list-group-item " id="testi-1">
                          <div class="list-group-item-heading">
                            <span class="text-muted pull-right"><small><i class="fa fa-clock-o"></i> <?php echo format_tanggal($testi->tanggal);?></small></span>
                            <?php echo ($this->user->is_admin() ? '<a href="'.site_url('admin/users/profil/'.$testi->us_id).'"><strong><i class="fa fa-user"></i> '.html_escape($testi->nama).'</a></strong>' : '<strong><i class="fa fa-user"></i> '.html_escape($testi->nama).'</strong>');?>&nbsp;
                          </div>
                          <div class="list-group-item-text"><?php echo nl2br(html_escape($testi->pesan));?></div>
                        </li>
                        <?php endforeach;?>
                      </ul>
                      <?php endif;?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <div class="panel panel-default" id="order">
            <div class="panel-heading">
              <h3><i class="fa fa-shopping-cart"></i> Beli <?php echo html_escape($this->system->produk->{$voucher->op_produk}->nama);?></h3>
            </div>
            <div class="panel-body">
              <?php echo form_open($voucher->op_produk,'id="order_form"');?>
                <!--<div class="form-group">
                  <label class="sr-only1"><?php echo $this->system->produk->{$voucher->op_produk}->form->provider->label;?></label>
                  <input class="form-control" value="<?php echo html_escape($voucher->op_nama);?>" readonly="readonly" />
                </div>
                <div class="form-group">
                  <label class="sr-only1"><?php echo $this->system->produk->{$voucher->op_produk}->form->voucher->label;?></label>
                  <input class="form-control" value="<?php echo html_escape($voucher->vo_nominal);?>" readonly="readonly" />
                </div>-->
                <?php if (property_exists($this->system->produk->{$voucher->op_produk}->form, 'id_plgn')):?>
                <div class="form-group">
                  <label class="sr-only1"><?php echo $this->system->produk->{$voucher->op_produk}->form->id_plgn->label;?></label>
                  <input class="form-control" name="id_plgn" maxlength="16" placeholder="<?php echo $this->system->produk->{$voucher->op_produk}->form->id_plgn->label;?>" required="required"/>
                </div>
                <?php endif;?>
                <div class="form-group">
                  <label class="sr-only1">Nomor HP</label>
                  <input class="form-control" name="nomor_hp" maxlength="14" placeholder="Nomor HP" required="required"/>
                </div>
                <div class="form-group">
                  <label class="sr-only1">Pembayaran</label>
                  <select class="form-control" name="pembayaran"><?php echo $payment_html;?></select>
                </div>
                <?php if ($this->system->perm->captcha_order == 'yes'):?>
                <div class="form-group" id="captcha">
                  <label class="sr-only1">Kode Keamanan</label>
                  <div class="input-group">
                    <span class="input-group-addon" style="padding: 0;"><img id="captcha-image" src="<?php echo site_url('captcha?r='.time());?>" style="height:30px"/></span>
                    <input type="text" name="captcha" class="form-control" placeholder="Kode keamanan" required="required" autocomplete="off"/>
                  </div>
                </div>
                <?php endif;?>
                <div class="form-group">
                  Dengan mengklik melakukan pembelian berarti kamu sudah setuju dengan <a href="<?php echo site_url('tos');?>" target="_blank">Syarat dan Ketentuan</a> yang berlaku.
                </div>
                <div>
                  <button class="btn btn-primary btn-block" name="submit" value="konfirmasi" id="submit">Beli Sekarang</button>
                </div>
                <input type="hidden" name="operator" value="<?php echo $voucher->op_id;?>"/>
                <input type="hidden" name="voucher" value="<?php echo $voucher->vo_id;?>"/>
                <input type="hidden" name="json_format" value="1"/>
              <?php echo form_close();?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script>
    $(document).ready(function(){
        var url = document.location.toString();
        if (url.match('#')) {
            $('.nav-tabs a[href="#' + url.split('#')[1] + '"]').tab('show');
        }
        $('.nav-tabs a').on('shown.bs.tab', function (e) {
            window.location.hash = e.target.hash;
        })
        $("#images a").click(function(){
            $("#produk-image").attr("src", "<?php echo base_url('images/produk/'.$voucher->op_produk);?>/"+$(this).data("image"));
            $('#images img').removeClass('active');
            $(this).find('img').addClass('active');
            return false;
        })
        $("#image a").click(function(){
            var image_url = $("#produk-image").attr('src');
            $("#myModal").modal("show");
            $("#myModal .modal-content").html('<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title">Preview Image</h4></div><div class="modal-body" style="text-align:center"><img style="margin: 0 auto;max-width:100%" src="'+image_url+'"></div>');
            return false;
        })
    })
    $(document).on("submit", "#order_form", function() {
      $("#submit").button('loading');
      var url = $(this).attr('action');
      $.post(url, $(this).serialize(), function(data) {
        if (data.success) {
          window.location.href ="<?php echo site_url('history/view');?>/"+data.id;
        }
        else {
          for (i = 0; i < data.errors.length; i++) {
            $.notify(data.errors[i], "error");
          }
          $.get("<?php echo current_url();?>", function(data){
            var csrf = $(data).find('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val();
            $('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val(csrf);
            <?php if ($this->system->perm->captcha_order == 'yes'):?>
            var captcha = $(data).find('#captcha-image').attr('src');
            $("#captcha-image").attr("src",captcha);
            $("#captcha .form-control").val('');
            <?php endif;?>
          })
          $("#submit").button('reset');
        }
      })
      .fail(function() {
        $.get("<?php echo current_url();?>", function(data){
          var csrf = $(data).find('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val();
          $('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val(csrf);
          <?php if ($this->system->perm->captcha_order == 'yes'):?>
          var captcha = $(data).find('#captcha-image').attr('src');
          $("#captcha-image").attr("src",captcha);
          $("#captcha .form-control").val('');
          <?php endif;?>
        })
        $.notify("Terjadi kesalahan saat memproses permintaan, silakan coba lagi atau refresh halaman ini.", "error");
        $("#submit").button('reset');
      })
      return false;
    });
    </script>
  </body>
</html>