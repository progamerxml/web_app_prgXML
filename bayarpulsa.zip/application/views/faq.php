<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <title>
      F.A.Q | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <link href="<?php echo base_url('assets/css/faq.css');?>" rel="stylesheet"/>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-thumb-tack"></i> Frequently Asked Questions
              </h3>
            </div>
            <div class="panel-body">
              <?php if (!$faqs):?>
              <div class="alert alert-warning">Tidak ada FAQ.</div>
              <?php else:?>
              <h3>
                Search
              </h3>
              <br />
              <ol class="faq-list">
                <?php foreach ($faqs as $faq):?>
                <li>
                  <h4>
                    <?php echo html_escape($faq->judul);?>
                  </h4>
                  <p>
                    <?php echo $faq->teks;?>
                  </p>
                </li>
                <?php endforeach;?>
              </ol>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <?php if ($faqs):?>
    <script src="<?php echo base_url('assets/js/faq.js');?>"></script>
    <script type="text/javascript">
    $('.faq-list').goFaq();
    </script>
    <?php endif;?>
  </body>

</html>