<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html style="height:100%">
  
  <head>
    <title>
      <?php echo ($mtc_title ? htmlspecialchars($mtc_title) : 'Maintenance!') . PHP_EOL;?>
    </title>
  </head>
  
  <body style="color: #444; margin:0;font: normal 14px/20px Arial, Helvetica, sans-serif; height:100%; background-color: #fff;position:relative">
    <div style="padding: 20px">
      <div style="text-align: center; margin: 0 auto; max-width: 480px;">
        <h2 style="margin-top:20px;font-size: 30px;">
          <?php echo ($mtc_title ? htmlspecialchars($mtc_title) : 'Maintenance') . PHP_EOL;?>
        </h2>
        <p>
          <?php echo ($mtc_message ? $mtc_message : 'Situs sedang dalam proses pemeliharaan, silakan kunjungi lagi nanti.!') . PHP_EOL;?>
        </p>
        <p>
          <a href="<?php echo site_url('user/login');?>" style="text-decoration: none;">.::.</a>
        </p>
      </div>
    </div>
  </body>

</html>