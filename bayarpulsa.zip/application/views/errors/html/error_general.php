<!DOCTYPE html>
<html>
  <head>
    <title>Error</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <style type="text/css">html{font-family:sans-serif;text-size-adjust:100%;font-size:10px;-webkit-tap-highlight-color:rgba(0,0,0,0)}body{margin:0px;font-family: "Helvetica Neue ",Helvetica,Arial,sans-serif;font-size:14px;line-height:1.42857;color:rgb(51,51,51);background-color:rgb(255,255,255)}p{margin:0}.fade{opacity:0;transition:opacity 0.15s linear 0s}.fade.in{opacity:1}.modal-open{overflow:hidden}.modal{position:fixed;top:0px;right:0px;bottom:0px;left:0px;z-index:1050;display:none;overflow:hidden;outline:0px}.modal.fade .modal-dialog{transition:transform 0.3s ease-out 0s;transform:translate(0px,-25%)}.modal.in .modal-dialog{transform:translate(0px,0px)}.modal-open .modal{overflow:hidden auto}.modal-dialog{position:relative;width:auto;margin:10px}.modal-content{max-width:580px;margin:0px auto;position:relative;background-color:rgb(255,255,255);background-clip:padding-box;border:1px solid rgba(0,0,0,0.2);border-radius:6px;outline:0px;box-shadow:rgba(0,0,0,0.5) 0px 3px 9px}.modal-backdrop{position:fixed;top:0px;right:0px;bottom:0px;left:0px;z-index:1040}.modal-backdrop.fade{opacity:0}.modal-backdrop.in{opacity:0.5}.modal-header{padding:15px;border-bottom:1px solid rgb(229,229,229);background:#b33030;border-top-left-radius:4px;border-top-right-radius:4px;color:#fff}.modal-header .close{margin-top:-2px}.modal-title{margin:0px;line-height:1.42857}.modal-body{position:relative;padding:15px}.modal-body >p{margin-bottom:0px}.modal-body >p{margin-bottom:0px}</style>
  </head>  
  <body class="modal-open">
    <div class="modal fade in" tabindex="-1" style="display: block;">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header" style="">
            <h4 class="modal-title"><?php echo $heading;?></h4>
          </div>
          <div class="modal-body">
            <?php echo $message;?>
          </div>
        </div>
      </div>
    </div>
    <div class="modal-backdrop fade in"></div>
  </body>
</html>