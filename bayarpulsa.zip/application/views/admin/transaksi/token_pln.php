<div class="table-responsive">
  <table class="table table-hover">
    <tbody>
      <tr><td>Jenis Produk</td><td><a href="<?php echo site_url('admin/produk/browse/'.$trx->op_produk);?>"><?php echo html_escape($this->system->produk->{$trx->op_produk}->nama);?></a></td></tr>
      <tr><td>Server</td><td><a href="<?php echo site_url('admin/pengaturan/server/edit/'.$trx->sv_id);?>"><?php echo html_escape(@$trx->sv_nama);?></a></td></tr>
      <tr><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->form->provider->label);?></td><td><?php echo $trx->op_slug ? '<a href="'.site_url('admin/produk/browse/'.$trx->op_produk.'/'.$trx->op_slug).'">'.html_escape($trx->op_nama).'</a>' : html_escape($trx->op_nama);?></td></tr>
      <tr><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->form->voucher->label);?></td><td><a href="<?php echo site_url('admin/produk/edit-voucher/'.$trx->vo_id.'/1');?>" data-toggle="modal" data-target="#myModal"><?php echo html_escape($trx->vo_nominal);?></a> <span class="text-muted">(<?php echo html_escape($trx->vo_kode);?>)</span></td></tr>
      <?php if ($trx->tr_id_plgn):?>
      <tr><td><?php echo html_escape(@$this->system->produk->{$trx->op_produk}->form->id_plgn->label);?></td><td><?php echo ($trx->tr_id_plgn);?></td></tr>
      <?php endif;?>
      <tr><td>Nomor HP</td><td><a data-toggle="modal" data-target="#myModal" href="<?php echo site_url('admin/sms/kirim?phone=' . $trx->tr_no_hp.'&amp;message='.urlencode($trx->tr_status_pembayaran == 'sukses' ? "Terima kasih sudah melakukan pembayaran, lihat transaksi kamu di " . site_url('history/view/'. $trx->tr_id) : "Pesanan kamu belum dibayar, silakan kunjungi " . site_url('history/view/'.$trx->tr_id) . "\r\nTerima Kasih"));?>"><?php echo $trx->tr_no_hp;?></a></td></tr>
      <?php if ($trx->tr_income):?>
      <tr><td>Harga Beli</td><td><?php echo format_uang2(($trx->us_id ? $trx->tr_harga2 : $trx->tr_harga) - $trx->tr_income);?></td></tr>
      <?php endif;?>
      <tr><td>Harga Jual</td><td><strong><?php echo format_uang2($trx->tr_harga, $trx->tr_rate, $this->payment->{$trx->tr_pembayaran}->template, $this->payment->{$trx->tr_pembayaran}->round);?></strong><?php echo ($trx->us_id && ($trx->tr_harga2 < $trx->tr_harga)) ? ' ('.format_uang2($trx->tr_harga2).')' : '';?></td></tr>
      <?php if ($trx->tr_income):?>
      <tr><td>Keuntungan</td><td><?php echo format_uang2($trx->tr_income);?></td></tr>
      <?php endif;?>
      <tr><td>Pembayaran</td><td><?php echo $trx->tr_pembayaran =='balance' ? 'Saldo Akun' : '<a href="'.site_url('admin/payments/'.$trx->tr_pembayaran.'/mutasi').'" target="_blank">'.$this->payment->{$trx->tr_pembayaran}->nama.'</a>';?></td></tr>
      <tr><td>Tanggal Pembelian</td><td><?php echo format_tanggal($trx->tr_tanggal);?></td></tr>
      <?php if ($trx->tr_status_pembayaran != 'pending'):?>
      <tr><td>Tanggal Pembayaran</td><td><?php echo ($trx->tanggal ? format_tanggal($trx->tanggal) : '-');?></td></tr>
      <?php endif;?>
      <tr><td>Status Pembayaran</td><td><?php echo ucfirst(str_replace('_',' ', $trx->tr_status_pembayaran));?></td></tr>
      <tr><td>Status Pengisian</td><td><?php echo ucfirst(str_replace('_',' ', $trx->tr_status));?></td></tr>
      <?php if ($trx->tr_status == 'sukses' && isset($opsi['sn'])):?>
      <tr><td>SN/Ref</td><td><?php echo $opsi['sn'];?></td></tr>
      <?php endif;?>
    </tbody>
  </table>
</div>