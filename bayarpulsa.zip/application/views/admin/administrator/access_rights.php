<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Hak Akses</title>
    <?php include_once(VIEWPATH. 'includes/head.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-multiselect.css');?>" type="text/css"/>
    <style type="text/css">
    .btn.btn-link{padding:0;}button.multiselect{font-size: inherit;}
    .multiselect-container>li>a>label{padding: 3px 20px 3px 30px;}
    .multiselect-container>li>a {margin:0; border-radius: 0;}
    .multiselect-container>li:first-child>a {border-top-left-radius: 4px; border-top-right-radius: 4px;}
    .multiselect-container>li:last-child>a {border-bottom-left-radius: 4px; border-bottom-right-radius: 4px;}
    </style>   
  </head>
  <body>
    <?php include_once(VIEWPATH. 'admin/_navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('admin');?>">Admin Panel</a></li>
        <li><a href="<?php echo site_url('admin/administrator');?>">Administrator</a></li>
        <li class="active"><span><?php echo html_escape($admins[$id]['name']);?></span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php
          $params = array(array(
              'title' => html_escape($admins[$id]['name']),
              'icon' => 'fa fa-shield',
              'links' => array(
                array('Hak Akses',  site_url('admin/administrator/access-rights/'.$id), 'fa fa-sitemap', true),
                array('Daftar Pengguna', site_url('admin/administrator/users/'.$id), 'fa fa-users'),
              ),
            ));
            echo sidebar_menu($params, true, 'ADMIN MENU');
          ?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="row">
            <div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
              <a class="btn btn-default btn-block" style="margin-bottom: 15px;" href="#" id="refreshBtn" title="Refresh daftar hak akses"><i class="fa fa-refresh"></i> Refresh</a>
            </div>
            <div class="col-xs-6 col-sm-offset-4 col-sm-4 col-md-offset-6 col-md-3 col-lg-offset-8 col-lg-2">
              <a class="btn btn-danger btn-block" style="margin-bottom: 15px;" data-toggle="modal" data-target="#myModal" href="<?php echo site_url('admin/administrator/access-rights/'.$id.'/clear');?>" title="Kosongkan semua pilihan"><i class="fa fa-trash"></i> Kosongkan</a>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-sitemap"></i> Hak Akses</h3>
            </div>
            <?php if (!$lists):?>
            <div class="panel-body">
              <div id="lists"><div class="text-center">Tidak ada daftar hak akses!</div></div>
              <div id="loading" class="text-center" style="display: none;"><p><i class="fa fa-spinner fa-2x fa-pulse fa-fw"></i></p><div id="count">[0/0]</div><div id="result">...</div></div>
            </div>
            <?php else:?>
            <div id="loading" class="panel-body text-center" style="display: none;"><p><i class="fa fa-spinner fa-2x fa-pulse fa-fw"></i></p><div id="count">[0/0]</div><div id="result">...</div></div>
            <div class="table-responsive" id="lists">
              <div style="padding: 15px;" class="text-center"><i class="fa fa-spinner fa-2x fa-pulse fa-fw"></i></div>
              <table class="table table-bordered table-hover" style="display: none;">
                <thead>
                  <tr>
                    <th>Halaman</th>
                    <th style="width: 180px;">Tindakan</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($lists as $page=>$actions): ?>
                  <tr>
                    <td style="vertical-align: middle;"><a href="<?php echo site_url('admin/'.$page);?>" title="<?php echo site_url('admin/'.$page);?>" target="gotopage"><?php echo $page;?></a></td>
                    <td>
                      <select multiple="multiple" size="1" data-page="<?php echo $page;?>" data-actions="<?php echo implode(',', $actions);?>">
                        <?php foreach ($actions as $action):?>
                        <option value="<?php echo $page.'/'.$action;?>" <?php echo isset($admins[$id]['access_rights'][$page]) && in_array($action, $admins[$id]['access_rights'][$page]) ? 'selected="selected"': '';?>><?php echo $action;?></option>
                        <?php endforeach;?>                        
                      </select>
                    </td>
                  </tr>
                  <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <?php endif;?>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap-multiselect.js');?>"></script>
    <script type="text/javascript">
    $('select[multiple="multiple"]').multiselect({
        buttonClass: 'btn btn-link',
        includeSelectAllOption: true,
        onChange: function(option, checked, select) {
            if (checked) {
                $.get("<?php echo site_url('admin/administrator/access-rights/'.$id.'/add');?>?access_right="+$(option).val(), function() {});
            } else {
                $.get("<?php echo site_url('admin/administrator/access-rights/'.$id.'/delete');?>?access_right="+$(option).val(), function() {});
            }
        }
    });
    $(document).on("change", 'input[type="checkbox"][value="multiselect-all"]', function(){
        var btn = $(this).parent().parent().parent().parent().prev();
        var btnTitle = btn.attr('title');
        var select = btn.parent().prev();
        if (btnTitle == 'None selected') {
            $.get("<?php echo site_url('admin/administrator/access-rights/'.$id.'/delete');?>?page="+select.attr('data-page')+"&actions="+select.attr('data-actions'), function(){});
        } else {
            $.get("<?php echo site_url('admin/administrator/access-rights/'.$id.'/add');?>?page="+select.attr('data-page')+"&actions="+select.attr('data-actions'), function(){});
        }
    });
    <?php if ($lists):?>
    $("#lists>div").hide();
    $("#lists>table").show();
    <?php endif;?>
    var accessRights = null;
    var index = 0;
    function getMethods() {
        if (index < accessRights.length) {
            var accessRight = accessRights[index];
            $("#loading>#count").text('['+(index + 1)+'/'+accessRights.length+']');
            index += 1;
            $.get("<?php echo site_url('admin');?>/" + accessRight + "/get-access-right-methods", function(data) {
                $("#loading>#result").html('<span class="text-success">'+accessRight+'</span>');
                setTimeout(function() {
                    getMethods();
                }, 500);
            }).fail(function() {
                $("#loading>#result").html('<span class="text-danger">'+accessRight+'</span>');
                setTimeout(function() {
                    getMethods();
                }, 500);
            });
        } else {
            window.location = "<?php echo site_url('admin/administrator/access-rights/'.$id);?>";
        }
    }
    $("#refreshBtn").click(function() {
        accessRights = null;
        index = 0;
        $("#loading>#count").text('[0/0]');
        $("#loading>#result").text('...');
        $(this).addClass('disabled');
        $("#lists").hide();
        $("#loading").show();
        $.get("<?php echo site_url('admin/administrator/get-access-rights');?>", function(data) {
            accessRights = data;
            getMethods();
        }).fail(function() {
            $("#refreshBtn").removeClass('disabled');
            $("#lists").show();
            $("#loading").hide();
            alert("Terjadi kesalahan!");
        });
        return false;
    });
    </script>
  </body>
</html>