<?php defined('BASEPATH') or exit('No direct script access allowed');?>
<?php echo form_open(current_url(), 'class="form-horizontal"');?>
  <div class="form-group">
    <label class="col-sm-2 control-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="name" value="<?php echo set_value('name');?>" maxlength="16" required="required"/>
    </div>
  </div>
  <div class="form-group" style="margin-bottom:0">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Simpan</button>
      &nbsp;
      <a href="<?php echo site_url('admin/administrator');?>" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i> Batal</a>
    </div>
  </div>
<?php echo form_close();?>
