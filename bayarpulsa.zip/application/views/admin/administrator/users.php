<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Daftar Pengguna</title>
    <?php include_once(VIEWPATH. 'includes/head.php'); ?>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap-multiselect.css');?>" type="text/css"/>
    <style type="text/css">
    .btn.btn-link{padding:0;}button.multiselect{font-size: inherit;}
    .multiselect-container>li>a>label{padding: 3px 20px 3px 30px;}
    .multiselect-container>li>a {margin:0; border-radius: 0;}
    .multiselect-container>li:first-child>a {border-top-left-radius: 4px; border-top-right-radius: 4px;}
    .multiselect-container>li:last-child>a {border-bottom-left-radius: 4px; border-bottom-right-radius: 4px;}
    </style>   
  </head>
  <body>
    <?php include_once(VIEWPATH. 'admin/_navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('admin');?>">Admin Panel</a></li>
        <li><a href="<?php echo site_url('admin/administrator');?>">Administrator</a></li>
        <li class="active"><span><?php echo html_escape($admins[$id]['name']);?></span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php
          $params = array(array(
              'title' => html_escape($admins[$id]['name']),
              'icon' => 'fa fa-shield',
              'links' => array(
                array('Hak Akses',  site_url('admin/administrator/access-rights/'.$id), 'fa fa-sitemap', false),
                array('Daftar Pengguna', site_url('admin/administrator/users/'.$id), 'fa fa-users', true),
              ),
            ));
            echo sidebar_menu($params, true, 'ADMIN MENU');
          ?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><a href="<?php echo site_url('admin/administrator/users/'.$id.'/add');?>" data-toggle="modal" data-target="#myModal" class="pull-right" title="Tambah pengguna"><i class="fa fa-user-plus"></i></a><i class="fa fa-users"></i> Daftar Pengguna</h3>
            </div>
            <?php if (!$users):?>
            <div class="panel-body"><div class="alert alert-warning">Tidak ada pengguna!</div></div>
            <?php else:?>
            <div class="table-responsive">
              <table class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Pengguna</th>
                    <th style="width: 120px;">Terakhir Masuk</th>
                    <th style="width: 39px; vertical-align: middle;" class="text-center"><i class="fa fa-ellipsis-h"></i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($users as $user):?>
                  <tr>
                    <td><a href="<?php echo site_url('admin/users/profil/'.$user->us_id);?>"><?php echo ($user->us_verified ? '<span class="text-success" data-toggle="tooltip" data-title="Terverifikasi"><i class="fa fa-check-circle"></i></span> ' : '') . html_escape($user->us_name);?></a></td>
                    <td><?php echo $user->us_lastdate ? format_tanggal($user->us_lastdate) : '-';?></td>
                    <td><?php if ($this->user->us_id != $user->us_id):?><a class="btn btn-danger btn-xs" href="<?php echo site_url('admin/administrator/users/'.$id.'/delete/'.$user->us_id);?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-times"></i></a><?php endif;?></td>
                  </tr>
                  <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <?php endif;?>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>