<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Administrator</title>
    <?php include_once(VIEWPATH. 'includes/head.php'); ?>
    <style type="text/css">
    .popover-content>.list-group{margin: -9px -15px;border-radius:0;}
    .popover-content>.list-group>.list-group-item{padding:5px 8px;border-left:0;border-right:0;}
    .popover-content>.list-group>.list-group-item:first-child{border-top:0;}
    .popover-content>.list-group>.list-group-item:last-child{border-bottom:0;}
    </style>
  </head>
  <body>
    <?php include_once(VIEWPATH. 'admin/_navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('admin');?>">Admin Panel</a></li>
        <li class="active"><span>Administrator</span></li>
      </ul>
      <div class="row">
        <div class="col-xs-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><?php if (count($admins) < 9):?><a href="<?php echo site_url('admin/administrator/add');?>" data-toggle="modal" data-target="#myModal" class="pull-right" title="Tambah administrator"><i class="fa fa-user-plus"></i></a><?php endif;?><i class="fa fa-shield"></i> Administrator</h3>
            </div>
            <div class="table-responsive">
              <table class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th style="vertical-align: middle;width:30px">ID</th>
                    <th style="vertical-align: middle;">Nama</th>
                    <th style="width: 77px; vertical-align: middle;" class="text-center">Hak Akses</th>
                    <th style="width: 77px; vertical-align: middle;" class="text-center">Pengguna</th>
                    <th style="width: 39px; vertical-align: middle;" class="text-center"><i class="fa fa-ellipsis-h"></i></th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($admins as $admin):?>
                  <tr>
                    <td style="vertical-align: middle;"><?php echo $admin['id'];?></td>
                    <td style="vertical-align: middle;"><a href="<?php echo site_url('admin/administrator/users/'.$admin['id']);?>"><?php echo html_escape($admin['name']);?></a></td>
                    <td style="vertical-align: middle;" class="text-center">
                    <?php if ($admin['id'] == 10):?>*<?php else:?><a data-toggle="tooltip" title="<?php echo $admin['total_pages'];?> halaman / <?php echo $admin['total_actions'];?> tindakan" href="<?php echo site_url('admin/administrator/access-rights/'.$admin['id']);?>"><?php echo $admin['total_pages'].'/'.$admin['total_actions'];?></a><?php endif;?>
                    </td>
                    <td style="vertical-align: middle;" class="text-center"><a href="<?php echo site_url('admin/administrator/users/'.$admin['id']);?>" title="<?php echo html_escape(implode(', ', $admin['users']));?>"><?php echo count($admin['users']);?></a></td>
                    <td style="vertical-align: middle;" class="text-center"><button type="button" class="btn btn-default btn-xs" data-container="body" data-toggle="popover" data-placement="left" data-html="true" data-content="<?php echo html_escape('<div class="list-group"><a data-toggle="modal" data-target="#myModal" class="list-group-item" href="' . site_url('admin/administrator/edit/'.$admin['id']) . '"><i class="fa fa-pencil"></i> Edit</a>'.($admin['id'] != 10 ? '<a data-toggle="modal" data-target="#myModal" class="list-group-item" href="' . site_url('admin/administrator/delete/'.$admin['id']) . '"><span class="text-danger"><i class="fa fa-remove"></i> Hapus</span></a>' : '').'</div>');?>" data-trigger="focus"><i class="fa fa-edit"></i></button></td>
                  </tr>
                  <?php endforeach;?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>