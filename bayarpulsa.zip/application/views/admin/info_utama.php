<div class="alert alert-info"><i class="fa fa-info-circle"></i> <strong>Info Utama</strong> akan ditampilkan di halaman <a href="<?php echo site_url('akun/profil');?>" class="alert-link">User Profile</a>.</div>
<?php echo form_open();?>
  <div class="form-group">
    <label>Judul</label>
    <input type="text" class="form-control" name="judul" maxlength="64" value="<?php echo set_value('judul', $info['judul']);?>"/>
  </div>
  <div class="form-group">
    <label>Pesan</label>
    <textarea class="form-control" name="pesan" maxlength="1000" rows="12"><?php echo set_value('pesan', $info['pesan']);?></textarea>
    <p class="help-block">Masukan pesan info dalam format HTML dan maksimal 1000 karakter.</p>
  </div>
  <div class="form-group">
    <label>Status</label>
    <div>
      <div class="radio-inline"><label style="font-weight: normal"><input type="radio" name="aktif" value="1" <?php echo  set_radio('status', '1', $info['aktif'] ? true : false); ?>/> Aktif</label></div>
      <div class="radio-inline"><label style="font-weight: normal"><input type="radio" name="aktif" value="0" <?php echo  set_radio('status', '1', $info['aktif'] ? false : true); ?>/> Tidak aktif</label></div>
    </div>
  </div>
  <div>
    <button type="submit" class="btn btn-primary" name="submit" value="simpan"><i class="fa fa-check"></i> Simpan</button>
    &nbsp;
    <a href="<?php echo site_url('akun/profil');?>" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i> Batal</a>
  </div>
<?php echo form_close();?>