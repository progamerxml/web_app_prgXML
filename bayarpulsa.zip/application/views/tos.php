<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <title>
      Ketentuan Layanan | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <link href="<?php echo base_url('assets/css/faq.css');?>" rel="stylesheet"/>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-exclamation-triangle"></i> Ketentuan Layanan
              </h3>
            </div>
            <div class="panel-body">
              Text Here!
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>