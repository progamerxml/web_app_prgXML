<?php

$payments = $this->payment->get();
$data_payments = array();
$harga_updated = array();
$current_time = time();

$option_active = '';
$option_inactive = '';
foreach ($payments as $payment) {
    if ($payment->status == 'off')
        continue;
    elseif ($payment->user == 1 && !$this->user->is_user())
        $option_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member)</option>';
    elseif ($payment->user == 2 && !$this->user->verified)
        $option_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member terverifikasi)</option>';
    else
        $option_active .= '<option value="' . $payment->key . '">' . $payment->nama . '</option>';
    $data_payments[$payment->key] = array(
        'nama' => $payment->nama,
        'template' => $payment->template,
        'rate' => (int)@$payment->rate,
        'round'=> (int)@$payment->round,
    );
}
$payment_html = $option_active . $option_inactive;
// Jumlah produk aktif
$produk_aktif = 0;
?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo isset($page_description) ? htmlentities($page_description) : ($this->config->item('page_description') ?  htmlentities($this->config->item('page_description')) : htmlentities(@$this->system->set['site_desc']));?>"/>
    <meta name="keywords" content="<?php echo isset($page_keywords) ? htmlentities($page_keywords) : ($this->config->item('page_keywords') ?  htmlentities($this->config->item('page_keywords')) : htmlentities(@$this->system->set['site_keywords']));?>"/>
    <link rel="icon" href="<?php echo base_url('favicon.ico');?>" type="image/x-icon"/>
    <link rel="shortcut icon" href="<?php echo base_url('favicon.ico');?>" type="image/x-icon"/>
    <title>
      <?php echo html_escape($this->system->config('site_name'));?>
    </title>
    <link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,600,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Roboto:400,500,700' rel='stylesheet' type='text/css'>
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet"/>
    <link href="<?php echo base_url('assets/css/font-awesome.min.css');?>" rel="stylesheet"/>
    <link href="<?php echo base_url('assets/css/home.css');?>" rel="stylesheet"/>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js">
      </script>
      <script src="js/respond.min.js">
      </script>
    <![endif]-->
    <script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>
  <style type="text/css">select option {margin: 0;}</style>
</head>
  
  <body>
    <nav class="navbar navbar-default navbar-custom navbar-custom-dark bg-dark" >
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">
              Toggle navigation
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
            <span class="icon-bar">
            </span>
          </button>
          <a class="navbar-brand" href="<?php echo site_url();?>"><img src="<?php echo base_url('assets/logo.png');?>" class="logo" alt="logo"/> </a>
        </div>
        <div class="navbar-collapse collapse" id="bs-example-navbar-collapse-1" aria-expanded="false" style="height: 1px;">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#produk" class="scroll">Produk</a></li>
            <li><a href="<?php echo site_url('history');?>" class="scroll">Status</a></li>
            <li><a href="<?php echo site_url('testimonial');?>" class="scroll">Testimonial</a></li>
            <?php if ($this->user->is_user()):?>
            <li><a href="<?php echo site_url('akun');?>" class="scroll"><i class="fa fa-user"></i> <?php echo html_escape($this->user->us_name);?></a></li>
            <?php else:?>
            <li><a href="<?php echo site_url('user/login');?>" class="scroll"><i class="fa fa-user"></i> Akun Saya</a></li>
            <?php endif;?>
          </ul>
        </div>
      </div>
    </nav>
    <section class="section home home-welcome bg-dark" id="home" >
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-8 text-left">
            <div class="home-wrapper">
              <div class="text-tran-box text-tran-box-dark" style="background: transparent;">
                <h1 class="text-transparent" style="background: transparent; mix-blend-mode: normal"><?php echo html_escape($this->system->set['site_name']);?></h1>
              </div>
              <h4><?php echo html_escape(@$this->system->set['site_desc']);?></h4>
              <ul class="list-inline client-list hidden-xs hidden-sm">
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/telkomsel.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/indosat.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/xl-axiata.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/three.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/axis.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/smartfren.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/bolt.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/esia.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/pln.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/gemscool.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/wavegame.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/megaxus.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/lyto.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/garena.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
                <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/operator/zynga.png');?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;padding: 0;border: 1px solid rgba(0,0,0,.5);" alt=""/></li>
              </ul>
              <div class="clearfix">
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-4">
            <div class="home-wrapper">
              <?php echo form_open(site_url('pulsa'), 'role="form" id="order_form" class="intro-form"');?>
                <h2 style="color: #949799;font-size: 26px;font-weight: 700;text-transform: uppercase;margin-top: 0;margin-bottom: 20px;display: block; text-align: center">Order</h2>
                <div class="form-group" style="position: relative;">
                  <label class="sr-only">Produk</label>
                  <select class="form-control" id="produk-select">
                    <option value="" disabled="disabled">-- Produk --</option>
                    <?php
                    $active_tab = '';
                    foreach ($this->system->produk as $pr_key=>$pr_val) {
                      if ($pr_val->status == 'off')
                         continue;
                      $produk_aktif += 1;
                      if ($active_tab == '')
                        $active_tab = $pr_key;
                      
                      $order_key = 'order_' . $pr_key;
                      $allow_order = (property_exists($this->system->perm, $order_key) ? $this->system->perm->$order_key : 'all');
                      if (($allow_order == 'user' || $allow_order == 'user_verified') && !$this->user->is_user()) {
                        $produk_attr = array('disabled' => ' disabled="disabbled"', 'text' => ' (Hanya member)');
                      }
                      elseif ($allow_order == 'user_verified' && !$this->user->verified) {
                        $produk_attr = array('disabled' => ' disabled="disabbled"', 'text' => ' (Hanya member terverifikasi)');
                      }
                      else {
                        $produk_attr = array('disabled' => '', 'text' => '');
                      }
                    ?>
                    <option value="<?php echo $pr_key;?>"<?php echo ($active_tab == $pr_key ? ' selected="selected"' : '') . $produk_attr['disabled'];?>><?php echo strtoupper($pr_val->nama) . $produk_attr['text'];?></option>
                    <?php } ?>
                  </select>
                  <i class="fa fa-chevron-down" style="right: 10px;bottom: 10px;position: absolute"></i>
                </div>
                <div id="produk-form">
                  <?php
                  $harga_html = '';
                  foreach ($this->system->produk as $pr_key=>$pr_val) {
                    if ($pr_val->status == 'off')
                      continue;
                    if (!isset($first_produk))
                      $first_produk = $pr_key;
                    $harga_html .= '<h3 style="margin-bottom: 0;display: '.($active_tab == $pr_key ? 'block' : 'none').';" id="harga_'.$pr_key.'">Rp -</h3>';
                  ?>
                  <div id="<?php echo $pr_key;?>" <?php echo $active_tab == $pr_key ? 'style="display:block" data-aktif="true"' : 'style="display:none" data-aktif="false"';?>>
                    <div class="form-group" style="position: relative;">
                      <label class="sr-only"><?php echo $pr_val->form->provider->label;?></label>
                      <select class="form-control" name="operator" <?php echo $active_tab == $pr_key ? 'required="required"' : 'disabled="disabled"';?> <?php echo $pr_val->form->provider->attr;?>>
                        <option value="">-- <?php echo $pr_val->form->provider->label;?> --</option>
                        <?php
                        foreach ($this->produk_model->get_providers($pr_key) as $provider) {
                        $harga_updated[$provider->op_id] = ($provider->op_harga_markup ? ($provider->op_markup_update > ($current_time - (3600 * 24)) ? 1 : 0) : 1);
                        ?>
                        <option value="<?php echo $provider->op_id;?>"><?php echo html_escape($provider->op_nama);?></option>
                        <?php } ?>
                      </select>
                      <i class="fa fa-chevron-down" style="right: 10px;bottom: 10px;position: absolute"></i>
                    </div>
                    <div class="form-group" style="position: relative;">
                      <label class="sr-only"><?php echo $pr_val->form->voucher->label;?></label>
                      <select class="form-control" name="voucher" <?php echo $active_tab == $pr_key ? 'required="required"' : 'disabled="disabled"';?> <?php echo $pr_val->form->voucher->attr;?>>
                        <option value="">-- <?php echo $pr_val->form->voucher->label;?> --</option>
                      </select>
                      <i class="fa fa-chevron-down" style="right: 10px;bottom: 10px;position: absolute"></i>
                    </div>
                    <?php if (property_exists($pr_val->form,'id_plgn')):?>
                    <div class="form-group">
                      <label class="sr-only"><?php echo $pr_val->form->id_plgn->label;?></label>
                      <input type="text" name="id_plgn" class="form-control" placeholder="<?php echo $pr_val->form->id_plgn->label;?>" required="required"  <?php echo $active_tab == $pr_key ? 'required="required"' : 'disabled="disabled"';?> autocomplete="off" <?php echo $pr_val->form->id_plgn->attr;?>>
                    </div>
                    <?php endif;?>
                  </div>
                  <?php
                  }
                  ?>
                </div>
                <div class="form-group">
                  <label class="sr-only">Nomor HP</label>
                  <input type="text" name="nomor_hp" class="form-control" placeholder="Nomor HP" required="required" autocomplete="off">
                </div>
                <div class="form-group" style="position: relative;">
                  <label class="sr-only">Pembayaran</label>
                  <select class="form-control" name="pembayaran">
                    <?php echo $payment_html;?>
                  </select>
                  <i class="fa fa-chevron-down" style="right: 10px;bottom: 10px;position: absolute"></i>
                </div>
                <div class="form-group text-center" id="harga">
                  <?php echo $harga_html;?>
                </div>
                <?php if ($this->system->perm->captcha_order == 'yes'):?>
                <div class="form-group" id="captcha">
                  <label class="sr-only">Kode Keamanan</label>
                  <div class="input-group">
                    <span class="input-group-addon"><img id="captcha-image" src="<?php echo site_url('captcha?r='.time());?>" style="height:30px"/></span>
                    <input type="text" name="captcha" class="form-control" placeholder="Kode keamanan" required="required" autocomplete="off">
                  </div>
                </div>
                <?php endif;?>
                <div class="form-group text-center" style="margin-bottom: 0">
                  <button type="submit" class="btn btn-warning btn-block" name="submit" id="submit" value="konfirmasi" data-loading-text="<i class='fa fa-circle-o-notch fa-spin'></i> Memproses" <?php echo (isset($disabled_order) ? 'disabled="disabled"' : '');?>>
                    Order Sekarang
                  </button>
                </div>
                <input type="hidden" name="json_format" value="1" />
              <?php echo form_close();?>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <div class="facts-box text-center">
              <div class="row">
                <div class="col-sm-3 col-xs-6">
                  <h2><?php echo $total_trx_sukses;?></h2>
                  <p class="text-muted">Transaksi Sukses</p>
                </div>
                <div class="col-sm-3 col-xs-6">
                  <h2><?php echo $total_users;?></h2>
                  <p class="text-muted">Member Terdaftar</p>
                </div>
                <div class="col-sm-3 col-xs-6">
                  <h2><?php echo $total_providers;?></h2>
                  <p class="text-muted">Total Operator</p>
                </div>
                <div class="col-sm-3 col-xs-6">
                  <h2><?php echo $total_vouchers;?></h2>
                  <p class="text-muted">Total Voucher</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="clearfix">
    </div>
    <section class="section">
      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <div class="features-box text-center">
              <div class="feature-icon"><i class="fa fa-dollar"></i></div>
              <h3>Murah</h3>
              <p class="text-muted">Harga lebih murah dibanding harga di konter-konter dekat rumah Anda.</p>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="features-box text-center">
              <div class="feature-icon"><i class="fa fa-clock-o"></i></div>
              <h3>Non Stop</h3>
              <p class="text-muted">Kapan pun Anda bisa melakukan pembelian karena buka 24 jam non stop.</p>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="features-box text-center">
              <div class="feature-icon"><i class="fa fa-tasks"></i></div>
              <h3>Otomatis</h3>
              <p class="text-muted">Transaksi diproses secara cepat dan otomais oleh sistem Kami.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section bg-white" id="produk">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <h2 class="title">Produk</h2>
            <p class="title-alt">Daftar produk yang tersedia</p>
          </div>
        </div>
        <div class="row">
          <?php
          if ($produk_aktif == 1) {
            $col1 = 'col-sm-offset-4 col-sm-4';
            $col2 = 'col-sm-12 col-md-offset-1 col-md-10';
          }
          elseif ($produk_aktif == 2) {
            $col1 = 'col-sm-12 col-md-offset-3 col-md-6';
            $col2 = 'col-sm-6 col-md-6';
          }
          elseif ($produk_aktif == 3) {
            $col1 = 'col-sm-12 col-md-offset-1 col-md-10';
            $col2 = 'col-sm-4 col-md-4';
          }
          else {
            $col1 = 'col-sm-12';
            $col2 = 'col-sm-6 col-md-3';
          }
          ?>
          <div class="<?php echo $col1;?>">
          <div class="row">
          <?php
          foreach ($this->system->produk as $pr_key=>$pr_val):
          if ($pr_val->status == 'off')
            continue;
          $total = $this->produk_model->count($pr_key);

          ?>
          <div class="<?php echo $col2;?>">
            <div class="panel panel-default">
              <div class="panel-heading" style="white-space: nowrap; overflow: hidden;">
                <a href="<?php echo site_url('harga/'.str_replace('_','-', $pr_key));?>"><h3 class="text-center text-uppercase" style="margin: 0;"><?php echo $pr_val->nama . PHP_EOL;?></h3></a>
              </div>
              <div style="margin: 0; padding: 0; height: 200px; position: relative; overflow: hidden;">
                <img src="<?php echo (file_exists(FCPATH.'assets/'.$pr_key.'.png') ? base_url('assets/'.$pr_key.'.png') : base_url('assets/produk-default.png'));?>" class="img-responsive" style="margin: 0 auto;"/>
              </div>
              <ul class="list-group">
                <li class="list-group-item">Provider <span class="badge" data-toggle="tooltip" data-title="Jumlah provider" data-placement="left"><?php echo $total['providers'];?></span></li>
                <li class="list-group-item">Voucher <span class="badge" data-toggle="tooltip" data-title="Jumlah voucher" data-placement="left"><?php echo $total['vouchers'];?></span></li>
                <li class="list-group-item">Transaksi <span class="badge" data-toggle="tooltip" data-title="Jumlah transaksi sukses" data-placement="left"><?php echo $total['trx'];?></span></li>
              </ul>
              <div class="panel-body text-center">
                <a class="btn btn-primary btn-block scroll" href="#home" data-produk="<?php echo $pr_key;?>" data-toggle="order"><i class="fa fa-shopping-cart"></i> Order</a>
              </div>
            </div>
          </div>
          <?php endforeach;?>
          </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section  hidden-xs" id="clients">
      <div class="container">
        <div class="row text-center">
          <div class="col-sm-12">
            <h2 class="title">Pembayaran</h2>
            <p class="slogan">Pilihan metode pembayaran yang memudahkan Anda.</p>
            <div class="row">
              <div class="col-sm-offset-2 col-sm-8">
                <ul class="list-inline client-list">
                  <?php
                  foreach ($payments as $payment):
                  if (file_exists(FCPATH.'assets/payments/'.$payment->key.'.png'))
                    $logo_payment = $payment->key.'.png';
                  elseif (file_exists(FCPATH.'assets/payments/'.$payment->key.'.jpg'))
                    $logo_payment = $payment->key.'.jpg';
                  else
                    continue;
                  ?>
                  <li style="margin-bottom: 15px;"><img src="<?php echo base_url('assets/payments/'.$logo_payment);?>" class="img-thumbnail" style="width: 120px !important; height: 48px !important;" alt="<?php echo $payment->nama;?>"/></li>
                  <?php endforeach;?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script src="<?php echo base_url('assets/js/jquery.easing.1.3.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.app.js');?>"></script>
    <script>
    <?php
    $data_vouchers = array();
    foreach ($vouchers as $voucher) {
        $data_vouchers[$voucher->op_id][] = array(
            'id' => $voucher->vo_id,
            'nama' => $voucher->vo_nominal,
            'harga' => $voucher->vo_harga,
            'harga_updated' => (isset($harga_updated[$voucher->op_id]) && $harga_updated[$voucher->op_id] == 1 ? 1 : 0),
            'status' => (int)$voucher->vo_status,
        );
    }
    ?>
    var vouchers = <?php echo json_encode($data_vouchers);?>;
    var payments = <?php echo json_encode($data_payments);?>;
    function format_harga(price, rate, tpl, round) {
      if (rate != 0) {
        var harga = (price / rate).toFixed(round);
        return tpl.replace('{INT}', harga);
      }
      else {
        var rev = parseInt(price, 10).toString().split('').reverse();
        var rev = rev.join('');
        var rev2    = '';
        for(var i = 0; i < rev.length; i++){
          rev2  += rev[i];
          if((i + 1) % 3 === 0 && i !== (rev.length - 1)) {
            rev2 += '.';
          }
        }
        var harga =  rev2.split('').reverse().join('');
        return tpl.replace('{INT}', harga);
      }
    }
    function update_harga(produk, hide) {
      if (hide) {
        $("#harga h3").hide();
      }
      var provider = $("#"+produk+" [name='operator'] option:selected").val();
      var voucher = $("#"+produk+" [name='voucher'] option:selected").val();
      var pembayaran = $("[name='pembayaran'] option:selected").val();
      if (typeof vouchers[provider] != "undefined" && typeof payments[pembayaran] != "undefined") {
        for (i = 0; i < vouchers[provider].length; i++) {
          if (vouchers[provider][i]['id'] == voucher) {
            var harga = format_harga(vouchers[provider][i]['harga'], payments[pembayaran]['rate'],payments[pembayaran]['template'],payments[pembayaran]['round']);
            /*if (vouchers[provider][i]['harga_updated'] == 1) {*/
              $("#harga_"+produk).html(harga);
            /*}
            else {
              $("#harga_"+produk).html(harga+' <a href="<?php echo site_url('harga');?>/'+produk+'/'+provider+'" title="Lihat harga terbaru" target="harga_produk"><i class="fa fa-refresh"></i></a>');
            }*/
            continue;
          }
        }
      }
      else {
        $("#harga_"+produk).html("Rp -");
      }
      if (hide) {
        $("#harga_"+produk).show();
      }
    }
    function change_tab(produk, hide) {
      var selected_produk = $("#produk-select option:selected").val();
      $('#produk-select').val(produk);
      $("#produk-form .form-control").attr('disabled','disabled').removeAttr('required');
      $("#order_form #"+produk+" .form-control").removeAttr('disabled').attr('required','required');
      update_harga(produk, true);
      if (hide) {
        $('#produk-form > div').hide(1000).attr('data-aktif','false');
        $('#produk-form > #'+produk).show(1000).attr('data-aktif','true');
      }
    }
    <?php if (isset($first_produk) && $first_produk != 'pulsa'):?>
    $("#order_form").attr('action', "<?php echo site_url($first_produk);?>");
    <?php endif;?>
    $(document).on('change', '#produk-select', function () {
      var produk = $("#produk-select option:selected").val();
      $("#order_form").attr('action', "<?php echo site_url();?>"+produk);  
      change_tab(produk, true);
    });
    $('[data-toggle="order"]').click(function(e) {
      var produk = $(this).data('produk');
      $("#order_form").attr('action', "<?php echo site_url();?>"+produk);
      change_tab(produk, true);
    })
    $(document).on("change", "[name='operator']", function() {
      var produk = $("#produk-form [data-aktif='true']").attr('id');
      var operator = $("#produk-form #"+produk+" [name='operator'] option:selected").val();
      if (operator == "") {
        $("#produk-form #"+produk+" [name='voucher']").html('<option value="">-- Voucher --</option>');
      } else {
        if (typeof vouchers[operator] != "undefined") {
          var vo_option = '';
          vo_option += '<option value="">-- Silakan pilih --</option>';
          for (i = 0; i < vouchers[operator].length; i++) {
            vo_option += '<option value="' + vouchers[operator][i]['id'] + '"' + (vouchers[operator][i]['status'] == 0 ? ' disabled="disabled"' : '') + '>' + vouchers[operator][i]['nama'] + (vouchers[operator][i]['status'] == 0 ? ' (Kosong)' : '') + '</option>';
          }
          $("#produk-form #"+produk+" [name='voucher']").html(vo_option);
        }
      }
      $("#harga_"+produk).html("Rp -");
    });
    $(document).on("change", "[name='voucher'], [name='pembayaran']", function(e) {
      var produk = $("#produk-form [data-aktif='true']").attr('id');
      update_harga(produk, false);
    });
    $(document).on("submit", "#order_form", function() {
      $("#submit").button('loading');
      var url = $(this).attr('action');
      $.post(url, $(this).serialize(), function(data) {
        if (data.success) {
          window.location.href ="<?php echo site_url('history/view');?>/"+data.id;
        }
        else {
          for (i = 0; i < data.errors.length; i++) {
            $.notify(data.errors[i], "error");
          }
          $.get("<?php echo site_url();?>", function(data){
            var csrf = $(data).find('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val();
            $('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val(csrf);
            <?php if ($this->system->perm->captcha_order == 'yes'):?>
            var captcha = $(data).find('#captcha-image').attr('src');
            $("#captcha-image").attr("src",captcha);
            $("#captcha .form-control").val('');
            <?php endif;?>
          })
          $("#submit").button('reset');
        }
      })
      .fail(function() {
        $.get("<?php echo site_url();?>", function(data){
          var csrf = $(data).find('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val();
          $('#order_form [name="<?php echo $this->security->get_csrf_token_name();?>"]').val(csrf);
          <?php if ($this->system->perm->captcha_order == 'yes'):?>
          var captcha = $(data).find('#captcha-image').attr('src');
          $("#captcha-image").attr("src",captcha);
          $("#captcha .form-control").val('');
          <?php endif;?>
        })
        $.notify("Terjadi kesalahan saat memproses permintaan, silakan coba lagi atau refresh halaman ini.", "error");
        $("#submit").button('reset');
      })
      return false;
    });
    </script>
  </body>

</html>