<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'):?>
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <h4 class="modal-title"><i class="fa fa-exclamation-triangle"></i> Konfirmasi</h4>
</div>
<?php echo form_open();?>
  <div class="modal-body">
    <div class="alert alert-warning" style="margin-bottom: 0;"><?php echo @$info;?></div>
    <?php echo (isset($opsi) ? $opsi : '');?>
    <?php foreach ($_POST as $post_key => $post_val):?>
    <?php if (is_array($post_val)):?>
    <?php foreach ($post_val as $post):?>
    <input type="hidden" name="<?php echo html_escape($post_key);?>[]" value="<?php echo html_escape($post);?>" />
    <?php endforeach;?>
    <?php else:?>
    <input type="hidden" name="<?php echo html_escape($post_key);?>" value="<?php echo html_escape($post_val);?>" />
    <?php endif;?>
    <?php endforeach;?>
  </div>
  <div class="modal-footer">
    <button class="btn btn-primary" type="submit" name="confirm" value="1"><i class="fa fa-check"></i> Ya</button>
    &nbsp;
    <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i> Tidak</button>
  </div>
<?php echo form_close();?>
<?php else:?>
<?php define('HIDE_SUBNAVBAR', true);?>
<!DOCTYPE html>
<html>
  <head>
    <title>Konfirmasi</title>
    <?php include_once(VIEWPATH. 'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH. 'includes/navbar.php'); ?>
    <div class="container">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3><i class="fa fa-exclamation-triangle"></i> Konfirmasi</h3>
        </div>
        <div class="panel-body">
          <div class="row">
            <div class="col-sm-offset-3 col-sm-6">
              <?php echo form_open();?>
                <div class="alert alert-warning"><?php echo @$info;?></div>
                <?php echo (isset($opsi) ? $opsi : '');?>
                <?php foreach ($_POST as $post_key => $post_val):?>
                <?php if (is_array($post_val)):?>
                <?php foreach ($post_val as $post):?>
                <input type="hidden" name="<?php echo html_escape($post_key);?>[]" value="<?php echo html_escape($post);?>" />
                <?php endforeach;?>
                <?php else:?>
                <input type="hidden" name="<?php echo html_escape($post_key);?>" value="<?php echo html_escape($post_val);?>" />
                <?php endif;?>
                <?php endforeach;?>
                <div class="text-right">
                  <button class="btn btn-primary" type="submit" name="confirm" value="1"><i class="fa fa-check"></i> Ya</button>
                  &nbsp;
                  <button class="btn btn-default" type="button" onclick="window.history.back()"><i class="fa fa-remove"></i> Tidak</button>
                </div>
              <?php echo form_close();?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>
<?php endif;?>