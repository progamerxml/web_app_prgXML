<?php if (isset($is_tagihan)):?>
<!-- Tagihan -->
<?php if ($trx->tg_status == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div>
    <div class="text-warning text-center">
      Pembayaran akan diproses secara otomatis apabila menggunakan saldo iPaymu, jika menggunakan bank transfer dan anda sudah membayarnya maka segera hubungi Administrator.
    </div>
    <br />
    <div class="table-responsive">
      <table class="table table-striped">
        <tbody>
          <tr><td>Harga</td><td><?php echo format_uang2($trx->tg_amount2);?></td></tr>
          <tr><td>Kode Unik</td><td><?php echo format_uang2($trx->tg_amount - $trx->tg_amount2);?></td></tr>
          <tr><td>Fee / Biaya</td><td><?php echo format_uang2($fee = ceil(round($trx->tg_amount / 100, 2)));?></td></tr>
          <tr><td>Total</td><td><strong><?php echo format_uang2($trx->tg_amount + $fee);?></strong></td></tr>
        </tbody>
      </table>
    </div>
    <div>
      <ul style="padding-left: 15px;">
        <li>Harga unik sebesar <?php echo format_uang2($trx->tg_amount - $trx->tg_amount2);?> akan dikembalikan ke saldo deposit Anda.</li>
        <li>Fee / Biaya sebesar <?php echo format_uang2($fee);?> tidak akan dikembalikan.</li>
        <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tg_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
      </ul>
    </div>
  </div>
</div>
<div class="panel-footer">
  <a class="btn btn-primary btn-block" href="<?php echo site_url('payment/ipaymu/tagihan/'.$trx->tg_id);?>" id="submit-confirm"><i class="fa fa-money"></i> Bayar Sekarang</a>
</div>
<?php endif;?>
<!-- End -->
<?php else:?>
<!-- Transaksi -->
<?php if ($trx->tr_status_pembayaran == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div>
    <div class="text-warning text-center">
      Pembayaran akan diproses secara otomatis apabila menggunakan saldo iPaymu, jika menggunakan bank transfer dan anda sudah membayarnya maka segera hubungi Administrator.
    </div>
    <br />
    <div class="table-responsive">
      <table class="table table-striped">
        <tbody>
          <tr><td>Harga</td><td><?php echo format_uang2($trx->tr_harga2);?></td></tr>
          <tr><td>Kode Unik</td><td><?php echo format_uang2($trx->tr_harga - $trx->tr_harga2);?></td></tr>
          <tr><td>Fee / Biaya</td><td><?php echo format_uang2($fee = ceil(round($trx->tr_harga / 100, 2)));?></td></tr>
          <tr><td>Total</td><td><strong><?php echo format_uang2($trx->tr_harga + $fee);?></strong></td></tr>
        </tbody>
      </table>
    </div>
    <div>
      <ul style="padding-left: 15px;">
        <li>Harga unik sebesar <?php echo format_uang2($trx->tr_harga - $trx->tr_harga2);?> akan dikembalikan ke saldo deposit Anda.</li>
        <li>Fee / Biaya sebesar <?php echo format_uang2($fee);?> tidak akan dikembalikan.</li>
        <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
      </ul>
    </div>
  </div>
</div>
<div class="panel-footer">
  <a class="btn btn-primary btn-block" href="<?php echo site_url('payment/ipaymu/trx/'.$trx->tr_id);?>" id="submit-confirm"><i class="fa fa-money"></i> Bayar Sekarang</a>
</div>
<?php endif;?>
<!-- End -->
<?php endif;?>