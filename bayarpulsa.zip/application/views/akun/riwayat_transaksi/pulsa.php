<div class="table-responsive">
  <table class="table table-hover">
    <tbody>
      <tr><td>Jenis Produk</td><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->nama);?></td></tr>
      <tr><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->form->provider->label);?></td><td><?php echo html_escape($trx->op_nama);?></td></tr>
      <tr><td><?php echo html_escape($this->system->produk->{$trx->op_produk}->form->voucher->label);?></td><td><?php echo html_escape($trx->vo_nominal);?></td></tr>
      <tr><td>Nomor HP</td><td><?php echo $trx->tr_no_hp;?></td></tr>
      <tr><td>Harga</td><td><?php echo format_uang2($trx->tr_harga, $trx->tr_rate, $this->payment->{$trx->tr_pembayaran}->template, $this->payment->{$trx->tr_pembayaran}->round);?></td></tr>
      <tr><td>Pembayaran</td><td><?php echo $trx->tr_pembayaran =='balance' ? 'Saldo Akun' : $this->payment->{$trx->tr_pembayaran}->nama;?></td></tr>
      <tr><td>Tanggal Pembelian</td><td><?php echo format_tanggal($trx->tr_tanggal);?></td></tr>
      <?php if ($trx->tr_status_pembayaran != 'pending'):?>
      <tr><td>Tanggal Pembayaran</td><td><?php echo ($trx->tanggal ? format_tanggal($trx->tanggal) : '-');?></td></tr>
      <?php endif;?>
      <tr><td>Status Pembayaran</td><td><?php echo ucfirst(str_replace('_',' ', $trx->tr_status_pembayaran));?></td></tr>
      <tr><td>Status Pengisian</td><td><?php echo ucfirst(str_replace('_',' ', $trx->tr_status));?></td></tr>
      <?php if ($trx->tr_status == 'sukses' && isset($opsi['sn'])):?>
      <tr><td>SN/Ref</td><td><?php echo $opsi['sn'];?></td></tr>
      <?php endif;?>
    </tbody>
  </table>
</div>