<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Riwayat Transaksi &gt; Tagihan</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">.panel-body.xxx{padding-bottom: 0;}.panel-body.xxx div.row>div>button{margin-bottom: 15px;}.panel-body.xxx div.row>div>nav{float:right;margin-bottom:15px;}</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li><a href="<?php echo site_url('akun/riwayat-transaksi');?>">Riwayat Transaksi</a></li>
        <li class="active"><span>Tagihan</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-money"></i> Tagihan</h3>
            </div>
            <div class="panel-body xxx">
              <?php if (!$results):?>
              <div class="alert alert-warning" style="margin-bottom: 15px;">Tidak ada riwayat tagihan</div>
              <?php else:?>
              <?php if ($page <= 1):?>
              <div class="alert alert-info fade in"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Klik tanggal untuk melihat melakukan pembayaran.</div>
              <?php endif;?>
              <?php echo form_open();?>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th><input type="checkbox" id="select-all"/></th>
                      <th>Tanggal</th>
                      <th>Tagihan</th>
                      <th>Keterangan</th>
                      <th>Pembayaran</th>
                      <th>Jumlah</th>
                      <th style="width: 80px;text-align:center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($results as $res):?>
                    <tr>
                      <td><input type="checkbox" class="checkbox1" name="tag_id[]" value="<?php echo $res->tg_id;?>"/></td>
                      <?php if ($res->tg_tanggal > $expired):?>
                      <td><a href="<?php echo site_url('akun/riwayat-transaksi/tagihan/view/'.$res->tg_id);?>"><?php echo format_tanggal($res->tg_tanggal);?></a></td>
                      <?php else:?>
                      <td><?php echo format_tanggal($res->tg_tanggal);?></td>
                      <?php endif;?>
                      <td><?php echo html_escape($res->tg_title);?></td>
                      <td><?php echo tg_keterangan($res->us_id, $res->tg_title, json_decode($res->tg_opsi,true));?></td>
                      <td><?php echo html_escape($this->payment->{$res->tg_payment}->nama);?></td>
                      <td><?php echo format_uang($res->tg_amount, $res->tg_rate, $this->payment->{$res->tg_payment}->template, $this->payment->{$res->tg_payment}->round);?></td>
                      <td style="width: 80px;text-align:center"><?php echo tg_status($res->tg_tanggal, $res->tg_status, $expired);?></td>
                    </tr>
                    <?php endforeach;?>
                  </tbody>
                </table>
              </div>
              <div class="row">
                <div class="col-sm-4 col-md-3">
                <button class="btn btn-danger btn-block btn-sm" type="submit"><i class="fa fa-trash"></i> Hapus yang ditandai</button>
                </div>
                <div class="col-sm-8 col-md-9">
                <?php echo pagination(site_url('akun/riwayat-transaksi/tagihan/page/'), $start, $total, $this->system->set['list_per_page'], '%d');?>
                </div>
              </div>
              <?php echo form_close();?>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script>$(document).ready(function(){$('#select-all').click(function(event){if(this.checked){$('.checkbox1').each(function(){this.checked=true;})}else{$('.checkbox1').each(function(){this.checked=false;})}});});</script>
  </body>
</html>