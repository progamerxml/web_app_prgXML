<?php
defined('BASEPATH') or exit('No direct script access allowed');
$status_label = array('wp'=>'Menunggu Pembayaran','ip'=>'Dalam Proses','ok'=>'Sukses','cl'=>'Gagal','rf'=>'Refund','ex'=>'Tidak Berlaku');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Riwayat Transaksi</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <link id="bsdp-css" href="<?php echo base_url('assets/css/bootstrap-datepicker3.css');?>" rel="stylesheet"/>
    <style type="text/css">#list-table{padding-bottom:0;}#action-links>div>button,#action-links>div>nav{float:right;margin-bottom:15px;}</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Riwayat Transaksi</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="row">
            <div class="col-xs-6 col-sm-4 col-md-3">
              <a style="margin-bottom: 15px;" class="btn btn-default btn-block" href="<?php echo site_url('akun/riwayat-transaksi/tagihan');?>"><i class="fa fa-money"></i> Tagihan<?php echo $total_tagihan ? ' ('.$total_tagihan.')' : '';?></a>
            </div>
            <div class="col-xs-6 col-sm-4 col-sm-offset-4 col-md-3 col-md-offset-6">
              <button style="margin-bottom: 15px;" type="button" class="btn btn-default btn-block" data-toggle="collapse" aria-expanded="false" aria-controls="filter_form" data-target="#filter_form"><i class="fa fa-filter"></i> Filter <?php echo ($total_filter ? '('.$total_filter.') ' : '');?><span class="caret"></span></button>
            </div>
          </div>
          <!-- Filter form -->
          <form method="get" action="<?php echo site_url('akun/riwayat-transaksi');?>">
            <div id="filter_form" class="row collapse">
              <div class="col-sm-8 col-md-9">
                <div class="row">
                  <div class="col-xs-6 col-sm-4">
                    <select style="margin-bottom: 15px;" class="form-control" name="produk" data-toggle="tooltip" data-title="Jenis Produk">
                      <option value="" <?php echo (@$produk == '' ? 'selected' : '');?>>-- Jenis Produk --</option>
                      <?php foreach ($this->system->produk as $pr_key=>$pr_val): if ($pr_val->status == 'off') continue;?>
                      <option value="<?php echo $pr_key;?>" <?php echo (@$produk == $pr_key ? 'selected' : '');?>><?php echo html_escape($pr_val->nama);?></option>
                      <?php endforeach;?>
                    </select>
                  </div>
                  <div class="col-xs-6 col-sm-4">
                    <input style="margin-bottom: 15px;" type="text" class="form-control" name="no_hp" value="<?php echo html_escape(@$no_hp);?>" placeholder="0812345678" data-toggle="tooltip" data-title="Nomor HP" maxlength="16"/>
                  </div>
                  <div class="col-xs-6 col-sm-4">
                    <select style="margin-bottom: 15px;" class="form-control" name="pembayaran" data-toggle="tooltip" data-title="Pembayaran">
                      <option value="" <?php echo (@$pembayaran == '' ? 'selected' : '');?>>-- Pembayaran --</option>
                      <?php foreach ($this->payment->get() as $payment): if ($payment->status == 'off') continue;?>
                      <option value="<?php echo $payment->key;?>" <?php echo (@$pembayaran == $payment->key ? 'selected' : '');?>><?php echo html_escape($payment->nama);?></option>
                      <?php endforeach;?>
                    </select>
                  </div>
                  <div class="col-xs-6 col-sm-4">
                    <select style="margin-bottom: 15px;" class="form-control" name="status" data-toggle="tooltip" data-title="Status">
                      <option value="" <?php echo (@$status == '' ? 'selected' : '');?>>-- Status --</option>
                      <?php foreach ($status_label as $status_key=>$status_value):?>
                      <option value="<?php echo $status_key;?>" <?php echo (@$status == $status_key ? 'selected' : '');?>><?php echo $status_value;?></option>
                      <?php endforeach;?>
                    </select>
                  </div>
                  <div class="col-xs-6 col-sm-4">
                    <input style="margin-bottom: 15px;" class="form-control" id="dari_tanggal" data-toggle="tooltip" title="Dari Tanggal" type="text" name="dari_tanggal" value="<?php echo html_escape(@$dari_tanggal);?>" placeholder="HH-BB-TTTT" autocomplete="off"/>
                  </div>
                  <div class="col-xs-6 col-sm-4">
                    <input style="margin-bottom: 15px;" class="form-control" id="ke_tanggal" data-toggle="tooltip" title="Ke Tanggal" type="text" name="ke_tanggal" value="<?php echo html_escape(@$ke_tanggal);?>" placeholder="HH-BB-TTTT" autocomplete="off"/>
                  </div>
                </div>
              </div>
              <div class="col-sm-4 col-md-3">
                <div class="row">
                  <div class="col-xs-6 col-sm-12">
                    <button style="margin-bottom: 15px;" type="submit" class="btn btn-primary btn-block">Tampilkan</button>
                  </div>
                  <div class="col-xs-6 col-sm-12">
                    <a style="margin-bottom: 15px;" href="<?php echo site_url('akun/riwayat-transaksi');?>" class="btn btn-default btn-block">Reset</a>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <!-- End -->
          <div id="summary" class="panel panel-default">
            <div style="cursor: pointer;" class="panel-heading" data-toggle="collapse" aria-expanded="false" aria-controls="ringkasan" data-target="#ringkasan">
              <h3><span class="pull-right" id="chevron"><i class="fa fa-chevron-down"></i></span><i class="fa fa-list"></i> Ringkasan Transaksi</h3>
            </div>
            <div id="ringkasan" class="table-responsive collapse">
              <div id="spinner" style="text-align: center;padding: 15px;"><i class="fa fa-spinner fa-2x fa-pulse fa-fw"></i></div>
            </div>
          </div>
          <?php if (!$total):?>
          <div class="alert alert-warning" style="margin-bottom: 15px;">Tidak ada riwayat transaksi.</div>
          <?php else:?>
          <div class="progress" id="progress" style="display: none;">
            <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">0%</div>
          </div>
          <?php echo form_open('akun/riwayat-transaksi/bayar');?>
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3><a id="dl-link" class="pull-right" href="#" title="Download <?php echo $total;?> transaksi"><i class="fa fa-download"></i></a><i class="fa fa-history"></i> Riwayat Transaksi</h3>
              </div>
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <?php if ($this->system->perm->bayar_masal == 'yes'):?><th class="text-center" style="width: 40px;">#</th><?php endif;?>
                      <th style="width: 115px;">Tanggal</th>
                      <th>Provider</th>
                      <th>Nominal</th>
                      <th>No. Telepon</th>
                      <th>Harga</th>
                      <th>Pembayaran</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody id="history_transaksi">
                    <?php foreach ($results as $trx): ?>
                    <tr>
                      <?php if ($this->system->perm->bayar_masal == 'yes'):?><td class="text-center" style="vertical-align: middle;"><input type="checkbox" name="trx_id[]" value="<?php echo $trx->tr_id;?>" <?php echo ($trx->tr_status_pembayaran == 'pending' && (time() < ($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']))) ? 'checked="checked"' : 'disabled="disabled"');?>/></td><?php endif;?>
                      <td style="vertical-align: middle;"><a href="<?php echo site_url('akun/riwayat-transaksi/view/' . $trx->tr_id); ?>"><?php echo format_tanggal($trx->tr_tanggal);?></a></td>
                      <td style="vertical-align: middle;"><?php echo html_escape($trx->op_nama);?></td>
                      <td style="vertical-align: middle;"><?php echo html_escape($trx->vo_nominal);?></td>
                      <td style="vertical-align: middle;"><?php echo html_escape($trx->tr_no_hp);?></td>
                      <td class="text-left"><?php echo format_uang2($trx->tr_harga, $trx->tr_rate, $this->payment->{$trx->tr_pembayaran}->template, $this->payment->{$trx->tr_pembayaran}->round);?></td>
                      <td style="vertical-align: middle;"><?php echo $trx->tr_pembayaran =='balance' ? 'Saldo Akun' : $this->payment->{$trx->tr_pembayaran}->nama;?></td>
                      <td style="vertical-align: middle;"><?php echo status_label($trx, $exp_time, false);?></td>
                    </tr>
                    <?php endforeach;?>
                  </tbody>
                </table>
              </div>              
            </div>
            <div class="row" id="action-links">
              <div class="col-sm-4 col-md-3"><?php if ($this->system->perm->bayar_masal == 'yes'):?><button type="submit" class="btn btn-primary btn-block btn-sm"><i class="fa fa-credit-card"></i> Bayar yang ditandai</button><?php endif;?></div>
              <div class="col-sm-8 col-md-9"><?php echo pagination(site_url('akun/riwayat-transaksi/index/'), $start, $total, $this->system->set['list_per_page'], '%d?no_hp='.$no_hp.'&amp;produk='.$produk.'&amp;pembayaran='.$pembayaran.'&amp;dari_tanggal='.$dari_tanggal.'&amp;ke_tanggal='.$ke_tanggal.'&amp;status='.$status);?></div>
            </div>
          <?php echo form_close();?>
          <?php endif;?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script src="<?php echo base_url('assets/js/bootstrap-datepicker.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/locales/bootstrap-datepicker.id.min.js');?>" charset="UTF-8"></script>
    <script type="text/javascript">
    function format_rp(price){var rev=price.toString().split('').reverse();var rev=rev.join('');var rev2='';for(var i=0;i<rev.length;i++){rev2+=rev[i];if((i+1)%3===0&&i!==(rev.length-1)){rev2+='.';}}var harga=rev2.split('').reverse().join('');return'Rp '+harga;}
    var progress = false;
    $(document.body).on("shown.bs.collapse",function(){if($("#ringkasan").hasClass("in")){$("#chevron").html('<i class="fa fa-chevron-up"></i>');}if(progress==false){progress=true;$.get("<?php echo site_url('akun/riwayat-transaksi/ringkasan').'?no_hp='.$no_hp.'&produk='.$produk.'&pembayaran='.$pembayaran.'&dari_tanggal='.$dari_tanggal.'&ke_tanggal='.$ke_tanggal.'&status='.$status;?>",function(data){$("#ringkasan").find("#spinner").remove();var html="";html+='<table class="table table-bordered"><thead><tr><th>Jenis Produk</th><th>Jumlah Transaksi</th><th>Jumlah Pembayaran</th></tr></thead>';html+='<tbody>';var total_trx=0;var total_pembayaran=0;for(var i=0;i<data.length;i++){total_trx+=data[i]['total_trx'];total_pembayaran+=data[i]['total_pembayaran'];html+='<tr><td>'+data[i]['produk']+'</td><td>'+data[i]['total_trx']+'</td><td>'+format_rp(data[i]['total_pembayaran'])+'</td></tr>'}html+='</tbody>';html+='<tfoot style="background-color: #f3f3f3;font-weight: bold;"><tr><td></td><td>'+total_trx+'</td><td>'+format_rp(total_pembayaran)+'</td></tr></tfoot></table>';$("#ringkasan").html(html);});}});
    $(document.body).on("hidden.bs.collapse",function(){if(!$("#ringkasan").hasClass("in")){$("#chevron").html('<i class="fa fa-chevron-down"></i>');}});
    <?php $tgl = explode(' ', format_tanggal(time()));?>
    $("#dari_tanggal").datepicker({format:"dd-mm-yyyy",endDate:"<?php echo str_replace('/', '-', $tgl[0]);?>",todayHighlight:true,autoclose:true,language:"id"});
    $("#ke_tanggal").datepicker({format:"dd-mm-yyyy",endDate:"<?php echo str_replace('/', '-', $tgl[0]);?>",todayHighlight:true,autoclose:true,language:"id"});
    <?php if ($total):?>
    var dl = false;
    $("#dl-link").click(function() {
      dl = true;
      $("#myModal").modal("show");
      return false;
    });
    $(document.body).on("show.bs.modal", function() {
      if (dl == false)
        return;
      setTimeout(function() {
        var html = '<form id="downloadForm" method="get" class="form-horizontal" action="#">';
        html += '<div class="form-group"><label class="col-sm-3 control-label">Format</label><div class="col-sm-9"><select class="form-control" name="format" required="required"><option value="xls">Excel (.xls)</option><option value="xlsx">Excel (.xlsx)</option></select></div></div>';
        html += '<div class="form-group" style="margin-bottom:0"><div class="col-sm-offset-3 col-sm-9"><button type="submit" class="btn btn-primary"><i class="fa fa-download"></i>Download</button>&nbsp;<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i>Batal</button></div></div>';
        html += '</form>';
        $(".modal-content").html('<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title">Download Riwayat Transaksi</h4></div><div class="modal-body">'+html+'</div>');
      }, 500);
    });
    $(document.body).on("show.bs.modal", function() {
      dl = false;
    });
    var errors = 0;
    function download(page, format) {
      $.get("<?php echo site_url('akun/riwayat-transaksi/ajax-download').'?no_hp='.$no_hp.'&produk='.$produk.'&pembayaran='.$pembayaran.'&dari_tanggal='.$dari_tanggal.'&ke_tanggal='.$ke_tanggal.'&status='.$status;?>&page="+page+"&format="+format, function(data) {
        $(".progress-bar").attr("aria-valuenow", data.progress).css("width", data.progress+"%").text(data.progress+"%");
        if (data.next_page > 0) {
          setTimeout(function() {
            download(data.next_page, format);
          }, 500);
        } else {
          setTimeout(function() {
            $("#dl-link").show();
            $("#progress").hide();
            window.location = "<?php echo site_url('akun/riwayat-transaksi/download');?>/"+format;
          }, 1000);
        }
      }).fail(function() {
        if (errors >= 5) {
          $("#dl-link").show();
          $("#progress").hide();
          alert("Terjadi kesalahan!");
        } else {
          errors += 1;
          setTimeout(function() {
            download(page, format);
          }, 500);
        }
      });
    }
    $(document).on("submit", "#downloadForm", function() {
      var format = $('#downloadForm [name="format"] option:selected').val();
      $("#dl-link").hide();
      $(".progress-bar").attr("aria-valuenow", "0").css("width", "0%").text("0%");
      $("#progress").show();
      $("[data-dismiss=modal]").trigger({ type: "click" });
      download(1, format);
      return false;
    });
    <?php endif;?>
    </script>
  </body>
</html>