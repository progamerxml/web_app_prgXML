<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Riwayat Transaksi</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Riwayat Transaksi</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-money"></i> Pembayaran Masal</h3>
            </div>
            <div class="panel-body" style="padding-bottom: 0;">
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Jenis Produk</th>
                      <th>Provider</th>
                      <th>Nominal</th>
                      <th>No. HP / ID Plgn</th>
                      <th>Harga</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($results as $trx): ?>
                    <tr>
                      <td><?php echo html_escape(property_exists($this->system->produk, $trx->op_produk) ? $this->system->produk->{$trx->op_produk}->nama : ucwords(str_replace('_',' ', $trx->op_produk)));?></td>
                      <td><?php echo html_escape($trx->op_nama);?></td>
                      <td><?php echo html_escape($trx->vo_nominal);?></td>
                      <td><?php echo html_escape($trx->tr_id_plgn ? $trx->tr_id_plgn : $trx->tr_no_hp);?></td>
                      <td><?php echo format_uang($trx->tr_harga2);?></td>
                    </tr>
                    <?php endforeach;?>
                  </tbody>
                  <tfoot style="background-color: #f9f9f9;">
                    <tr>
                      <td colspan="4"><strong>Total</strong></td>
                      <td><strong><?php echo format_uang($total_amount);?></strong></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <?php echo form_open();?>
                <div class="row">
                  <div class="col-sm-8 col-lg-9" style="margin-bottom: 15px;">
                    <select class="form-control" name="payment" required="required">
                      <option value="">-- Metode Pembayaran --</option>
                      <?php foreach ($this->payment->get() as $py) {
                        if ($py->status != 'on')
                          continue;
                        elseif ($py->user == 2 && !$this->user->verified)
                          echo '<option value="' . $py->key . '" disabled="disabled">' . $py->nama . ' (Hanya member terverifikasi)</option>';
                        else
                          echo '<option value="' . $py->key . '">' . $py->nama . '</option>';
                      } ?>
                    </select>
                  </div>
                  <div class="col-sm-4 col-lg-3" style="margin-bottom: 15px;">
                    <button type="submit" name="submit" value="bayar" class="btn btn-primary btn-block"><i class="fa fa-credit-card"></i> Bayar Semua</button>
                  </div>
                </div>
                <?php foreach ($results as $trx):?>
                <input type="hidden" name="trx_id[]" value="<?php echo $trx->tr_id;?>" />
                <?php endforeach;?>
              <?php echo form_close();?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>