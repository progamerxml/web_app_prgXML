<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Riwayat Transaksi &gt; Tagihan #<?php echo $trx->tg_id;?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li><a href="<?php echo site_url('akun/riwayat-transaksi');?>">Riwayat Transaksi</a></li>
        <li><a href="<?php echo site_url('akun/riwayat-transaksi/tagihan');?>">Tagihan</a></li>
        <li class="active"><span>Tagihan #<?php echo $trx->tg_id;?></span></li>
      </ul>
      <div class="row">
        <div class="col-sm-8">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-list-alt"></i> Tagihan #<?php echo $trx->tg_id;?></h3>
            </div>
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-striped">
                  <tbody>
                    <tr><td>Tagihan</td><td><?php echo html_escape($trx->tg_title);?></td></tr>
                    <tr><td>Keterangan</td><td><?php echo tg_keterangan($trx->us_id, $trx->tg_title, json_decode($trx->tg_opsi,true));?></td></tr>
                    <tr><td>Pembayaran</td><td><?php echo html_escape($this->payment->{$trx->tg_payment}->nama);?></td></tr>
                    <tr><td>Jumlah</td><td><?php echo format_uang2($trx->tg_amount, $trx->tg_rate, $this->payment->{$trx->tg_payment}->template, $this->payment->{$trx->tg_payment}->round);?></td></tr>
                    <tr><td>Tanggal</td><td><?php echo format_tanggal($trx->tg_tanggal);?></td></tr>
                    <tr><td>Status</td><td><?php echo tg_status($trx->tg_tanggal, $trx->tg_status, $exp_time);?></td></tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="panel-footer hidden-print">
              <button type="button" id="komplain" class="btn btn-warning pull-right"><i class="fa fa-exclamation-circle"></i> Komplain</button>
              <?php if ($trx->tg_status === 'pending' && $trx->tg_tanggal > $exp_time):?>
              <a class="btn btn-danger" href="<?php echo site_url('akun/riwayat-transaksi/tagihan/cancel/'.$trx->tg_id);?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-remove"></i> Batalkan</a>
              <?php endif;?>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <?php if ($trx->tg_payment == 'balance'):?>
          <?php if ($trx->tg_status == 'refund'):?>
          <div class="alert alert-success">
            <h3>Refund</h3>Pembayaran direfund ke saldo akun.
          </div>
          <?php else:?>
          <div class="alert alert-success">
            <h3>Sukses</h3>Pembayaran sudah diselesaikan dengan menggunakan saldo akun.
          </div>
          <?php endif;?>
          <?php else:?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-money"></i> Bayar Dengan <?php echo $this->payment->{$trx->tg_payment}->nama;?></h3>
            </div>
            <?php if (file_exists(FCPATH.'assets/payments/'.$trx->tg_payment.'.png')):?>
            <div class="panel-body" style="margin-bottom: 0;padding-bottom: 0;">
              <div class="text-center"><img src="<?php echo base_url('assets/payments/'.$trx->tg_payment.'.png');?>" class="img-thumbnail" style="margin: 0 auto;"/></div>
            </div>
            <?php endif;?>
            <?php if ($this->payment->{$trx->tg_payment}->status != 'on'):?>
            <div class="panel-body">
              <div class="alert alert-danger">Pembayaran <?php echo $this->payment->{$trx->tg_payment}->nama;?> saat ini sedang tidak aktif.</div>
            </div>
            <?php elseif ($trx->tg_status == 'pending' && $trx->tg_tanggal < $exp_time):?>
            <div class="panel-body">
              <div class="alert alert-danger">Pembayaran belum diselesaikan dan pesanan sudah tidak berlaku lagi.</div>
            </div>
            <?php elseif ($trx->tg_status == 'refund'):?>
            <div class="panel-body">
              <div class="alert alert-info">Pembayaran direfund.</div>
            </div>
            <?php else:?>
            <?php
            $is_tagihan = true;
            @include_once(VIEWPATH.'akun/riwayat_transaksi/'.$trx->tg_payment.'.php');
            ?>
            <?php endif;?>
          </div>
          <?php endif;?>
        </div>                
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <?php
    $content =  '<ul class="list-unstyled">
        <li><a href="'.site_url('contact-us?pesan='.urlencode('Komplain Pembayaran Masal: '.$trx->tg_id.' > Sudah transfer tapi status pembayaran masih pending')).'">Sudah transfer tapi status pembayaran masih pending</a></li>
        <li><a href="'.site_url('contact-us?pesan='.urlencode('Komplain Pembayaran Masal: '.$trx->tg_id.' > Data transfer salah')).'">Data transfer salah</a></li></li>
        <li><a href="'.site_url('contact-us?pesan='.urlencode('Komplain Pembayaran Masal: '.$trx->tg_id.' > ')).'">Masalah lainnya</a></li></li>
        </ul>';
    ?>
    <script>
    $(function () {
        $('#komplain').popover(<?php echo json_encode(array('title'=>'Pilih topik permasalahan','content'=>$content,'html'=>true,'placement'=>'top'));?>);
    })
    </script>
  </body>
</html>