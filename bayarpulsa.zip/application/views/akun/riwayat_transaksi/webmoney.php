<?php if (isset($is_tagihan)):?>
<!-- Tagihan -->
<?php if ($trx->tg_status == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>Jumlah</td><td><?php echo format_uang2($trx->tg_amount, $trx->tg_rate, $this->payment->webmoney->template, $this->payment->webmoney->round);?></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tg_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <form method="POST" action="https://merchant.wmtransfer.com/lmi/payment.asp" accept-charset="windows-1251" target="_blank">
    <input type="hidden" name="LMI_PAYEE_PURSE" value="<?php echo $this->payment->webmoney->data->nomor_rekening;?>"/>
    <input type="hidden" name="LMI_PAYMENT_AMOUNT" value="<?php echo round($trx->tg_amount / $trx->tg_rate, 2);?>"/>
    <input type="hidden" name="LMI_PAYMENT_NO" value="<?php echo $trx->tg_id;?>"/>
    <input type="hidden" name="LMI_PAYMENT_DESC" value="<?php echo 'Tagihan #'.$trx->tg_id;?>"/>
    <input type="hidden" name="LMI_SIM_MODE" value="0"/>
    <input type="hidden" name="LMI_RESULT_URL" value="<?php echo site_url('payment/webmoney/tagihan/'.$trx->tg_id);?>"/>
    <input type="hidden" name="LMI_SUCCESS_URL" value="<?php echo site_url('akun/riwayat-transaksi/tagihan/view/'.$trx->tg_id);?>"/>
    <input type="hidden" name="LMI_SUCCESS_METHOD" value="2"/>
    <input type="hidden" name="LMI_FAIL_URL" value="<?php echo site_url('akun/riwayat-transaksi/tagihan/view/'.$trx->tg_id);?>"/>
    <input type="hidden" name="LMI_FAIL_METHOD" value="2"/>
    <input type="hidden" name="LMI_FAIL_METHOD" value="2"/>
    <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-money"></i> Bayar Sekarang</button>
  </form>
</div>
<?php endif;?>
<!-- End -->
<?php else:?>
<!-- Transaksi -->
<?php if ($trx->tr_status_pembayaran == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>Jumlah</td><td><?php echo format_uang2($trx->tr_harga, $trx->tr_rate, $this->payment->webmoney->template, $this->payment->webmoney->round);?></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <form method="POST" action="https://merchant.wmtransfer.com/lmi/payment.asp" accept-charset="windows-1251" target="_blank">
    <input type="hidden" name="LMI_PAYEE_PURSE" value="<?php echo $this->payment->webmoney->data->nomor_rekening;?>"/>
    <input type="hidden" name="LMI_PAYMENT_AMOUNT" value="<?php echo round($trx->tr_harga / $trx->tr_rate, 2);?>"/>
    <input type="hidden" name="LMI_PAYMENT_NO" value="<?php echo $trx->tr_id;?>"/>
    <input type="hidden" name="LMI_PAYMENT_DESC" value="<?php echo html_escape($this->system->produk->{$trx->op_produk}->nama.' '.$trx->op_nama.' '.$trx->vo_nominal.' ('.$trx->tr_id_pembayaran.')');?>"/>
    <input type="hidden" name="LMI_SIM_MODE" value="0"/>
    <input type="hidden" name="LMI_RESULT_URL" value="<?php echo site_url('payment/webmoney/trx/'.$trx->tr_id);?>"/>
    <input type="hidden" name="LMI_SUCCESS_URL" value="<?php echo site_url('history/view/'.$trx->tr_id);?>"/>
    <input type="hidden" name="LMI_SUCCESS_METHOD" value="2"/>
    <input type="hidden" name="LMI_FAIL_URL" value="<?php echo site_url('history/view/'.$trx->tr_id);?>"/>
    <input type="hidden" name="LMI_FAIL_METHOD" value="2"/>
    <input type="hidden" name="LMI_FAIL_METHOD" value="2"/>
    <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-money"></i> Bayar Sekarang</button>
  </form>
</div>
<?php endif;?>
<!-- End -->
<?php endif;?>