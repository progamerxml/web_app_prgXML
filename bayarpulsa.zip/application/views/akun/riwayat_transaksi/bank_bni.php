<?php if (isset($is_tagihan)):?>
<!-- Tagihan -->
<?php if ($trx->tg_status == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>No. Rekening</td><td><?php echo html_escape($this->payment->bank_bni->data->nomor_rekening);?></td></tr>
        <tr><td>Atas Nama</td><td><?php echo html_escape($this->payment->bank_bni->data->nama_rekening);?></td></tr>
        <tr><td>Harga</td><td><?php echo format_uang2($trx->tg_amount2);?></td></tr>
        <tr><td>Kode Unik</td><td><?php echo format_uang2($trx->tg_amount - $trx->tg_amount2);?></td></tr>
        <tr><td>Total</td><td><strong><?php echo format_uang2($trx->tg_amount);?></strong></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
    <li>Silakan lakukan transfer sebesar <strong><?php echo format_uang2($trx->tg_amount);?></strong>.</li>
    <?php if ($trx->us_id):?>
    <li>Harga unik sebesar <?php echo format_uang2($trx->tg_amount - $trx->tg_amount2);?> akan dikembalikan ke saldo deposit Anda.</li>
    <?php endif;?>
    <li>Setelah melakukan pembayaran silakan klik tombol &quot;<b>Konfirmasi Pembayaran</b>&quot;.</li>
    <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tg_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <a href="<?php echo site_url('payment/bank_bni/tagihan/'.$trx->tg_id);?>" class="btn btn-primary btn-block" id="submit-confirm"><i class="fa fa-check"></i> Konfirmasi Pembayaran</a>
</div>
<?php endif;?>
<!-- End -->
<?php else:?>
<!-- Transaksi -->
<?php if ($trx->tr_status_pembayaran == 'sukses'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>No. Rekening</td><td><?php echo html_escape($this->payment->bank_bni->data->nomor_rekening);?></td></tr>
        <tr><td>Atas Nama</td><td><?php echo html_escape($this->payment->bank_bni->data->nama_rekening);?></td></tr>
        <tr><td>Harga</td><td><?php echo format_uang2($trx->tr_harga2);?></td></tr>
        <tr><td>Kode Unik</td><td><?php echo format_uang2($trx->tr_harga - $trx->tr_harga2);?></td></tr>
        <tr><td>Total</td><td><strong><?php echo format_uang2($trx->tr_harga);?></strong></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
    <li>Silakan lakukan transfer sebesar <strong><?php echo format_uang2($trx->tr_harga);?></strong>.</li>
    <?php if ($trx->us_id):?>
    <li>Harga unik sebesar <?php echo format_uang2($trx->tr_harga - $trx->tr_harga2);?> akan dikembalikan ke saldo deposit Anda.</li>
    <?php endif;?>
    <li>Jika memungkinkan, Anda juga dapat mentransfer sejumlah <strong><?php echo format_uang2($trx->tr_harga2);?></strong> dan masukan berita transfer <strong><?php echo $trx->tr_id_pembayaran;?></strong>.</li>
    <li>Setelah melakukan pembayaran silakan klik tombol &quot;<b>Konfirmasi Pembayaran</b>&quot;.</li>
    <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->tr_tanggal + (3600 * $this->system->set['jam_pembayaran']));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <a href="<?php echo site_url('payment/bank_bni/trx/'.$trx->tr_id);?>" class="btn btn-primary btn-block" id="submit-confirm"><i class="fa fa-check"></i> Konfirmasi Pembayaran</a>
</div>
<?php endif;?>
<!-- End -->
<?php endif;?>