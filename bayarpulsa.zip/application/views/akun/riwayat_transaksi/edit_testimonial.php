<?php echo form_open(current_url());?>
  <div class="form-group">
    <label>Pesan</label>
    <textarea class="form-control" name="testimonial" rows="4" maxlength="160"><?php echo set_value('testimonial',$testimonial->pesan);?></textarea>
  </div>
  <div>
    <button type="submit" name="submit" value="testimonial" class="btn btn-primary">Simpan</button>
    &nbsp;
    <a class="btn btn-default" data-dismiss="modal" href="<?php echo site_url('akun/riwayat-transaksi/view/'.$testimonial->tr_id);?>">Batal</a>
  </div>
<?php echo form_close();?>