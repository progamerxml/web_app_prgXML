<?php
defined('BASEPATH') or exit('No direct script access allowed');
$opsi = $trx->tr_opsi ? json_decode($trx->tr_opsi, true) : array(); ?>
<!DOCTYPE html>
<html>

<head>
  <title>Rincian Transaksi #<?php echo $trx->tr_id; ?></title>
  <?php include_once(VIEWPATH . 'includes/head.php'); ?>
</head>

<body>
  <?php include_once(VIEWPATH . 'includes/navbar.php'); ?>
  <div class="container">
    <ul class="breadcrumb">
      <li><a href="<?php echo site_url(); ?>"><i class="fa fa-home"></i></a></li>
      <li><a href="<?php echo site_url('akun/profil'); ?>">Akun Saya</a></li>
      <li><a href="<?php echo site_url('akun/riwayat-transaksi'); ?>">Riwayat Transaksi</a></li>
      <li class="active"><span>Transaksi #<?php echo $trx->tr_id; ?></span></li>
    </ul>
    <div class="row">
      <div class="col-sm-4 col-md-3 hidden-print">
        <?php include(dirname(__FILE__) . '/../_sidebar.php'); ?>
      </div>
      <div class="col-sm-8 col-md-9">
        <?php if ($trx->us_id == 0) : ?>
          <div class="row">
            <div class="col-sm-12">
              <div class="alert alert-warning alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                Transaksi ini diorder oleh non member yang menggunakan No. HP kamu <?php echo $trx->tr_no_hp; ?> yang sudah terverifikasi.
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="row">
          <div class="col-sm-12 col-md-7">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3><i class="fa fa-list-alt"></i> Transaksi #<?php echo $trx->tr_id; ?></h3>
              </div>
              <?php
              if (file_exists(VIEWPATH . 'akun/riwayat_transaksi/' . $trx->op_produk . '.php'))
                include(VIEWPATH . 'akun/riwayat_transaksi/' . $trx->op_produk . '.php');
              else
                include(VIEWPATH . 'akun/riwayat_transaksi/undefined.php');
              ?>
              <div class="panel-footer hidden-print" style="padding-bottom: 0;">
                <?php
                if ($trx->tr_status_pembayaran == 'pending' && $trx->tr_tanggal > (time() - (3600 * $this->system->config('jam_pembayaran'))) && $this->system->perm->cancel_order == 'yes') {
                  $cancel = true;
                } else {
                  $cancel = false;
                }
                ?>
                <div class="row">
                  <div class="<?php echo $cancel ? 'col-sm-4' : 'col-sm-6'; ?>">
                    <a class="btn btn-default btn-block" href="#" onclick="window.print();return false;" style="margin-bottom: 15px;"><i class="fa fa-print"></i> Print</a>
                  </div>
                  <div class="<?php echo $cancel ? 'col-sm-4' : 'col-sm-6'; ?>">
                    <?php /** TODO: v3.9.4 */ if (property_exists($trx, "ppob_amount")) : ?>
                      <button type="button" id="payButton" data-token-name="<?php echo $this->security->get_csrf_token_name(); ?>" data-token-hash="<?php echo $this->security->get_csrf_hash(); ?>" class="btn btn-primary btn-block" style="margin-bottom: 15px;"><i class="fa fa-credit-card"></i> Bayar <?php echo format_uang2($trx->ppob_amount); ?></button>
                    <?php else : ?>
                      <button type="button" id="komplain" class="btn btn-warning btn-block" style="margin-bottom: 15px;"><i class="fa fa-exclamation-circle"></i> Komplain</button>
                    <?php endif; ?>
                  </div>
                  <?php if ($cancel) : ?>
                    <div class="col-sm-4">
                      <a class="btn btn-danger btn-block" href="<?php echo site_url('akun/riwayat-transaksi/cancel/' . $trx->tr_id); ?>" data-toggle="modal" data-target="#myModal" style="margin-bottom: 15px;"><i class="fa fa-times"></i> Batalkan</a>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-md-5 hidden-print">
            <?php if (isset($opsi['shipping'])) : ?>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3><i class="fa fa-truck"></i> Pengiriman</h3>
                </div>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <tbody>
                      <tr>
                        <td>Dikirim Dari</td>
                        <td><?php echo html_escape($opsi['shipping']['from']['city'] . ' - ' . $opsi['shipping']['from']['province']); ?></td>
                      </tr>
                      <tr>
                        <td>Harga Barang</td>
                        <td><?php echo @$opsi['quantity']; ?> x <?php echo format_uang2($opsi['original_amount']); ?></td>
                      </tr>
                      <tr>
                        <td>Berat Barang</td>
                        <td><?php echo @$opsi['weight']; ?></td>
                      </tr>
                      <tr>
                        <td>Jasa Pengiriman</td>
                        <td><?php echo html_escape($opsi['shipping']['courier']['name']); ?></td>
                      </tr>
                      <tr>
                        <td>Biaya Kirim</td>
                        <td><?php echo format_uang2(@$opsi['shipping']['courier']['cost']); ?></td>
                      </tr>
                      <tr>
                        <td>Nomor Resi</td>
                        <td><?php echo html_escape(@$opsi['shipping']['awb_number']); ?></td>
                      </tr>
                      <tr>
                        <td>Status Pengiriman</td>
                        <td><?php if (@$opsi['shipping']['delivery_status'] == 'belum_dikirim') : ?><?php echo ucwords(str_replace("_", " ", @$opsi['shipping']['delivery_status'])); ?><?php else : ?><a data-toggle="modal" data-target="#myModal" href="<?php echo site_url('status-pengiriman/trx/' . $trx->tr_id . '/' . @$opsi['shipping']['awb_number']); ?>"><?php echo ucwords(str_replace("_", " ", @$opsi['shipping']['delivery_status'])); ?> <i class="fa fa-external-link"></i></a><?php endif; ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3><i class="fa fa-user"></i> Penerima</h3>
                </div>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <tbody>
                      <tr>
                        <td>Nama</td>
                        <td><?php echo html_escape($opsi['shipping']['to']['name']); ?></td>
                      </tr>
                      <tr>
                        <td>No. Telepon</td>
                        <td><?php echo html_escape($opsi['shipping']['to']['phone']); ?></td>
                      </tr>
                      <tr>
                        <td>Provinsi</td>
                        <td><?php echo html_escape($opsi['shipping']['to']['province']); ?></td>
                      </tr>
                      <tr>
                        <td>Kota</td>
                        <td><?php echo html_escape($opsi['shipping']['to']['city']); ?></td>
                      </tr>
                      <tr>
                        <td>Kode POS</td>
                        <td><?php echo html_escape($opsi['shipping']['to']['postal_code']); ?></td>
                      </tr>
                      <tr>
                        <td>Alamat</td>
                        <td><?php echo html_escape($opsi['shipping']['to']['address']); ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            <?php endif; ?>
            <?php if ($trx->tr_pembayaran == 'balance') : ?>
              <?php if ($trx->tr_status_pembayaran == 'refund') : ?>
                <div class="alert alert-success">
                  <h3>Refund</h3>Pembayaran direfund ke Saldo Akun member.
                </div>
              <?php else : ?>
                <div class="alert alert-success">
                  <h3>Sukses</h3>Pembayaran sudah diselesaikan dengan menggunakan saldo akun.
                </div>
              <?php endif; ?>
            <?php else : ?>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3><i class="fa fa-money"></i> Bayar dengan <?php echo $this->payment->{$trx->tr_pembayaran}->nama; ?></h3>
                </div>
                <?php if (file_exists(FCPATH . 'assets/payments/' . $trx->tr_pembayaran . '.png')) : ?>
                  <div class="panel-body" style="margin-bottom: 0;padding-bottom: 0;">
                    <div class="text-center"><img src="<?php echo base_url('assets/payments/' . $trx->tr_pembayaran . '.png'); ?>" class="img-thumbnail" style="margin: 0 auto;" /></div>
                  </div>
                <?php endif; ?>
                <?php if ($this->payment->{$trx->tr_pembayaran}->status != 'on') : ?>
                  <div class="panel-body">
                    <div class="alert alert-danger">Pembayaran <?php echo $this->payment->{$trx->tr_pembayaran}->nama; ?> saat ini sedang tidak aktif.</div>
                  </div>
                <?php elseif ($trx->tr_status_pembayaran == 'pending' && $trx->tr_tanggal < $exp_time) : ?>
                  <div class="panel-body">
                    <div class="alert alert-danger">Pembayaran belum diselesaikan dan pesanan sudah tidak berlaku lagi.</div>
                  </div>
                <?php elseif ($trx->tr_status_pembayaran == 'refund') : ?>
                  <div class="panel-body">
                    <div class="alert alert-info">Pembayaran direfund.</div>
                  </div>
                <?php else : ?>
                  <?php include_once(VIEWPATH . 'akun/riwayat_transaksi/' . $trx->tr_pembayaran . '.php'); ?>
                <?php endif; ?>
              </div>
            <?php endif; ?>
            <?php if ($trx->tr_status_pembayaran == 'sukses' && $trx->tr_status == 'sukses') : ?>
              <div class="panel panel-default" id="testimonial">
                <div class="panel-heading">
                  <h3><i class="fa fa-comments-o"></i> Testimonial</h3>
                </div>
                <div class="panel-body">
                  <?php if (!$testimonial) : ?>
                    <p>Kamu belum mengirimkan testimonial untuk transaksi ini.</p>
                    <?php echo form_open(current_url() . '#testimonial'); ?>
                    <div class="form-group">
                      <label>Pesan</label>
                      <textarea class="form-control" name="testimonial" rows="4" maxlength="160"><?php echo set_value('testimonial'); ?></textarea>
                    </div>
                    <div>
                      <button type="submit" name="submit" value="testimonial" class="btn btn-primary btn-block">Kirim Testimonial</button>
                    </div>
                    <?php echo form_close(); ?>
                  <?php else : ?>
                    <div>
                      <span class="text-muted pull-right"><small><i class="fa fa-clock-o"></i> <?php echo format_tanggal($testimonial->tanggal); ?></small></span>
                      <strong><i class="fa fa-user"></i> <?php echo html_escape($testimonial->nama); ?></strong>&nbsp;
                    </div>
                    <p style="margin-bottom: 0;">
                      <?php echo nl2br(html_escape($testimonial->pesan)); ?>
                      <?php if ($testimonial->tanggal > (time() - (3600 * 24))) : ?>
                        &nbsp;<a href="<?php echo site_url('akun/riwayat-transaksi/view/' . $trx->tr_id . '/edit-testimonial'); ?>" data-toggle="modal" data-target="#myModal">[Edit]</a>
                      <?php endif; ?>
                    </p>
                  <?php endif; ?>
                </div>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php include_once(VIEWPATH . 'includes/foot.php'); ?>
  <?php
  $content =  '<ul class="list-unstyled">
        <li><a href="' . site_url('contact-us?trx_id=' . $trx->tr_id . '&amp;pesan=' . urlencode('Sudah membayar tapi status pembayaran masih pending')) . '">Sudah membayar tapi status pembayaran masih pending</a></li>
        <li><a href="' . site_url('contact-us?trx_id=' . $trx->tr_id . '&amp;pesan=' . urlencode('Sudah membayar tapi status pengisian masih pending')) . '">Sudah membayar tapi status pengisian masih pending</a></li>
        <li><a href="' . site_url('contact-us?trx_id=' . $trx->tr_id . '&amp;pesan=' . urlencode('Keterangan status pengisian sukses tapi pulsa belum masuk')) . '">Keterangan status pengisian sukses tapi pulsa belum masuk</a></li>
        <li><a href="' . site_url('contact-us?trx_id=' . $trx->tr_id . '&amp;pesan=' . urlencode('Data transfer salah')) . '">Data transfer salah</a></li></li>
        <li><a href="' . site_url('contact-us?trx_id=' . $trx->tr_id) . '">Masalah lainnya</a></li></li>
        </ul>';
  ?>
  <script>
    $(function() {
      $('#komplain').popover(<?php echo json_encode(array('title' => 'Pilih topik permasalahan', 'content' => $content, 'html' => true, 'placement' => 'top')); ?>);
      <?php /** TODO: v3.9.4 */ if (property_exists($trx, "ppob_amount")) : ?>
        <?php
        $reseller_config = json_decode($this->system->get_set('reseller'));
        $payment_active = '';
        $payment_inactive = '';
        foreach ($this->payment->get() as $payment) {
          if ($payment->status == 'off')
            continue;
          elseif ($this->user->is_reseller && $reseller_config->payment == 'balance' && $payment->key != 'balance')
            $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member)</option>';
          elseif ($payment->user == 1 && !$this->user->is_user())
            $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member)</option>';
          elseif ($payment->user == 2 && !$this->user->verified)
            $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Hanya member terverifikasi)</option>';
          elseif ($this->system->produk->{$trx->ppob_pay->op_produk}->payments && !in_array($payment->key, $this->system->produk->{$trx->ppob_pay->op_produk}->payments))
            $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Tidak diijinkan)</option>';
          elseif ($this->payment->is_offline($payment->key))
            $payment_inactive .= '<option value="' . $payment->key . '" disabled="disabled">' . $payment->nama . ' (Offline)</option>';
          else
            $payment_active .= '<option value="' . $payment->key . '">' . $payment->nama . '</option>';
        }
        ?>
        var captchaField = '<div class="form-group" id="captcha" style="margin-top:15px;display:<?php echo $this->system->perm->captcha_order == 'yes' ? 'block' : 'none';?>"><label>Kode Keamanan</label><div class="input-group"><span class="input-group-addon" style="padding: 0;"><img id="captcha-image" src="<?php echo site_url('captcha?r=' . time()); ?>" style="height:30px"/></span><input type="text" name="captcha" class="form-control" <?php echo $this->system->perm->captcha_order == 'yes' ? 'required="required"' : '';?> placeholder="Kode keamanan" autocomplete="off"/></div></div>';
        $("#payButton").click(function() {
          $("body").append('<div class="modal fade" id="payModal" tabindex="-1" role="dialog" aria-labelledby="payModal-label" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"></div></div></div>');
          var mContent = '<form id="payForm" method="post" action="<?php echo site_url($trx->ppob_pay->op_produk); ?>"><input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">' +
            '<input type="hidden" name="nomor_hp" value="<?php echo html_escape($trx->tr_no_hp); ?>">' +
            '<input type="hidden" name="id_plgn" value="<?php echo html_escape($trx->tr_id_plgn); ?>">' +
            '<input type="hidden" name="operator" value="<?php echo $trx->ppob_pay->op_id; ?>">' +
            '<input type="hidden" name="voucher" value="<?php echo $trx->ppob_pay->vo_id; ?>">' +
            '<input type="hidden" name="json_format" value="1">' +
            '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" ' +
            'aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title">Informasi' +
            ' Tagihan</h4></div><div class="modal-body"><p style="margin-bottom: 15px;">Pembayaran tagihan <?php echo html_escape($trx->op_nama); ?> sudah tersedia, jika kamu belum melakukan pembayaran silakan klik tombol <span class="label label-primary">Bayar Sekarang</span> untuk melakukan pembayaran.</p><dl><dt>Rincian Tagihan</dt><dd style="margin-bottom:5px"><?php echo html_escape($trx->ppob_sn); ?></dd><dt>Jumlah Tagihan</dt><dd><?php echo format_uang2($trx->ppob_amount); ?></dd></dl>' +
            '<div class="form-group" style="margin-bottom:0"><label>Pembayaran</label><select class="form-control" name="pembayaran"><?php echo $payment_active . $payment_inactive; ?></select></div>' + captchaField +
            '</div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button><button class="btn btn-primary" id="paySubmitBtn" type="submit" style="margin-left: 15px;"><i class="fa fa-credit-card"></i> Bayar Sekarang</button></div></form>';
          $("#payModal").modal({
            backdrop: 'static',
            keyboard: false
          });
          setTimeout(function() {
            $("#payModal .modal-content").html(mContent);
          }, 1000);
          return false;
        });
        $("#payButton").trigger("click");
        $(document).on("submit", "#payForm", function() {
          $("#paySubmitBtn").button('loading');
          var url = $(this).attr('action');
          $.post(url, $(this).serialize(), function(data) {
              if (data.success) {
                window.location.href = "<?php echo site_url('history/view'); ?>/" + data.id;
              } else {
                for (i = 0; i < data.errors.length; i++) {
                  $.notify(data.errors[i], "error");
                }
                $.get("<?php echo current_url(); ?>", function(data) {
                  var csrf = $(data).find('[data-token-name="<?php echo $this->security->get_csrf_token_name(); ?>"]').data("token-hash");
                  $('[name="<?php echo $this->security->get_csrf_token_name(); ?>"]').val(csrf);
                  <?php if ($this->system->perm->captcha_order == 'yes') : ?>
                    var captcha = $(data).find('#captcha-image').attr('src');
                    $("#captcha-image").attr("src", captcha);
                    $("#captcha .form-control").val('');
                  <?php endif; ?>
                })
                $("#paySubmitBtn").button('reset');
              }
            })
            .fail(function() {
              $.get("<?php echo current_url(); ?>", function(data) {
                var csrf = $(data).find('[data-token-name="<?php echo $this->security->get_csrf_token_name(); ?>"]').data("token-hash");
                $('[name="<?php echo $this->security->get_csrf_token_name(); ?>"]').val(csrf);
                <?php if ($this->system->perm->captcha_order == 'yes') : ?>
                  var captcha = $(data).find('#captcha-image').attr('src');
                  $("#captcha-image").attr("src", captcha);
                  $("#captcha .form-control").val('');
                <?php endif; ?>
              })
              $.notify("Terjadi kesalahan saat memproses permintaan, silakan coba lagi atau refresh halaman ini.", "error");
              $("#paySubmitBtn").button('reset');
            })
          return false;
        });
      <?php endif; ?>
    });
  </script>
</body>

</html>