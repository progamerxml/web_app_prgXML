<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Transaksi Via SMS | <?php echo html_escape($this->system->set['site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Transaksi Via SMS</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-envelope-o"></i> Transaksi Via SMS</h3>
            </div>
            <div class="panel-body">
              <?php if ($set['user'] == 'none'):?>
              <div class="alert alert-warning">Fitur transaksi melalui SMS saat ini tidak tersedia.</div>
              <?php elseif ($set['user'] == 'verified' && !$this->user->verified):?>
              <div class="alert alert-warning">Fitur transaksi melalui SMS hanya diperbolehkan untuk member terverifikasi.</div>
              <?php elseif ($set['user'] == 'reseller' && !$this->user->is_reseller):?>
              <div class="alert alert-warning">Fitur transaksi melalui SMS hanya diperbolehkan untuk reseller.</div>
              <?php else:?>
              Kami berkomitmen memberikan pelayanan yang terbaik bagi member kami salah satunya dengan cara menyediakan layanan transaksi melalui SMS, jadi kamu tidak repor - repot lagi mengunjungi web kami dan pastinya tidak dikenankan biaya internet, cukup dengan mengirim SMS ke nomor SMS Center kami maka transaksi anda akan kami proses.
              <br />
              <br />
              Untuk menggunakan layanan ini kamu harus membuat PIN transaksi <a href="<?php echo site_url('akun/pengaturan/pin');?>" target="_blank">di sini</a> dan pastikan nomor HP kamu sudah <a href="<?php echo site_url('akun/verifikasi');?>" target="_blank">terverifikasi</a>.
              <br />
              <br />
              <h4>Format Transaksi</h4>
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>Transaksi</th>
                      <th>Format</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    foreach ($this->system->produk as $pr_k=>$pr_val) {
                        if ($pr_val->status == 'off')
                            continue;
                    ?>
                    <tr>
                      <td>Order <?php echo $pr_val->nama;?></td>
                      <td><?php echo (property_exists($pr_val->form,'id_plgn')) ? "<strong>KODE</strong>".html_escape($set['pemisah'])."<strong>".str_replace(' ','', strtoupper($pr_val->form->id_plgn->label))."</strong>".html_escape($set['pemisah'])."<strong>PIN</strong>".html_escape($set['pemisah'])."<strong>NOHPTUJUAN</strong>" : "<strong>KODE</strong>".html_escape($set['pemisah'])."<strong>NOHPTUJUAN</strong>".html_escape($set['pemisah'])."<strong>PIN</strong>";?></td>
                    </tr>
                    <?php } ?>
                    <?php if ($set['cek_saldo']):?>
                    <tr>
                      <td>Cek Saldo</td>
                      <td><strong>S</strong><?php echo html_escape($set['pemisah']);?><strong>PIN</strong></td>
                    </tr>
                    <?php endif;?>
                    <?php if ($set['deposit']):?>
                    <tr>
                      <td>Tambah Saldo</td>
                      <td><strong>DEPOSIT</strong><?php echo html_escape($set['pemisah']);?><strong>JUMLAH</strong><?php echo html_escape($set['pemisah']);?><strong>PEMBAYARAN</strong><?php echo html_escape($set['pemisah']);?><strong>PIN</strong></td>
                    </tr>
                    <?php endif;?>
                    <?php if ($set['history']):?>
                    <tr>
                      <td>Cek Riwayat Transaksi</td>
                      <td><strong>LAP</strong><?php echo html_escape($set['pemisah']);?><strong>TANGGAL</strong><?php echo html_escape($set['pemisah']);?><strong>PIN</strong></td>
                    </tr>
                    <?php endif;?>
                    <tr>
                      <td>Komplain</td>
                      <td><strong>K</strong><?php echo html_escape($set['pemisah']);?><strong>PESAN</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p>* Untuk melihat kode - kode voucher / nominal yang tersedia silakan <a href="<?php echo site_url('harga');?>">kunjungi daftar harga</a>.</p>
              <?php if ($set['deposit']):?>
              <p>* Pembayaran Deposit yang tersedia:
              <?php
              $payments = array();
              $deposit = json_decode($this->system->get_set('deposit'),true);
              foreach($this->payment->get() as $payment) {
                if ($payment->key != 'balance' && $payment->status == 'on' && in_array($payment->key, $deposit['payments'])) {
                    $payments[] = '<strong>'.strtoupper(str_replace('_','', $payment->key)).'</strong>';
                }
              }
              echo implode(', ', $payments);
              ?>.</p>
              <?php endif;?>
              <br />
              <h4>SMS Center</h4>
              <ul class="list-unstyled">
                <?php
                $centers = explode(',', $set['sms_center']);
                foreach ($centers as $center) {
                ?>
                <li><?php echo $center;?></li>
                <?php } ?>
              </ul>
              <br />
              Silakan kirim SMS sesuai format transaksi ke nomor SMS Center.
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>