<?php echo form_open(current_url(),'class="form-horizontal"');?>
  <div class="form-group">
    <label class="col-sm-3 control-label">Kode Verifikasi</label>
    <div class="col-sm-8 col-md-9">
      <input type="text" class="form-control" name="code" value="<?php echo set_value('code');?>" required="required"/>
      <p class="help-block">Belum punya kode verifikasi?, <a href="<?php echo site_url('akun/verifikasi/kode/'.$this->router->fetch_method());?>">klik di sini</a> untuk mengirim.</p>
    </div>
  </div>
  <div class="form-group" style="margin-bottom: 0;">
    <div class="col-sm-offset-3 col-sm-9">
      <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Kirim</button>
      &nbsp;
    <a href="<?php echo site_url('akun/verifikasi');?>" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i> Batal</a>
    </div>
  </div>
<?php echo form_close();?>