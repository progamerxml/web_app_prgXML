<?php
defined('BASEPATH') or exit('No direct script access allowed');
if (@$_SERVER['HTTP_USER_AGENT'] == "WebView")
  $modal_tag = '';
else
  $modal_tag = 'data-toggle="modal" data-target="#myModal"';
?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <title>
      Akun Saya &gt; Verfikasi | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun');?>">Akun Saya</a></li>
        <li class="active"><span>Verifikasi</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-check-circle"></i> Verifikasi Akun
              </h3>
            </div>
            <div class="panel-body">
              <div class="alert alert-info">
                Karena maraknya penipuan online maka dari itu kami membutuhkan beberapa data untuk memverifikasi akun anda.
              </div>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Nama</th>
                      <th>Data</th>
                      <th>Verifikasi</th>
                      <th>Status</th>
                      <th>Tindakan</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Email</td>
                      <td><?php echo $this->user->data['us_email'];?></td>
                      <td><?php echo (in_array('email', $this->system->perm->user_verified) ? 'Dibutuhkan' : 'Opsional');?></td>
                      <td><?php echo ($this->user->email_verified ? '<span class="text-success">Terverifikasi</span>' : '<span class="text-danger">Belum Terverifikasi</span>');?></td>
                      <td><?php echo ($this->user->email_verified ? '<span class="text-success"><i class="fa fa-check"></i></span>' : '<a href="'.site_url('akun/verifikasi/email').'" '.$modal_tag.'>Verifikasi</a>');?></td>
                    </tr>
                    <tr>
                      <td>No. HP</td>
                      <td><?php echo $this->user->data['us_phone'];?></td>
                      <td><?php echo (in_array('phone', $this->system->perm->user_verified) ? 'Dibutuhkan' : 'Opsional');?></td>
                      <td><?php echo ($this->user->phone_verified ? '<span class="text-success">Terverifikasi</span>' : '<span class="text-danger">Belum Terverifikasi</span>');?></td>
                      <td><?php echo ($this->user->phone_verified ? '<span class="text-success"><i class="fa fa-check"></i></span>' : '<a href="'.site_url('akun/verifikasi/phone').'" '.$modal_tag.'>Verifikasi</a>');?></td>
                    </tr>
                    <tr>
                      <td>KTP</td>
                      <td><?php echo (isset($this->user->set['verify_ktp']) ? html_escape($this->user->set['verify_ktp']['orig_name']) : (isset($this->user->set['ktp_data']) ? html_escape($this->user->set['ktp_data']['orig_name']) : ''));?></td>
                      <td><?php echo (in_array('ktp', $this->system->perm->user_verified) ? 'Dibutuhkan' : 'Tidak dibutuhkan');?></td>
                      <td><?php echo ($this->user->ktp_verified ? '<span class="text-success">Terverifikasi</span>' : (isset($this->user->set['verify_ktp']) ? '<span class="text-info">Menunggu Verifikasi</span>' : '<span class="text-danger">Belum Terverifikasi</span>'));?></td>
                      <td><?php echo ($this->user->ktp_verified ? '<span class="text-success"><i class="fa fa-check"></i></span>' : (isset($this->user->set['verify_ktp']) ? '<i class="fa fa-hourglass-end"></i>' : '<a href="'.site_url('akun/verifikasi/ktp').'" '.$modal_tag.'>Verifikasi</a>'));?></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>