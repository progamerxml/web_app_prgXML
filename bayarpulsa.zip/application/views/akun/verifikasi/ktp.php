<div class="alert alert-warning">
  Ekstensi file file yang diperbolehkan adalah jpg, jpeg dan png, maksimal ukuran file 500kb.
  <br />
  Kamu harus mengupload KTP asli berwarna ataupun tidak, jangan mengupload KTP yang bukan milik kamu karena akan menyebabkan akun kamu diblokir.
  <br />
  Kami tidak akan menyalahgunakan KTP kamu dan setelah proses verifikasi selesai maka KTP kamu akan kami simpan dengan aman.
</div>
<?php echo form_open_multipart(current_url());?>
  <div class="form-group">
    <div class="input-group">
      <label class="input-group-btn">
        <span class="btn btn-default">Pilih... <input type="file" style="display: none;" name="ktp"/></span>
      </label>
      <input type="text" class="form-control" value="Tidak ada file" readonly="readonly"/>
      <span class="input-group-btn">
        <button type="submit" class="btn btn-primary" name="submit" value="upload"><i class="fa fa-upload"></i> Upload</button>
      </span>
    </div>
  </div>
<?php echo form_close();?>
<script>
    $(document).on('change', ':file', function() {
        var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [numFiles, label]);
    });
    $(document).ready( function() {
        $(':file').on('fileselect', function(event, numFiles, label) {
            var input = $(this).parents('.input-group').find(':text'),
            log = numFiles > 1 ? numFiles + ' files selected' : label;
            if( input.length ) {
                input.val(log);
            }
        });
    });
</script>