<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Pengaturan | <?php echo html_escape($this->system->set['site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Pengaturan</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-cogs"></i> Pengaturan</h3>
            </div>
            <div class="panel-body">
              <?php include(dirname(__FILE__).'/_nav-tabs.php');?>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="profile" style="padding-top: 15px;">
                  <?php echo form_open();?>
                    <div class="form-group">
                      <label for="user_name">Nama Lengkap</label>
                      <input class="form-control" type="text" name="user_name" id="user_name" value="<?php echo set_value('user_name', $this->user->data['us_name']);?>"  maxlength="32" required="required"/>
                    </div>
                    <div class="form-group">
                      <label for="user_gender">Jenis Kelamin</label>
                      <select class="form-control" name="user_gender" id="user_gender">
                        <option value="male" <?php echo set_select('user_ender', 'male', $this->user->data['us_gender'] == 'male' ? true : false);?>>Laki-laki</option>
                        <option value="female" <?php echo set_select('user_ender', 'female', $this->user->data['us_gender'] == 'female' ? true : false);?>>Perempuan</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="user_location">Alamat Lengkap</label>
                      <input class="form-control" type="text" name="user_location" id="user_location" value="<?php echo set_value('user_location', $this->user->data['us_location']);?>"  maxlength="160" required="required"/>
                    </div>
                    <?php if ($this->system->perm->edit_phone):?>
                    <div class="form-group">
                      <label for="user_phone">Nomor HP</label>
                      <input class="form-control" type="number" name="user_phone" id="user_phone" value="<?php echo set_value('user_phone', $this->user->data['us_phone']);?>" required="required"/>
                    </div>
                    <?php endif;?>
                    <div class="form-group">
                      <label for="user_password">Kata sandi</label>
                      <input class="form-control" type="password" name="user_password" id="user_password" maxlength="12" required="required"/>
                    </div>
                    <div>
                      <button class="btn btn-primary" type="submit" name="submit" value="update_profile">Simpan</button>
                    </div>
                  <?php echo form_close();?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>