<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Pengaturan | <?php echo html_escape($this->system->set['site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Pengaturan</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-cogs"></i> Pengaturan</h3>
            </div>
            <div class="panel-body">
              <?php include(dirname(__FILE__).'/_nav-tabs.php');?>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="pin" style="padding-top: 15px;">
                  <?php echo form_open();?>
                    <div class="form-group">
                      <label>PIN SMS</label>
                      <input class="form-control" type="number" name="pin" id="pin" value="<?php echo set_value('pin', '');?>" min="1000" max="9999" required="required"/>
                      <p class="help-block">PIN untuk transaksi menggunakan SMS, harus terdiri dari 4 digit angka.</p>
                    </div>
                    <div class="form-group">
                      <label for="user_password">Kata sandi</label>
                      <input class="form-control" type="password" name="user_password" id="user_password" maxlength="12" required="required"/>
                      <p class="help-block">Masukan kata sandi anda untuk memverifikasi perubahan PIN</p>
                    </div>
                    <div>
                      <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>
                  <?php echo form_close();?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>