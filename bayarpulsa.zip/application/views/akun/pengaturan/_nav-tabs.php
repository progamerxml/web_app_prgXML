<?php
defined('BASEPATH') or exit('No direct script access allowed');
$method = $this->router->fetch_method();
?>
<ul class="nav nav-tabs" role="tablist">
  <li role="presentation" class="<?php echo ($method == 'index' ? 'active' : '');?>">
    <a href="<?php echo ($method == 'index' ? '#profile' : site_url('akun/pengaturan'));?>"><i class="fa fa-user"></i> Profil</a>
  </li>
  <li role="presentation" class="<?php echo ($method == 'kata_sandi' ? 'active' : '');?>">
    <a href="<?php echo ($method == 'kata_sandi' ? '#password' : site_url('akun/pengaturan/kata-sandi'));?>"><i class="fa fa-lock"></i> Password</a>
  </li>
  <li role="presentation" class="<?php echo ($method == 'pin' ? 'active' : '');?>">
    <a href="<?php echo ($method == 'pin' ? '#pin' : site_url('akun/pengaturan/pin'));?>"><i class="fa fa-key"></i> PIN</a>
  </li>
  <li role="presentation" class="<?php echo ($method == 'keamanan' ? 'active' : '');?>">
    <a href="<?php echo ($method == 'keamanan' ? '#keamanan' : site_url('akun/pengaturan/keamanan'));?>"><i class="fa fa-shield"></i> Keamanan</a>
  </li>
</ul>