<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Pengaturan</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">.checkbox>label,.checkbox-inline>label,.radio>label,.radio-inline>label{font-weight: normal;}</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Pengaturan</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-cogs"></i> Pengaturan</h3>
            </div>
            <div class="panel-body">
              <?php include(dirname(__FILE__).'/_nav-tabs.php');?>
              <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="keamanan" style="padding-top: 15px;">
                  <?php echo form_open();?>
                    <div class="form-group">
                      <label>Login OTP (One Time Password)</label>
                      <div class="radio" style="margin-top: 0;"><label><input type="radio" name="otp" value="email" <?php echo ($this->system->perm->otp == 0 || ($this->system->perm->otp == 2 && !$this->user->is_admin()) ? 'disabled="disabled"' : (!in_array('email', $this->system->perm->otp_gateway) ? 'disabled="disabled"' : (isset($this->user->set['otp']) && $this->user->set['otp'] == 'email' ? 'checked="checked"' : '')));?>/> Kirimkan saya OTP melalui Email</label></div>
                      <div class="radio"><label><input type="radio" name="otp" value="sms" <?php echo ($this->system->perm->otp == 0 || ($this->system->perm->otp == 2 && !$this->user->is_admin()) ? 'disabled="disabled"' : (!in_array('sms', $this->system->perm->otp_gateway) ? 'disabled="disabled"' : (isset($this->user->set['otp']) && $this->user->set['otp'] == 'sms' ? 'checked="checked"' : '')));?>/> Kirimkan saya OTP melalui SMS</label></div>
                      <div class="radio"><label><input type="radio" name="otp" value="none" <?php echo ($this->system->perm->otp == 0 || ($this->system->perm->otp == 2 && !$this->user->is_admin()) ? 'disabled="disabled"' : (isset($this->user->set['otp']) && $this->user->set['otp'] == 'none' ? 'checked="checked"' : ''));?>/> Jangan kirimkan saya OTP</label></div>
                    </div>
                    <?php if ($this->system->perm->email_login == 'yes'):?>
                    <div class="form-group">
                      <label>Kirimkan pemberitahuan masuk melaui email</label>
                      <div>
                        <div class="radio-inline"><label><input type="radio" name="login_notify" value="1"<?php echo (isset($this->user->set['login_notify']) && $this->user->set['login_notify'] ? ' checked="checked"' : '');?>/> Ya</label></div>
                        <div class="radio-inline"><label><input type="radio" name="login_notify" value="0"<?php echo (isset($this->user->set['login_notify']) && !$this->user->set['login_notify'] ? ' checked="checked"' : '');?>/> Tidak</label></div>
                      </div>
                    </div>
                    <?php endif;?>
                    <?php if ($this->system->perm->password_verify == 'yes'):?>
                    <div class="form-group">
                      <label>Verifikasi kata sandi sebelum melakukan order di web?</label>
                      <div>
                        <div class="radio-inline"><label style="font-weight: normal;"><input type="radio" name="password_verify" value="yes"<?php echo (@$this->user->set['password_verify'] != 'no' ? ' checked="checked"' : '');?>> Ya</label></div>
                        <div class="radio-inline"><label style="font-weight: normal;"><input type="radio" name="password_verify" value="no"<?php echo (@$this->user->set['password_verify'] == 'no' ? ' checked="checked"' : '');?>> Tidak</label></div>
                      </div>
                    </div>
                    <?php endif;?>
                    <div class="form-group">
                      <label for="user_password">Kata sandi</label>
                      <input class="form-control" type="password" name="user_password" id="user_password" maxlength="12" required="required"/>
                    </div>
                    <div>
                      <button class="btn btn-primary" type="submit" name="submit" value="update_password">Simpan</button>
                    </div>
                  <?php echo form_close();?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>