<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Akun Saya | <?php echo html_escape($this->system->set['site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li class="active"><span>Akun Saya</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="row">
            <div class="col-sm-12 col-md-7" id="data-profil">
              <?php if ($info['aktif']):?>
              <div class="visible-xs visible-sm" style="margin-bottom: 15px;">
                <a class="btn btn-warning btn-block" href="#info"><i class="fa fa-info-circle"></i> <?php echo html_escape($info['judul']);?></a>
              </div>
              <?php endif;?>
              <div class="panel panel-default">
                <div class="panel-heading" style="height: 100px;"></div>
                <div class="panel-body">
                  <div class="row" style="margin-top: -65px;margin-bottom: 20px">
                    <div class="col-xs-offset-2 col-xs-8 col-sm-offset-4 col-sm-4 text-center">
                      <img class="img-thumbnail" src="<?php echo base_url('images/user-default.png');?>"/>
                    </div>
                  </div>
                  <div class="table-responsiveX">
                    <table class="table" style="margin-bottom: 0;">
                      <tbody>
                        <tr><td style="width: 140px;">Nama Lengkap</td><td>: <?php echo html_escape($this->user->data['us_name']);?></td></tr>
                        <tr><td style="width: 140px;">Nama Pengguna</td><td>: <?php echo $this->user->data['us_username'];?></td></tr>
                        <tr><td style="width: 140px;">Email</td><td>: <?php echo html_escape($this->user->data['us_email']);?></td></tr>
                        <tr><td style="width: 140px;">Jenis Kelamin</td><td>: <?php echo str_replace(array('female','male'),array('Perempuan','Laki-laki'),$this->user->data['us_gender']);?></td></tr>
                        <tr><td style="width: 140px;">Alamat</td><td>: <?php echo html_escape($this->user->data['us_location']);?></td></tr>
                        <tr><td style="width: 140px;">No. HP</td><td>: <strong><?php echo html_escape($this->user->data['us_phone']);?></strong></td></tr>
                        <?php if ($this->user->us_telegram_id):?>
                        <tr><td style="width: 140px;">Telegram</td><td>: <?php echo $this->user->us_telegram_username ? '<a href="http://t.me/'.$this->user->us_telegram_username.'" target="_blank">@'.$this->user->us_telegram_username.'</a>' : $this->user->us_telegram_id;?>&nbsp;&nbsp;&nbsp;<a class="btn btn-danger btn-xs" href="<?php echo site_url('akun/profil/hapus-telegram');?>" data-toggle="modal" data-target="#myModal" title="Hapus Telegram"><i class="fa fa-times"></i></a></td></tr>
                        <?php endif;?>
                        <tr><td style="width: 140px;">Status Akun</td><td>: <a href="<?php echo site_url('akun/verifikasi');?>"><?php echo $this->user->verified ? '<span class="text-success"><i class="fa fa-check-circle"></i> Terverifikasi</span>'  : '<span class="text-danger"><i class="fa fa-times-circle"></i> Belum Terverifikasi</span>';?></a></td></tr>
                        <tr><td style="width: 140px;">Jenis Akun</td><td>: <a href="<?php echo site_url('akun/reseller');?>"><?php echo $this->user->data['us_reseller'] == 'active' ? '<i class="fa fa-shopping-bag"></i> Reseller'  : '<i class="fa fa-user-o"></i> Member';?></a></td></tr>
                        <tr><td style="width: 140px;">Saldo</td><td>: <?php echo format_uang2($this->user->data['us_balance'], 0);?>&nbsp;&nbsp;&nbsp;<?php echo ($this->system->perm->allow_deposit == 'yes' ? '<a class="btn btn-default btn-xs" href="'.site_url('akun/deposit').'" title="Tambah saldo"><i class="fa fa-plus"></i></a>' : '');?></td></tr>
                        <tr><td style="width: 140px;">Total Transaksi</td><td>: <?php echo $this->user->data['us_total_order'];?> transaksi sukses</td></tr>
                        <tr><td style="width: 140px;">Tanggal Mendaftar</td><td>: <?php echo format_tanggal($this->user->data['us_regdate']);?></td></tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>              
            </div>
            <div class="col-sm-12 col-md-5">
              <?php if ($info['aktif']):?>
              <div class="panel panel-warning" id="info">
                <div class="panel-heading">
                  <h3><i class="fa fa-info-circle"></i> <?php echo html_escape($info['judul']);?></h3>
                </div>
                <div class="panel-body">
                <?php echo $info['pesan'];?>
                <?php if ($this->user->is_admin()):?>
                <p style="margin-bottom: 0;">[<a href="<?php echo site_url('admin/info-utama');?>" data-toggle="modal" data-target="#myModal">Edit Info</a>]</p>
                <?php endif;?>
                </div>
              </div>
              <?php elseif ($this->user->is_admin()):?>
              <div style="margin-bottom: 15px;"><a href="<?php echo site_url('admin/info-utama');?>" class="btn btn-default btn-block" data-toggle="modal" data-target="#myModal"><i class="fa fa-info-circle"></i> Info Utama</a></div>
              <?php endif;?>
              <?php if ($recent_posts):?>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3><i class="fa fa-sticky-note-o"></i> Artikel terbaru</h3>
                </div>
                <ul class="list-group">
                  <?php
                  include_once (APPPATH.'third_party/simple_html_dom.php');
                  $dom = new simple_html_dom;
                  foreach ($recent_posts as $recent_post):
                  $dom->load($recent_post['bp_deskripsi']);
                  if ($image = $dom->find('img', 0)) {
                    $media_left = '<div class="media-left"><a href="'.site_url('blog/'.$recent_post['bp_slug']).'"><img class="media-object" src="'.$image->src.'" alt="'.html_escape($recent_post['bp_judul']).'" style="width:40px !important;height:40px !important;"/></a></div>';
                  } else {
                    $media_left = '<div class="media-left" style="font-size: 40px;"><a href="'.site_url('blog/'.$recent_post['bp_slug']).'"><i class="fa fa-sticky-note-o"></i></a></div>';
                  }
                  $dom->clear();
                  ?>
                  <li class="list-group-item">
                    <div class="media">
                      <?php echo $media_left ? $media_left : '';?>
                      <div class="media-body">
                        <a href="<?php echo site_url('blog/'.$recent_post['bp_slug']);?>"><h4 class="media-heading"><?php echo html_escape($recent_post['bp_judul']);?></h4></a>
                        <span class="text-muted">Pada <?php echo format_tanggal($recent_post['bp_tanggal']);?> oleh <?php echo html_escape($recent_post['us_name']);?></span>
                        <p><?php echo substr(trim(strip_tags($recent_post['bp_deskripsi'])), 0, 200);?></p>
                      </div>
                    </div>
                  </li>
                  <?php endforeach;?>
                </ul>
              </div>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>