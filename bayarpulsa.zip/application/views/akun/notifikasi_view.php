<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      Akun Saya &gt; Pemberitahuan | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li><a href="<?php echo site_url('akun/notifikasi');?>">Pemberitahuan</a></li>
        <li class="active"><span><?php echo html_escape($notifikasi->nf_judul);?></span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <?php echo html_escape($notifikasi->nf_judul);?> <small>(<?php echo format_tanggal($notifikasi->nf_tanggal);?>)</small>
              </h3>
            </div>
            <div class="panel-body">
              <?php if ($notifikasi->nf_judul === 'Administrator' || $notifikasi->nf_feedback === '1'):?>
              <p>
              <?php
              if (strpos($notifikasi->nf_teks, '--------------------') !== false) {
                $sub = explode('--------------------', $notifikasi->nf_teks, 2);
                echo '<span class="text-mutted"><i>'.nl2br(trim(auto_link(html_escape($sub[0])))).'</i></span><br/>--------------------<br/>'.nl2br(trim(auto_link(html_escape($sub[1]))));
              } else {
                echo nl2br(auto_link(html_escape($notifikasi->nf_teks)));
              }
              ?>
              </p>
              <?php echo form_open();?>
                <div class="form-group">
                  <label>Kirim umpan balik ke Administrator</label>
                  <textarea class="form-control" name="pesan" rows="8"><?php echo set_value('pesan');?></textarea>
                </div>
                <div class="row">
                  <div class="col-sm-8 col-md-10">
                    <div class="form-group">
                      <div class="input-group">
                        <span class="input-group-addon" style="padding: 0;overflow: hidden;">
                          <img src="<?php echo site_url('captcha');?>" style="height:30px" alt="Loading...."/>
                        </span>
                        <input type="text" class="form-control" name="captcha" id="v" maxlength="5" size="5" required="required"/>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-4 col-md-2">
                    <button type="submit" class="btn btn-primary btn-block" style="margin-bottom: 15px;"><i class="fa fa-paper-plane"></i> Kirim</button>
                  </div>
                </div>
                <input type="hidden" name="nama" value="<?php echo html_escape($this->user->data['us_name']);?>"/>
                <input type="hidden" name="no_hp" id="no_hp" value="<?php echo html_escape($this->user->data['us_phone']);?>"/>
              <?php echo form_close();?>
              <?php else:?>
              <?php echo nl2br(auto_link(html_escape($notifikasi->nf_teks)));?>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>