<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Transfer Saldo | <?php echo html_escape($this->system->set['site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Transfer Saldo</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-money"></i> Transfer Saldo</h3>
            </div>
            <div class="panel-body">
              <div class="alert alert-info">
                Jumlah saldo kamu saat ini <strong>Rp <?php echo format_uang($this->user->data['us_balance']);?></strong>
              </div>
              <?php echo form_open();?>
                <div class="form-group">
                  <label for="receiver">Username penerima</label>
                  <input type="text" class="form-control" name="receiver" id="receiver" value="<?php echo set_value('receiver');?>" required="required" maxlength="16"/>
                </div>
                <div class="form-group">
                  <label for="amount">Jumlah</label>
                  <input class="form-control" type="number" name="amount" id="amount" value="<?php echo set_value('amount');?>" required="required" max="<?php echo $this->user->data['us_balance'];?>"/>
                </div>
                <div class="form-group">
                  <label for="note">Keterangan</label>
                  <input class="form-control" type="text" name="note" id="note" value="<?php echo set_value('note');?>"  maxlength="80" autocomplete="off"/>
                </div>
                <div class="form-group">
                  <label for="user_password">Password anda</label>
                  <input class="form-control" type="password" name="user_password" id="user_password" value=""  maxlength="12" required="required"/>
                </div>
                <div>
                  <button class="btn btn-primary" type="submit" name="submit" value="send">Kirim</button>
                </div>
              <?php echo form_close();?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>