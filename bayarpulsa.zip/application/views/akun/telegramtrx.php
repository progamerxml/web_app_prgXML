<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Transaksi Via Telegram | <?php echo html_escape($this->system->set['site_name']); ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Transaksi Via Telegram</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-telegram"></i> Transaksi Via Telegram</h3>
            </div>
            <div class="panel-body">
              <?php if (empty($set['token'])):?>
              <div class="alert alert-warning">
                Transaksi via Telegram saat ini tidak tersedia.
              </div>
              <?php else:?>
              Kami berkomitmen memberikan pelayanan yang terbaik bagi member kami salah satunya dengan cara menyediakan layanan transaksi melalui Telegram, jadi kamu tidak repor - repot lagi mengunjungi web kami, cukup dengan mengirim pesan ke bot Telegram kami maka transaksi anda akan kami proses.
              <br />
              <br />
              Untuk menggunakan layanan ini silakan <a href="https://telegram.org" target="_blank">download aplikasi telegram</a> dan pastikan nomor HP kamu sudah <a href="<?php echo site_url('akun/verifikasi');?>" target="_blank">terverifikasi</a>, selanjutnya cari <a href="http://t.me/<?php echo $set['username'];?>" target="_blank">@<?php echo $set['username'];?></a> di kolom pencarian pada aplikasi Telegram.
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>