<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Akun Saya &gt; Reseller</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Reseller</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-shopping-bag"></i> Reseller</h3>
            </div>
            <div class="panel-body">
              <p>
                Program Reseller Pulsa Online telah kami buka dengan tawaran harga lebih murah.
                <br/>
                <h4>Ketentuan Reseller</h4>
                <ol>
                  <li>Minimal <?php echo $reseller_config->min_trx; ?> transaksi per bulan dan apabila dalam satu bulan transaksi kurang dari <?php echo $reseller_config->min_trx; ?> maka status reseller otomatis akan dinonaktifkan</li>
                  <li>Pembayaran menggunakan <?php echo ($reseller_config->payment == 'balance' ? 'Saldo Akun' : 'Saldo Akun dan Payment Sistem');?>.</li>
                </ol>
                Status Reseller Kamu saat ini <strong><?php echo str_replace(array('inactive','active','blocked'),array('<span class="badge badge-default">Tidak aktif</span>','<span class="badge badge-success">Aktif</span>','<span class="badge badge-danger">Diblokir</span>'), $this->user->data['us_reseller']);?></strong>.
              </p>
              <?php if ($this->user->us_reseller == 'blocked'):?>
              <div class="alert alert-danger">Kamu tidak dapat mengirim permintaan untuk menjadi reseller.</div>
              <?php elseif (isset($this->user->set['reseller_request'])):?>
              <div class="alert alert-info">Permintaan kamu untuk menjadi reseller telah dikirim pada tanggal <strong><?php echo format_tanggal($this->user->set['reseller_reqtime']);?></strong> dengan isi pesan: <strong><?php echo nl2br(html_escape($this->user->set['reseller_request']));?></strong>.</div>
              <?php elseif ($this->user->us_reseller == 'inactive'):?>
              <div>
                <p>
                Anda dapat mengirimkan permintaan untuk menjadi reseller kami melalui form di bawah ini.
                <br/>
                Permintaan Anda akan segera kami review.
                <br />
                <h5>Syarat untuk mengirim permintaan menjadi reseller</h5>
                <ol>
                <li>Status akun sudah terverifikasi</li>
                <li>Minimal sisa saldo <?php echo format_uang2($reseller_config->min_saldo); ?>.</li>
                </ol>
                </p>
                <?php echo form_open();?>
                  <div class="form-group">
                    <label for="pesan">Pesan</label>
                      <textarea class="form-control" name="pesan" maxlength="120" rows="4"><?php echo set_value('pesan');?></textarea>
                      <p class="help-block">Maksimal 120 karakter</p>
                  </div>
                  <div class="row">
                    <div class="col-sm-6 col-md-9">
                      <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon" style="padding: 0;overflow: hidden;">
                            <img src="<?php echo site_url('captcha');?>" style="height:30px" alt="Loading....">
                          </span>
                          <input type="text" class="form-control" name="captcha" maxlength="5" size="5" required="required">
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                      <button type="submit" name="submit" value="kirim" class="btn btn-primary btn-block" style="margin-bottom: 15px;">Kirim Permintaan</button>
                    </div>
                  </div>
                <?php echo form_close();?>
              </div>
              <?php elseif ($this->user->us_reseller == 'active'):?>
              <div>
                <a class="btn btn-danger" href="<?php echo site_url('akun/reseller/berhenti');?>" data-toggle="modal" data-target="#myModal">Berhenti Menjadi Reseller</a>
              </div>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>