<?php
defined('BASEPATH') or exit('No direct script access allowed');
function set_trx($matches) {
  if ($matches[1] == 'Deposit')
    return $matches[1] . $matches[2] . '#<a href="'.site_url('akun/deposit/view/'.$matches[3]).'">'.$matches[3].'</a>';
  else
    return $matches[1] . $matches[2] . '#<a href="'.site_url('akun/riwayat-transaksi/view/'.$matches[3]).'">'.$matches[3].'</a>';
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Mutasi Saldo | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?></title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">nav {margin-bottom: 15px; float: right;}</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Mutasi Saldo</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <?php if (!$total):?>
          <div class="alert alert-warning">Belum ada riwayat saldo.</div>
          <?php else:?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-credit-card"></i> Mutasi Saldo</h3>
            </div>
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Tanggal</th>
                    <th>Keterangan</th>
                    <th>Jumlah</th>
                    <th>Saldo Akhir</th>
                  </tr>
                </thead>
                <tbody id="history_transaksi">
                  <?php foreach ($results as $res): ?>
                  <tr>
                    <td style="white-space: nowrap;"><?php echo format_tanggal($res->tanggal);?></td>
                    <td><?php echo preg_replace_callback("/(Trx|Deposit)(.*?)#([0-9]{1,12})/i", "set_trx", $res->info);?></td>
                    <td><?php echo $res->kredit ? '<span class="text-success" data-toggle="tooltip" title="Kredit">+'.format_uang($res->kredit).'<span>' : '<span class="text-danger" data-toggle="tooltip" title="Debet">-'.format_uang($res->debet).'<span>';?></td>
                    <td style="width: 85px;"><?php echo $res->saldo_akhir ? format_uang($res->saldo_akhir) : '';?></td>
                  </tr>
                  <?php endforeach;?>
                </tbody>
              </table>
            </div>
          </div>
          <?php echo pagination(site_url('akun/riwayat-saldo/index'), $start, $total, $this->system->set['list_per_page'], '/%d');?>
          <?php endif;?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>