<div class="alert alert-warning">
  Sebelum melakukan pembelian silakan verifikasi kata sandi terlebih dahulu, tindakan ini hanya sekali dilakukan disetiap sesi login untuk menjaga keamanan akun kamu.
</div>
<?php echo form_open();?>
  <input type="hidden" name="transaksi" value="<?php echo html_escape($data);?>" />
  <input type="hidden" name="password_verify" value="1" />
  <?php foreach ($items as $item):?>
  <input type="hidden" name="items[]" value="<?php echo html_escape($item);?>" />
  <?php endforeach;?>
  <div class="form-group">
    <div class="input-group">
      <input class="form-control" type="password" name="password" value="" required="required" placeholder="Kata Sandi"/>
      <span class="input-group-btn">
        <button class="btn btn-primary" type="submit" name="submit" value="order">
          Konfirmasi
        </button>
      </span>
    </div>
  </div>
  <p class="help-block" style="margin-bottom:0">
    Untuk menonaktifkan verifikasi ini silakan kunjungi halaman <a href="<?php echo site_url('akun/pengaturan/keamanan');?>">Pengaturan Keamanan</a>
  </p>
<?php echo form_close();?>