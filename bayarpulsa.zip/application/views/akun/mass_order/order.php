<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Akun Saya &gt; Pembelian Massal</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Pembelian Massal</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <?php echo form_open_multipart('akun/mass-order', 'id="form-confirm"');?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><?php echo $results ? '<span class="pull-right">'.count($results).'</span>' : '';?><i class="fa fa-shopping-cart"></i> Pembelian Massal</h3>
            </div>
            <div class="panel-body" id="form" style="display: <?php echo $results ? 'none' : 'block';?>">
              <div>
                <ul class="nav nav-tabs nav-justified" role="tablist">
                  <li role="presentation" class="active"><a href="#write" aria-controls="write" role="tab" data-toggle="tab"><i class="fa fa-edit"></i> Menulis</a></li>
                  <li role="presentation"><a href="#upload" aria-controls="upload" role="tab" data-toggle="tab"><i class="fa fa-upload"></i> Upload</a></li>
                </ul>
                <div class="tab-content">
                  <div role="tabpanel" class="tab-pane fade in active" id="write" style="padding-top: 15px;">
                    <div class="form-group">
                      <label>Format Transaksi</label>
                      <textarea class="form-control" rows="10" name="transaksi"><?php echo html_escape($data);?></textarea>
                    </div>
                    <div class="row" style="margin-bottom: 15px;">
                      <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                        <button type="submit" class="btn btn-primary btn-block" name="submit" value="next">Lanjutkan <i class="fa fa-chevron-right"></i></button>
                      </div>
                    </div>
                    <h5 style="margin-bottom: 5px;">Bantuan</h5>
                    <ul style="margin-bottom: 0;">
                      <li>Contoh format transaksi: <strong>X5.081812345678</strong>.</li>
                      <li>Jika pembelian lebih dari satu silakan pisahkan format transaksi dengan baris baru.</li>
                      <li>Maksimal jumlah pembelian adalah <strong><?php echo $set['max'];?></strong>.</li>
                      <li>Hanya berlaku untuk jenis produk: <strong><?php echo implode(', ', $jenis_produk);?></strong>.</li>
                      <li>Untuk melihat kode - kode voucher / nominal yang tersedia silakan <a target="_blank" href="http://localhost/pulsa3/harga">kunjungi daftar harga</a>.</li>
                    </ul>
                  </div>
                  <div role="tabpanel" class="tab-pane fade" id="upload" style="padding-top: 15px;">
                    <div class="input-group" id="form-upload">
                      <label class="input-group-btn">
                        <span class="btn btn-default">Pilih... <input type="file" accept="text/plain" style="display: none;" name="txt"/></span>
                      </label>
                      <input type="text" class="form-control" value="Tidak ada file" readonly="readonly"/>
                      <span class="input-group-btn">
                        <button type="submit" class="btn btn-primary" name="submit" value="upload"><i class="fa fa-upload"></i> Upload</button>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php if ($results):?>
              <div class="table-responsive" id="results">
                <table class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th class="text-center" style="width: 40px;"><input type="checkbox" id="select-all"/></th>
                      <th>Transaksi</th>
                      <th>Produk</th>
                      <th>Provider</th>
                      <th>Nominal</th>
                      <th style="width: 80px;">Harga</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($results as $key=>$result):?>
                    <tr id="item-<?php echo html_escape($key);?>">
                      <?php if ($result->error): ?>
                      <td class="text-center"><input type="checkbox" class="checkbox1" disabled="disabled"/></td>
                      <?php else:?>
                      <td class="text-center"><input type="checkbox" class="checkbox1 open" name="items[]" value="<?php echo html_escape($key);?>" <?php echo (in_array($key, $selected_items) ? 'checked="checked"' : '');?>/></td>
                      <?php endif;?>
                      <td><span<?php echo $result->error ? ' class="text-danger"  data-toggle="tooltip" data-title="'.html_escape($result->error).'"' : '';?>><?php echo $result->vo_kode_trx.'.'.html_escape($key);?></span></td>
                      <td><?php echo html_escape($this->system->produk->{$result->op_produk}->nama);?></td>
                      <td><?php echo html_escape($result->op_nama);?></td>
                      <td><?php echo html_escape($result->vo_nominal);?></td>
                      <td><?php echo $this->user->is_reseller && $result->vo_harga_reseller ? format_uang($result->vo_harga_reseller) : format_uang($result->vo_harga);?></td>
                    </tr>
                    <?php endforeach;?>
                  </tbody>
                </table>
              </div>
              <div class="panel-footer" id="button">
                <div class="row">
                  <div class="col-xs-8 col-sm-6 col-md-4 col-lg-3">
                    <button type="submit" class="btn btn-primary btn-block" name="submit" value="order" id="order_now"><i class="fa fa-check"></i> Order yang ditandai</button>
                  </div>
                  <div class="col-xs-4 col-sm-offset-3 col-sm-3 col-md-offset-6 col-md-2 col-lg-offset-7 col-lg-2" style="text-align: right;">
                    <button type="button" class="btn btn-default btn-block" id="batal"><i class="fa fa-times"></i> Batal</button>
                  </div>
                </div>
              </div>
            <?php endif;?>
          </div>
          <?php echo form_close();?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <script>
    $(document).ready(function(){$('#select-all').click(function(event){if(this.checked){$('.checkbox1.open').each(function(){this.checked=true;});}else{$('.checkbox1.open').each(function(){this.checked=false;});}});});
    $("#batal").click(function() {
        $("#form").show();
        $("#results, #button, .panel-heading span").hide();
    });
    $(document).on('change', ':file', function() {
        var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [numFiles, label]);
    });
    $(document).ready( function() {
        $(':file').on('fileselect', function(event, numFiles, label) {
            var input = $(this).parents('#form-upload').find(':text'),
            log = numFiles > 1 ? numFiles + ' files selected' : label;
            if( input.length ) {
                input.val(log);
            }
        });
    });
    <?php if ($password_verify): ?>
    $(document).on("click","#order_now", function() {
      var formData = $("#form-confirm").serialize();
      if (formData.indexOf('items') > 0) {
        $("#myModal").modal("show");
        $.ajax({
          type: "POST",
          url: $(this).attr("action"),
          data: formData + '&submit=order',
          success: function (data) {
            var csrf = $(data).find('[name="<?php echo $this->security->get_csrf_token_name();?>"]').val();
            $('#form-confirm [name="<?php echo $this->security->get_csrf_token_name();?>"]').val(csrf);
            $("#myModal .modal-content").html(data);
          },
          error: function() {
            alert("Terjadi kesalahan!");
          }
        });
        return false;
      } else {
        return true;
      }
    });
    <?php endif;?>
    </script>
  </body>
</html>