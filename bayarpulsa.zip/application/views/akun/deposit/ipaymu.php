<?php if ($trx->de_status != 'pending'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div>
    <div class="text-warning text-center">
      Pembayaran akan diproses secara otomatis apabila menggunakan saldo iPaymu, jika menggunakan bank transfer dan anda sudah membayarnya maka segera hubungi Administrator.
    </div>
    <br />
    <div class="table-responsive">
      <table class="table table-striped">
        <tbody>
          <tr>
            <td>Jumlah</td>
            <td>Rp <?php echo format_uang($trx->de_amount);?></td>
          </tr>
          <tr>
            <td>Fee / Biaya</td>
            <td>Rp <?php echo format_uang($fee = ceil(round($trx->de_amount / 100, 2)));?></td>
          </tr>
          <tr>
            <td>Total</td>
            <td><strong>Rp <?php echo format_uang($trx->de_amount + $fee);?></strong></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div>
    <ul style="padding-left: 15px;">
    <li>Dana yang akan ditambahkan ke saldo akun adalah <strong>Rp <?php echo format_uang($trx->de_amount);?></strong> setelah pembayaran berhasil diselesaikan.</li>
    <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time));?>.</li>
    </ul>
    </div>
  </div>
</div>
<div class="panel-footer">
  <a class="btn btn-primary btn-block" href="<?php echo site_url('payment/ipaymu/deposit/'.$trx->de_id);?>" id="submit-confirm"><i class="fa fa-money"></i> Bayar Sekarang</a>
</div>
<?php endif;?>