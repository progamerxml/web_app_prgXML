<?php if ($trx->de_status != 'pending'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr><td>IDR</td><td><?php echo format_uang2($trx->de_amount, 0, $this->payment->fasapay_id->template);?></td></tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time));?>.</li>
    </ul>
  </div>
</div>
<form action="https://sci.fasapay.com/" method="POST">
  <input type="hidden" name="fp_acc" value="<?php echo html_escape($this->payment->fasapay_id->data->nomor_rekening);?>"/>
  <input type="hidden" name="fp_store" value="<?php echo html_escape($this->payment->fasapay_id->data->nama_rekening);?>"/>
  <input type="hidden" name="fp_item" value="Deposit"/>
  <input type="hidden" name="fp_amnt" value="<?php echo $trx->de_amount;?>"/>
  <input type="hidden" name="fp_fee_mode" value="FiS"/>
  <input type="hidden" name="fp_merchant_ref" value="<?php echo $trx->de_note;?>"/>
  <input type="hidden" name="trx_id" value="DEP<?php echo $trx->de_id;?>"/>
  <input type="hidden" name="fp_success_url" value="<?php echo site_url('akun/deposit/view/'.$trx->de_id);?>"/>
  <input type="hidden" name="fp_status_url" value="<?php echo site_url('payment/fasapay_id/deposit/'.$trx->de_id);?>"/>
  <input type="hidden" name="fp_fail_url" value="<?php echo site_url('akun/deposit/view/'.$trx->de_id);?>"/>
  <input type="hidden" name="fp_currency" value="IDR"/>
  <div class="panel-footer">
    <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-money"></i> Bayar Sekarang</button>
  </div>
</form>
<?php endif;?>