<?php if ($trx->de_status != 'pending'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr>
          <td>No. Rekening</td>
          <td><?php echo html_escape($this->payment->bank_mandiri->data->nomor_rekening);?></td>
        </tr>
        <tr>
          <td>Atas Nama</td>
          <td><?php echo html_escape($this->payment->bank_mandiri->data->nama_rekening);?></td>
        </tr>
        <tr>
          <td>Jumlah</td>
          <td><strong><?php echo format_uang2($trx->de_amount, $trx->de_rate, $this->payment->bank_mandiri->template, $this->payment->bank_mandiri->round);?></strong></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
    <li>Silakan lakukan transfer sebesar <strong><?php echo format_uang2($trx->de_amount);?></strong>.</li>
    <li>Setelah melakukan pembayaran silakan klik tombol &quot;<b>Konfirmasi Pembayaran</b>&quot;.</li>
    <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <a href="<?php echo site_url('payment/bank_mandiri/deposit/'.$trx->de_id);?>" class="btn btn-primary btn-block" id="submit-confirm"><i class="fa fa-check"></i> Konfirmasi Pembayaran</a>
</div>
<?php endif;?>