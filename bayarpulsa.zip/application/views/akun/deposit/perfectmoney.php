<?php if ($trx->de_status != 'pending'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr>
          <td>
            Jumlah
          </td>
          <td>
            <?php echo format_uang2($trx->de_amount, $trx->de_rate, $this->payment->perfectmoney->template, $this->payment->perfectmoney->round) . PHP_EOL;?>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time));?>.</li>
    </ul>
  </div>
</div>
<form action="https://perfectmoney.is/api/step1.asp" method="POST">
  <input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo html_escape($this->payment->perfectmoney->data->nomor_rekening);?>"/>
  <input type="hidden" name="PAYEE_NAME" value="<?php echo html_escape($this->payment->perfectmoney->data->nama_rekening);?>"/>
  <input type="hidden" name="PAYMENT_ID" value="<?php echo $trx->de_id;?>"/>
  <input type="hidden" name="PAYMENT_AMOUNT" value="<?php echo round($trx->de_amount / $trx->de_rate, 2);?>"/>
  <input type="hidden" name="PAYMENT_UNITS" value="USD"/>
  <input type="hidden" name="STATUS_URL" value="<?php echo site_url('payment/perfectmoney/deposit/'.$trx->de_id);?>"/>
  <input type="hidden" name="PAYMENT_URL" value="<?php echo site_url('akun/deposit/view/'.$trx->de_id);?>"/>
  <input type="hidden" name="PAYMENT_URL_METHOD" value="POST"/>
  <input type="hidden" name="NOPAYMENT_URL" value="<?php echo site_url('akun/deposit/view/'.$trx->de_id);?>"/>
  <input type="hidden" name="NOPAYMENT_URL_METHOD" value="POST"/>
  <input type="hidden" name="SUGGESTED_MEMO" value="<?php echo $trx->de_note;?>"/>
  <input type="hidden" name="BAGGAGE_FIELDS" value=""/>
  <div class="panel-footer">
    <button type="submit" name="PAYMENT_METHOD" value="Pay Now!" class="btn btn-primary btn-block"><i class="fa fa-money"></i> Bayar Sekarang</button>
  </div>
</form>
<?php endif;?>