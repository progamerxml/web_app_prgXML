<?php if ($trx->de_status != 'pending'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<?php

$callback_url =site_url('payment/bitcoin/deposit/' . $trx->de_id);
$url_success =site_url('akun/deposit/view/' . $trx->de_id);
$url_failed =site_url('akun/deposit/view/' . $trx->de_id);
$data = json_decode($trx->de_opsi);
if (!is_object($data) || (is_object($data) && $data->expired_time < (time() + 3600))) {
    $postdata = array(
        'token=' . $this->payment->bitcoin->data->api->token,
        'invoice_id=DEP' . $trx->de_id,
        'rupiah=' . $trx->de_amount,
        'memo=' . $trx->de_note,
        'callback_url=' . urlencode($callback_url),
        'url_success=' . urlencode($url_success),
        'url_failed=' . urlencode($url_failed),
        );
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, 'https://bitbayar.com/api/create_invoice');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, implode('&', $postdata));
    $return = curl_exec($ch);
    curl_close($ch);
    $data = @json_decode($return);
    if (!is_object($data) || !property_exists($data, 'success')) {
        echo ('<div class="panel-body"><div class="alert alert-danger">Tidak dapat memproses permintaan!</div></div>');
        return;
    }
    $this->db->where('de_id', $trx->de_id);
    $this->db->set('de_cek_mutasi', time());
    $this->db->set('de_opsi', $return);
    $this->db->update('deposit');
}

?>
<?php if (!is_object($data) || !property_exists($data, 'success')):?>
<div class="panel-body">
  <div class="alert-danger">
    Tidak dapat memproses pembayaran, silakan hubungi Administrator.
  </div>
</div>
<?php else:?>
<div class="panel-body">
  <div style="margin-bottom: 15px;">
    <img src="https://chart.googleapis.com/chart?cht=qr&chld=H|0&chs=205&chl=<?php echo urlencode('bitcoin:'.$data->payment_address.'?amount='.$data->amount_btc);?>" class="img-responsive" style="margin: 0 auto;"/>
  </div>
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr>
          <td>Payment Address</td><td><?php echo $data->payment_address;?></td>
        </tr>
        <tr>
          <td>Jumlah</td><td><?php echo $data->amount_btc;?> BTC</td>
        </tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
      <li>Jumlah yang harus dibayarkan adalah <?php echo $data->amount_btc;?> BTC dan apabila dikenakan FEE maka FEE DITANGGUNG PEMBELI / PENGIRIM.</li>
      <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer hidden">
  <a href="<?php echo 'bitcoin:'.$data->payment_address.'?amount='.$data->amount_btc;?>" class="btn btn-primary btn-block"><i class="fa fa-money"></i> Bayar Sekarang</a>
</div>
<?php endif;?>
<?php endif;?>