<?php if ($trx->de_status != 'pending'):?>
<div class="panel-body">
  <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
</div>
<?php else:?>
<div class="panel-body">
  <div class="table-responsive">
    <table class="table table-striped">
      <tbody>
        <tr>
          <td>
            Email
          </td>
          <td>
            <?php echo html_escape($this->payment->paypal->data->nomor_rekening) . PHP_EOL;?>
          </td>
        </tr>
        <tr>
          <td>
            Jumlah
          </td>
          <td>
            <?php echo format_uang2($trx->de_amount, $trx->de_rate, $this->payment->paypal->template, $this->payment->paypal->round) . PHP_EOL;?>
          </td>
        </tr>
        <tr>
          <td>
            Catatan
          </td>
          <td>
            <?php echo html_escape($trx->de_note) . PHP_EOL;?>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div>
    <ul style="padding-left: 15px;">
    <li>Silakan lakukan pembayaran sesuai data di atas.</li>
    <li>Setelah melakukan pembayaran silakan klik tombol &quot;<b>Konfirmasi Pembayaran</b>&quot;.</li>
    <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time));?>.</li>
    </ul>
  </div>
</div>
<div class="panel-footer">
  <a href="<?php echo site_url('payment/paypal/deposit/'.$trx->de_id);?>" class="btn btn-primary btn-block" id="submit-confirm"><i class="fa fa-check"></i> Konfirmasi Pembayaran</a>
</div>
<?php endif;?>