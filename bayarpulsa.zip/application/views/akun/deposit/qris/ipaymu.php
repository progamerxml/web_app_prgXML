<?php if ($trx->de_status != 'pending') : ?>
  <div class="panel-body">
    <div class="alert alert-success">Pembayaran berhasil diselesaikan.</div>
  </div>
<?php else : ?>
  <script src="<?php echo base_url('assets/js/lazyload.min.js'); ?>"></script>
  <script>
    ll = new LazyLoad({
      elements_selector: "#qris",
      load_delay: 300,
      threshold: 0
    });
    $('img[src*="assets/payments/qris.png"]').hide();
    $.get('<?php echo site_url('payment/qris/ipaymu/inquiry/deposit/' . $trx->de_id); ?>', function(data) {
      if (data.success) {
        $('#qris').attr('data-src', data.results.qr_url);
        $('.amount').text(data.results.amount);
        $('.fee').text(data.results.fee);
        $('.total-amount').text(data.results.total_amount);
        $('#loading').hide();
        $('#result').show();
        ll.update();
      } else {
        $('#loading').text(data.message);
      }
    });
  </script>
  <div class="panel-body text-center" style="margin-top: -15px;" id="loading">
    <img src="<?php echo base_url('assets/ajax-loader.gif'); ?>" />
  </div>
  <div class="panel-body" style="margin-top: -15px; display: none" id="result">
    <img class="img-responsive" src="<?php echo base_url('assets/ajax-loader.gif'); ?>" id="qris" style="margin: 0 auto;" />
    <div class="table-responsive" style="margin-top: 15px;">
      <table class="table table-striped">
        <tbody>
          <tr>
            <td>Jumlah Deposit</td>
            <td class="text-right"><span class="amount">-</span></td>
          </tr>
          <tr>
            <td>Biaya Layanan</td>
            <td class="text-right"><span class="fee">-</span></td>
          </tr>
          <tr>
            <td>Total</td>
            <td class="text-right"><strong class="total-amount">-</strong></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div>
      <ul style="padding-left: 15px; margin-bottom: 0;">
        <li>Silakan scan gambar di atas menggunakan aplikasi OVO, DANA, LinkAja, GoPay atau aplikasi lainnya yang mendukung pembayaran QRIS.</li>
        <li>Pembayaran berlaku s/d <?php echo format_tanggal($trx->de_tanggal + (3600 * $deposit->time)); ?>.</li>
      </ul>
    </div>
  </div>
<?php endif; ?>