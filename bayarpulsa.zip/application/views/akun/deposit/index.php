<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Deposit</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">nav {float: right; margin-bottom: 15px;}</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Deposit</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><i class="fa fa-money"></i> Deposit</h3>
            </div>
            <?php if ($page == 1):?>
            <?php if ($allow_deposit):?>
            <div style="margin: 15px;">
              <?php echo form_open();?>
              <div class="row">
                <div class="col-sm-4 col-md-3 form-group">
                  <div class="input-group">
                    <span class="input-group-addon">Rp</span>
                    <input class="form-control" type="number" name="amount" id="amount" maxlength="12" value="<?php echo set_value('amount');?>" required="required" data-toggle="tooltip" data-title="Jumlah Deposit" placeholder="<?php echo $deposit->min;?>" min="<?php echo $deposit->min;?>" max="<?php echo $deposit->max;?>"/>
                  </div>
                </div>
                <div class="col-sm-5 col-md-6 form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
                    <select class="form-control" name="payment" id="payment" data-toggle="tooltip" data-title="Metode Pembayaran">
                    <option value="">-- Pembayaran --</option>
                    <?php
                     foreach ($this->payment->get() as $payment):
                     if ($payment->status == 'off' || !in_array($payment->key, $deposit->payments))
                        continue;
                     ?>
                     <?php if ($this->payment->is_offline($payment->key)):?>
                     <option value="" disabled="disabled"><?php echo html_escape($payment->nama);?> (Offline)</option>
                     <?php elseif ($payment->user == 2 && !$this->user->verified):?>
                     <option value="" disabled="disabled"><?php echo html_escape($payment->nama);?> (Hanya member terverifikasi)</option>
                     <?php else:?>
                     <option value="<?php echo $payment->key;?>" <?php echo ($this->input->post('payment') == $payment->key ? 'selected="selected"' : '');?>><?php echo html_escape($payment->nama);?></option>
                     <?php endif;?>
                    <?php endforeach;?>
                    </select>
                  </div>
                </div>
                <div class="col-sm-3 col-md-3 form-group"><button class="btn btn-primary btn-block" type="submit" name="submit" value="deposit"><i class="fa fa-plus"></i> Deposit</button></div>
                <div class="col-xs-12"><i>Minimal <?php echo format_uang($deposit->min);?>, maksimal <?php echo format_uang($deposit->max);?>, dan harus kelipatan <?php echo format_uang($deposit->multiple);?></i></div>
              </div>
              <?php echo form_close();?>
            </div>
            <?php elseif ($this->system->perm->allow_deposit == 0):?>
            <div class="alert alert-warning alert-dismissible fade in" role="alert" style="margin-bottom: 0; margin: 15px;">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">&times;</span></button>
              Saat ini layanan deposit tidak tersedia.
            </div>
            <?php else:?>
            <div class="alert alert-warning alert-dismissible fade in" role="alert" style="margin-bottom: 0; margin: 15px;">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>Deposit hanya diijinkan <?php echo $this->system->perm->allow_deposit == 1 ? '' : 'untuk member terverifikasi ';?>pada hari dan pukul:</strong>
              <ul class="list-unstyled">
              <?php
                  $days = array('mon' => 'Senin: ', 'tue' => 'Selasa: ', 'wed' => 'Rabu: ', 'thu' => 'Kamis: ', 'fri' => 'Jumat: ', 'sat' => 'Sabtu: ', 'sun' => 'Minggu: ');
                  foreach ($deposit->waktu as $w_key => $w_val) {
                    echo '<li><i class="fa fa-check"></i> '.str_replace(array_keys($days), array_values($days), $w_key) . $w_val.'</li>';
                  }
              ?>
              </ul>
            </div>
            <?php endif;?>
            <?php endif;?>
            <?php if (!$total):?>
            <div class="panel-body"><div class="alert alert-warning">Belum ada riwayat deposit.</div></div>
            <?php else:?>
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Tanggal</th>
                    <th>Jumlah</th>
                    <th>Pembayaran</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($results as $res):?>
                  <tr>
                    <td><a href="<?php echo site_url('akun/deposit/view/'.$res->de_id);?>"><?php echo format_tanggal($res->de_tanggal);?></a></td>
                    <td><?php echo format_uang2($res->de_amount, $res->de_rate, $this->payment->{$res->de_payment}->template, $this->payment->{$res->de_payment}->round);?></td>
                    <td><?php echo html_escape($this->payment->{$res->de_payment}->nama);?></td>
                    <td><?php echo deposit_status_label($res, $exp_time, false);?></td>
                  </tr>
                  <?php endforeach;?>
                </tbody>
              </table>
            </div>
            <?php endif;?>
          </div>
          <?php echo pagination(site_url('akun/deposit/index/'),$start,$total,$this->system->set['list_per_page'],'%d');?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>