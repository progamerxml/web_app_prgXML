<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      Rincian Deposit #<?php echo $trx->de_id;?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li><a href="<?php echo site_url('akun/deposit');?>">Deposit</a></li>
        <li class="active"><span>Deposit #<?php echo $trx->de_id;?></span></li>
      </ul>
      <div class="row">
        <div class="col-sm-3 hidden-print">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-5">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-list-alt">
                </i>
                Deposit #<?php echo $trx->de_id;?>
              </h3>
            </div>
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-striped">
                  <tbody>
                    <tr>
                      <td>
                        Tanggal
                      </td>
                      <td>
                        <?php echo format_tanggal($trx->de_tanggal) . PHP_EOL;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Jumlah
                      </td>
                      <td>
                        <?php echo format_uang2($trx->de_amount, $trx->de_rate, $this->payment->{$trx->de_payment}->template, $this->payment->{$trx->de_payment}->round) . PHP_EOL;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Metode Pembayaran
                      </td>
                      <td>
                        <?php echo html_escape($this->payment->{$trx->de_payment}->nama) . PHP_EOL;?>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        Status
                      </td>
                      <td>
                        <?php echo ucfirst(str_replace('_',' ',$trx->de_status)) . PHP_EOL;?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="panel-footer hidden-print">
              <button type="button" id="komplain" class="btn btn-warning pull-right"><i class="fa fa-exclamation-circle"></i> Komplain</button>
              <?php if ($trx->de_status === 'pending' && $trx->de_tanggal > (time() - (3600 * $deposit->time))):?>
              <a class="btn btn-danger" href="<?php echo site_url('akun/deposit/cancel/'.$trx->de_id);?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-remove"></i> Batalkan</a>
              <?php endif;?>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
        <div class="col-sm-4 hidden-print">
          <?php if ($trx->de_status == 'pending' && $trx->de_tanggal < $exp_time):?>
          <div class="alert alert-danger">
            <h3>
              Tidak Berlaku
            </h3>
            Pembayaran belum diselesaikan dan pesanan sudah tidak berlaku lagi
          </div>
          <?php else:?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                Bayar dengan <?php echo $this->payment->{$trx->de_payment}->nama . PHP_EOL;?>
              </h3>
            </div>
            <?php if (file_exists(FCPATH.'assets/payments/'.$trx->de_payment.'.png')):?>
            <div class="panel-body" style="margin-bottom: 0;padding-bottom: 0;">
              <div class="text-center">
                <img src="<?php echo base_url('assets/payments/'.$trx->de_payment.'.png');?>" class="img-thumbnail" style="margin: 0 auto;"/>
              </div>
            </div>
            <?php endif;?>
            <?php if ($this->payment->{$trx->de_payment}->status != 'on'):?>
            <div class="panel-body">
              <div class="alert alert-danger">
                Pembayaran <?php echo $this->payment->{$trx->de_payment}->nama;?> saat ini sedang tidak aktif.
              </div>
            </div>
            <?php elseif ($trx->de_status == 'pending' && $trx->de_tanggal < $exp_time):?>
            <div class="panel-body">
              <div class="alert alert-danger">
                Pembayaran belum diselesaikan dan pesanan sudah tidak berlaku lagi.
              </div>
            </div>
            <?php elseif ($trx->de_status == 'refund'):?>
            <div class="panel-body">
              <div class="alert alert-info">
                Pembayaran direfund.
              </div>
            </div>
            <?php elseif ($trx->de_status == 'dalam_proses'):?>
            <div class="panel-body">
              <div class="alert alert-info">
                Deposit Anda sedang menunggu konfirmasi Administrator.
              </div>
            </div>
            <?php else:?>
            <?php include_once(VIEWPATH.'akun/deposit/'.$trx->de_payment.'.php'); ?>
            <?php endif;?>
          </div>
          <?php endif;?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
    <?php
    $content =  '<ul class="list-unstyled">
        <li><a href="'.site_url('contact-us?pesan='.urlencode('Komplain Deposit ID: '.$trx->de_id.' > Sudah transfer tapi status pembayaran masih pending')).'">Sudah transfer tapi status pembayaran masih pending</a></li>
        <li><a href="'.site_url('contact-us?pesan='.urlencode('Komplain Deposit ID: '.$trx->de_id.' > Data transfer salah')).'">Data transfer salah</a></li></li>
        <li><a href="'.site_url('contact-us?pesan='.urlencode('Komplain Deposit ID: '.$trx->de_id.' > ')).'">Masalah lainnya</a></li></li>
        </ul>';
    ?>
    <script>
    $(function () {
        $('#komplain').popover(<?php echo json_encode(array('title'=>'Pilih topik permasalahan','content'=>$content,'html'=>true,'placement'=>'top'));?>);
    })
    </script>
  </body>

</html>