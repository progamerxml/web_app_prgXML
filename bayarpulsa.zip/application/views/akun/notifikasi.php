<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Pemberitahuan</title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
    <style type="text/css">nav{margin-bottom: 15px;float: right;}</style>
  </head>
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Pemberitahuan</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <?php if (!$total):?>
          <div class="alert alert-warning">Tidak ada pemberitahuan.</div>
          <?php else:?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <div class="dropdown pull-right">
                <a id="dropdownMenu1" title="Menu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" style="font-size: 18px;color:#333;cursor:pointer;" title="Pengaturan">
                  <i class="fa fa-ellipsis-v"></i>
                </a>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                  <li><a href="<?php echo site_url('akun/notifikasi/mark_all_as_read');?>"><i class="fa fa-bell-o"></i> Tandai semua sudah dibaca</a></li>
                  <li><a data-toggle="modal" data-target="#myModal" href="<?php echo site_url('akun/notifikasi/clear');?>"><i class="fa fa-trash"></i> Hapus semua pemberitahuan</a></li>
                </ul>
              </div>
              <h3><i class="fa fa-bell"></i> Pemberitahuan</h3>
              <div class="clearfix"></div>
            </div>
            <div class="list-group">
              <?php foreach ($results as $result):?>
              <a href="<?php echo site_url('akun/notifikasi/read/'.$result->nf_id);?>" class="list-group-item">
                <h5 class="list-group-item-heading"><i data-toggle="tooltip" class="fa fa-bell<?php echo ($result->nf_baca == '1' ? '-o" data-title="Sudah dibaca' : '" data-title="Belum dibaca');?>"></i> <?php echo $result->nf_admin == '1' ? '<i class="fa fa-shield" data-toggle="tooltip" data-title="Pemberitahuan untuk Administrator"></i> ' : '';?><?php echo html_escape($result->nf_judul);?> (<small><?php echo format_tanggal($result->nf_tanggal);?></small>)</h5>
                <p class="list-group-item-text"><?php echo nl2br($result->nf_link ? html_escape($result->nf_teks) : substr(strip_tags($result->nf_teks), 0, 160));?></p>
              </a>
              <?php endforeach;?>
            </div>
          </div>
          <?php echo pagination(site_url('akun/notifikasi/index'), $start, $total, $this->system->set['list_per_page'], '/%d');?>
          <?php endif;?>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>
</html>