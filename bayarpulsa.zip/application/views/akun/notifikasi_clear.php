<?php echo form_open();?>
  <div class="form-group">
    <div class="radio">
      <label>
        <input type="radio" name="status" value="sudah_dibaca"/> Hapus semua pemberitahuan yang sudah dibaca
      </label>
    </div>
    <div class="radio">
      <label>
        <input type="radio" name="status" value="semua" checked="checked"/> Hapus semua pemberitahuan
      </label>
    </div>
  </div>
  <?php if ($this->user->is_admin()):?>
  <div class="form-group">
    <div class="checkbox">
      <label><input type="checkbox" name="all_users" value="1"/> <i class="fa fa-shield"></i> Lakukan tindakan ini untuk semua pengguna</label>
    </div>
  </div>
  <?php endif;?>
  <div>
    <button type="submit" class="btn btn-primary">
      <i class="fa fa-check">
      </i>
      Submit
    </button>
    &nbsp;
    <a href="<?php echo site_url('akun/notifikasi');?>" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i> Batal</a>
  </div>
<?php echo form_close();?>