<?php

$links = array();
$links[] = array('Profile', site_url('akun/profil'), 'fa fa-user-o', $this->router->fetch_class() == 'profil' ? true : false);
$links[] = array('Riwayat Transaksi', site_url('akun/riwayat-transaksi'), 'fa fa-history', $this->router->fetch_class() == 'riwayat_transaksi' ? true : false);
$links[] = array('Deposit', site_url('akun/deposit'), 'fa fa-money', $this->router->fetch_class() == 'deposit' ? true : false);
$links[] = array('Transfer Saldo', site_url('akun/transfer-saldo'), 'fa fa-money', $this->router->fetch_class() == 'transfer_saldo' ? true : false);
$links[] = array('Mutasi Saldo', site_url('akun/riwayat-saldo'), 'fa fa-credit-card', $this->router->fetch_class() == 'riwayat_saldo' ? true : false);
$links[] = array('Pemberitahuan', site_url('akun/notifikasi'), 'fa fa-bell-o', $this->router->fetch_class() == 'notifikasi' ? true : false, ($this->user->count_notifications() ? '<span class="badge">'.$this->user->count_notifications().'</span>' : ''));
$links[] = array('Transaksi Via Telegram', site_url('akun/telegramtrx'), 'fa fa-telegram', $this->router->fetch_class() == 'telegramtrx' ? true : false);
$links[] = array('Transaksi Via SMS', site_url('akun/smstrx'), 'fa fa-envelope-o', $this->router->fetch_class() == 'smstrx' ? true : false);
$links[] = array('Transaksi Via Jabber', site_url('akun/jabbertrx'), 'fa fa-comment-o', $this->router->fetch_class() == 'jabbertrx' ? true : false);
$links[] = array('Pembelian Massal', site_url('akun/mass-order'), 'fa fa-shopping-cart', $this->router->fetch_class() == 'mass_order' ? true : false);
$links[] = array('Verifikasi', site_url('akun/verifikasi'), 'fa fa-check-circle', $this->router->fetch_class() == 'verifikasi' ? true : false);
$links[] = array('Pengaturan', site_url('akun/pengaturan'), 'fa fa-cogs', $this->router->fetch_class() == 'pengaturan' ? true : false);
if ($this->user->data['us_rights'] == 10)
    $links[] = array('Admin Panel', site_url('admin'), 'fa fa-shield', false);
$links[] = array('Keluar', site_url('user/logout'), 'fa fa-sign-out', false);

$params = array(array('title' => 'Akun Saya', 'links' => $links));
echo sidebar_menu($params);
