<?php if (!$sender):?>
<div class="alert alert-danger">
  Akun tidak ditemukan.
</div>
<?php else:?>
<?php $data = json_decode($sender->ct_data, true); ?>
<div>
  <table class="table">
    <tr><td>Pengirim</td><td><?php echo html_escape($sender->ct_sender);?></td></tr>
    <tr><td>Ditambahkan</td><td><?php echo format_tanggal($sender->ct_added);?></td></tr>
    <tr><td>Status</td><td><?php echo $sender->ct_blocked ? '<span class="text-danger"><i class="fa fa-ban"></i></span> Diblokir' : ($sender->ct_verified ? '<span class="text-success"><i class="fa fa-check"></i></span> Terverifikasi' : '<span class="text-muted"><i class="fa fa-times"></i></span> Belum terverifikasi');?></td></tr>
    <tr><td>Total Pesan</td><td><span class="badge"><?php echo $sender->ct_total_msg;?></span> <?php echo ($sender->ct_last_msg ? '<span class="text-muted">'.format_tanggal($sender->ct_last_msg).'</span>' : '');?></td></tr>
    <tr><td>Total Trx</td><td><span class="badge"><?php echo $sender->ct_total_trx;?></span> <?php echo ($sender->ct_last_trx ? '<span class="text-muted">'.format_tanggal($sender->ct_last_trx).'</span>' : '');?></td></tr>
  </table>
</div>
<?php if (!$sender->ct_verified):?>
<div class="well well-sm" id="verifikasi">
  <form method="post" action="javascript:;" id="form">
    <p id="error" class="text-danger" style="display: none;"><strong><i class="fa fa-exclamation-circle"></i> <span></span></strong></p>
    <div class="input-group">
      <input type="text" maxlength="8" class="form-control" name="kode" placeholder="Kode Verifikasi" />
      <span class="input-group-btn">
        <button class="btn btn-primary" type="submit"><i class="fa fa-check"></i> Verifikasi</button>
      </span>
    </div>
    <p class="help-block" style="margin-bottom: 0 !important;">Belum menerima kode verifikasi? <a id="kirim-kode" href="javascript:;">Klik di sini</a> untuk mengirim ulang.</p>
  </form>
</div>
<?php endif;?>
<div class="row">
  <div class="col-xs-6">
    <a class="btn btn-default" href="<?php echo site_url('akun/jabbertrx/ubah-pin/'.$sender->ct_id);?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-lock"></i> Ubah PIN</a>
  </div>
  <div class="col-xs-6 text-right">
    <a class="btn btn-danger" href="<?php echo site_url('akun/jabbertrx/hapus-pengirim/'.$sender->ct_id);?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-times"></i> Hapus</a>
  </div>
</div>
<?php if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || @$_SERVER['HTTP_X_REQUESTED_WITH'] != 'XMLHttpRequest'):?>
<hr />
<div class="text-center">
  <a href="<?php echo site_url('akun/jabbertrx');?>">&laquo; Kembali</a>
</div>
<?php endif;?>
<?php if (!$sender->ct_verified):?>
<script type="text/javascript">$(document).on("click","#kirim-kode",function(){var container = $(this).parent();container.hide();$.get("<?php echo site_url('akun/jabbertrx/kirim-kode-verifikasi/'.$sender->ct_id.'/1');?>",function(json){container.show();alert(json.message);var index=json.message.indexOf("Pengirim diblokir");if(index>=0){location.href="<?php echo site_url('akun/jabbertrx');?>";}});return false;});$(document).on("submit","#form",function(e){var mInput=$(this).find(".form-control");var mError=$(this).find("#error");var mBtn=$(this).find(".btn");var kode=mInput.val();mError.hide();if(kode.length<4){mError.find("span").text("Silakan masukan kode verifikasi dengan benar.");mError.show();}else{mInput.attr("disabled","disabled");mBtn.html('<i class="fa fa-spinner fa-spin"></i> Memverifikasi');mBtn.attr("disabled","disabled");$.get("<?php echo site_url('akun/jabbertrx/verifikasi/'.$sender->ct_id);?>/"+kode+"/1",function(json){if(json.success==false){var index=json.message.indexOf("Pengirim diblokir");if(index>=0){alert(json.message);location.href="<?php echo site_url('akun/jabbertrx');?>";}else{mInput.removeAttr("disabled");mInput.val("");mBtn.html('<i class="fa fa-check"></i> Verifikasi');mBtn.removeAttr("disabled");mError.find("span").text(json.message);mError.show();}}else{location.href="<?php echo site_url('akun/jabbertrx/index/'.$sender->ct_id);?>";}});}return false;});</script>
<?php endif;?>
<?php endif;?>