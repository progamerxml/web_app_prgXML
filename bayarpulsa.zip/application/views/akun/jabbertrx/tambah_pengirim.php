<?php echo form_open(current_url(), 'class="form-horizontal"');?>
  <div class="form-group">
    <label class="col-sm-2 control-label">Pengirim</label>
    <div class="col-sm-10">
      <input class="form-control" type="text" name="pengirim" value="<?php echo set_value('pengirim');?>" required="required" placeholder="username@example.com"/>
      <p class="help-block" style="margin-bottom: 0;">Alamat jabber kamu yang akan digunakan untuk transaksi.<?php if ($set['xmpp_domain']):?><br/>List domain jabber yang diperbolehkan: <i><?php echo html_escape(implode('</i>, <i>', $set['xmpp_domain']));?></i><?php endif;?></p>
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">PIN</label>
    <div class="col-sm-10">
      <input class="form-control" type="number" name="pin" value="<?php echo set_value('pin');?>" required="required" min="1000" max="9999" maxlength="4"/>
      <p class="help-block" style="margin-bottom: 0;">PIN transaksi hanya berupa digit dengan panjang 4 karakter.</p>
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">Kata Sandi</label>
    <div class="col-sm-10">
      <input class="form-control" type="password" name="user_password" required="required" id="user_password" autocomplete="new-password"/>
      <p class="help-block" style="margin-bottom: 0;">Masukan kata sandi akun kamu untuk memverifikasi tindakan ini.</p>
    </div>
  </div>
  <div class="form-group" style="margin-bottom: 0;">
    <div class="col-sm-offset-2 col-sm-10">
      <button class="btn btn-primary" type="submit" name="submit" value="save"><i class="fa fa-check"></i> Simpan</button>
      &nbsp;
      <a href="<?php echo site_url('akun/jabbertrx');?>" class="btn btn-default" data-dismiss="modal"><i class="fa fa-remove"></i> Batal</a>
    </div>
  </div>
<?php echo form_close();?>