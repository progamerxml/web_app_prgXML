<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html>
  
  <head>
    <title>
      Akun Saya &gt; Lisensi | <?php echo html_escape($this->system->set['site_name']) . PHP_EOL; ?>
    </title>
    <?php include_once(VIEWPATH.'includes/head.php'); ?>
  </head>
  
  <body>
    <?php include_once(VIEWPATH.'includes/navbar.php'); ?>
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="<?php echo site_url();?>"><i class="fa fa-home"></i></a></li>
        <li><a href="<?php echo site_url('akun/profil');?>">Akun Saya</a></li>
        <li class="active"><span>Lisensi</span></li>
      </ul>
      <div class="row">
        <div class="col-sm-4 col-md-3">
          <?php include(dirname(__FILE__).'/../_sidebar.php');?>
        </div>
        <div class="col-sm-8 col-md-9">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3>
                <i class="fa fa-key"></i> Lisensi
              </h3>
            </div>
            <div class="panel-body">
              <div style="margin-bottom: 15px;">
                <a class="btn btn-default btn-sm" href="<?php echo site_url('akun/lisensi/import');?>" data-toggle="modal" data-target="#myModal">Import Lisensi</a>
              </div>
              <?php if (!$total):?>
              <div class="alert alert-warning">
                Saat ini anda belum meliki lisensi, untuk order lisensi silakan lakukan seperti biasa di halaman order.
              </div>
              <?php else:?>
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Domain</th>
                      <th>Kode Lisensi</th>
                      <th>Dibuat</th>
                      <th>Masuk Terakhir</th>
                      <th>Status</th>
                      <th style="width: 100px;" class="text-center">Tindakan</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach($results as $result):?>
                    <tr>
                      <td><?php echo $result->li_id;?></td>
                      <td><?php
                      $domains =  explode(',', $result->li_domain);
                      $links = array();
                      foreach ($domains as $domain) {
                        $links[] = '<a href="http://'.$domain.'" target="_new">'.$domain.'</a>';
                      }
                      echo implode(', ', $links);
                      ?></td>
                      <td><?php echo $result->li_kode;?></td>
                      <td><?php echo format_tanggal($result->li_regdate);?></td>
                      <td><?php echo $result->li_lastdate ? format_tanggal($result->li_lastdate) : '';?></td>
                      <td><?php echo ucwords($result->li_status);?></td>
                      <td style="width: 100px" class="text-center">
                        <a class="btn btn-default btn-xs <?php echo $result->li_domain == '' ? 'disabled' : '';?>"" href="<?php echo site_url('akun/lisensi/edit/'.$result->li_id);?>" data-toggle="modal" data-target="#myModal" title="Ganti domain"><i class="fa fa-edit"></i></a>
                        <a class="btn btn-info btn-xs" href="<?php echo site_url('akun/lisensi/transfer/'.$result->li_id);?>" data-toggle="modal" data-target="#myModal" title="Transfer Lisensi"><i class="fa fa-exchange"></i></a>
                      </td>
                    </tr>
                    <?php endforeach;?>
                  </tbody>
                </table>
              </div>
              <?php echo pagination(site_url('akun/lisensi/index'), $start, $total, $this->system->set['list_per_page'], '/%d');?>
              <?php endif;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include_once(VIEWPATH.'includes/foot.php'); ?>
  </body>

</html>