<?php echo form_open(current_url(), 'class="form-horizontal"');?>
  <div class="form-group">
    <label class="col-sm-2 control-label">
      Domain
    </label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="domain" value="<?php echo set_value('domain');?>" required="required"/>
      <p class="help-block">Masukan domain tanpa www. Contoh: isipulsa.co</p>
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">
      Kode Lisensi
    </label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="kode_lisensi" value="<?php echo set_value('kode_lisensi');?>" required="required"/>
    </div>
  </div>
  <div class="form-group" style="margin-bottom:0">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" name="submit" value="1" class="btn btn-primary">
        Import
      </button>
      &nbsp;
      <a href="<?php echo site_url('akun/lisensi');?>" class="btn btn-default" data-dismiss="modal">
        Batal
      </a>
    </div>
  </div>
<?php echo form_close();?>