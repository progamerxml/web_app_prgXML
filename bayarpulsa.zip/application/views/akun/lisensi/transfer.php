<?php echo form_open(current_url(), 'class="form-horizontal"');?>
  <div class="alert alert-info">
    Transfer lisensi akan dikenakan biaya Rp. 10.000
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">
      Username
    </label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="username" value="<?php echo set_value('username');?>" required="required"/>
      <p class="help-block">Silakan masukan username penerima.</p>
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">
      Domain
    </label>
    <div class="col-sm-10">
      <input type="text" class="form-control" value="<?php echo html_escape($lisensi->li_domain);?>" readonly="readonly"/>
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-2 control-label">
      Kode Lisensi
    </label>
    <div class="col-sm-10">
      <input type="text" class="form-control" value="<?php echo html_escape($lisensi->li_kode);?>" readonly="readonly"/>
    </div>
  </div>
  <div class="form-group" style="margin-bottom:0">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" name="submit" value="1" class="btn btn-primary">
        Transfer
      </button>
      &nbsp;
      <a href="<?php echo site_url('akun/lisensi');?>" class="btn btn-default" data-dismiss="modal">
        Batal
      </a>
    </div>
  </div>
<?php echo form_close();?>