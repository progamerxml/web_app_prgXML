Hanya berjalan di PHP 5
